package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.model.Segmento;
import com.sistemas.presys.server.persistencia.ICorrelativoDAO;
import com.sistemas.presys.server.persistencia.ISegmentoDAO;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ManejadorSegmentosEJB implements IManejadorSegmentosEJB{

	@EJB
	ISegmentoDAO segmentoDAO;
	
	@EJB
	ICorrelativoDAO correlativoDAO;
	
	
	@Override
	public ArrayList<DTSegmento> obtenerSegmentos() {
        ArrayList<DTSegmento> resultado = new ArrayList<DTSegmento>();
		
		List<Segmento> listaSegmentos;
        
		listaSegmentos = segmentoDAO.obtenerTodos();
		
		cargarListaDTSegmentos(resultado, listaSegmentos);
		
		return resultado;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void agregar(String xcodigo, String xnombre, String xdescripcion)
			throws LogicException {
        Segmento segmento = new Segmento(xcodigo, xnombre, xdescripcion, true);
		
        Segmento segmentoAux = segmentoDAO.obtenerPorCodigo(xcodigo);
		
		if (segmentoAux != null) {
			throw new LogicException("Ya existe un segmento con codigo: " + xcodigo);
		}
	
		segmentoDAO.agregar(segmento);
		
		correlativoDAO.actualizarCorrelativo(Ctes.K_CORR_SEG);        
	}

	@Override
	public void eliminar(String xcodigo) {
	       segmentoDAO.eliminar(xcodigo);		
	}

	@Override
	public void modificar(String codigo, String nombre, String descripcion,
			Boolean habilitado) {
        Segmento segmento = new Segmento(codigo, nombre, descripcion, habilitado);
		
		segmentoDAO.modificarSegmento(segmento);		
	}

	@Override
	public ArrayList<DTSegmento> buscar(Integer buscarPor, String cadena) {
		   ArrayList<DTSegmento> resultado = new ArrayList<DTSegmento>();
			
	       List<Segmento> listaSegmento = segmentoDAO.buscar(buscarPor, cadena);  
		
	       cargarListaDTSegmentos(resultado, listaSegmento);
		
	       return resultado;
	}

	@Override
	public DTSegmento obtenerPorCodigo(String xcodigoProducto) {
        Segmento segmento = segmentoDAO.obtenerPorCodigo(xcodigoProducto);
		
		DTSegmento dtSegmento = obtenerDTSegmentoAPartirDeSegmento(segmento);
		
		return dtSegmento;
	}


	
	// METODOS AUXILIARES
	
	private void cargarListaDTSegmentos(ArrayList<DTSegmento> resultado,
            List<Segmento> listaSegmentos) {

		for (int i = 0; i < listaSegmentos.size(); i ++) {
		
		DTSegmento dtSegmento = obtenerDTSegmentoAPartirDeSegmento(listaSegmentos.get(i));
		
		resultado.add(dtSegmento);
		}	
	}

	private DTSegmento obtenerDTSegmentoAPartirDeSegmento(Segmento segmento) {			
		DTSegmento resultado = new  DTSegmento();
		
		resultado.setCodigo(segmento.getCodigo());
		resultado.setNombre(segmento.getNombre());
		resultado.setDescripcion(segmento.getDescripcion());
		resultado.setHabilitado(segmento.getHabilitado());
		
		
		return resultado;
	}


}
