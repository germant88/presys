package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.sistemas.presys.server.model.Rol;
import com.sistemas.presys.server.model.Usuario;
import com.sistemas.presys.server.persistencia.IUsuarioDAO;
import com.sistemas.presys.server.utiles.Encriptacion;
import com.sistemas.presys.shared.datatypes.DTRol;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;

@Stateless
public class ManejadorUsuariosEJB implements IManejadorUsuariosJEJB {
	@EJB
    IUsuarioDAO usuarioDAO;
	
	@EJB
	IManejadorRolesEJB manejadorRoles;
	
	
	public ArrayList<DTUsuario> obtenerUsuarios(){
		  ArrayList<DTUsuario> resultado = new ArrayList<DTUsuario>();
		
		  List<Usuario> listaUsuarios;
      
		  listaUsuarios = usuarioDAO.obtenerTodos();
		
	      cargarListaDTUsuarios(resultado, listaUsuarios);
		
		  return resultado;
	}
	
	public DTUsuario obtenerPorCodigo(String xcodigo) throws LogicException{
		try {
		   Usuario usuarioObtenido = usuarioDAO.obtenerPorCodigo(xcodigo);
		   DTUsuario dtUsuario = obtenerDTUsuarioAPartirDeUsuario(usuarioObtenido);
		   return dtUsuario;		   
		} catch (Exception e) {
			throw new LogicException("No se pudo obtener ningun usuario con el codigo: " + xcodigo);
		}		
	}


	private void cargarListaDTUsuarios(ArrayList<DTUsuario> resultado,
			List<Usuario> listaUsuarios) {
        
		for (int i = 0; i < listaUsuarios.size(); i ++) {
			
			DTUsuario dtUsuario = obtenerDTUsuarioAPartirDeUsuario(listaUsuarios.get(i));
			
			resultado.add(dtUsuario);
		}
		
	}


	private DTUsuario obtenerDTUsuarioAPartirDeUsuario(Usuario usuario) {
        DTUsuario resultado = new  DTUsuario();
		
        resultado.setId((usuario.getUsuario_id()));
		resultado.setPassword(usuario.getPassword());
		resultado.setNombre(usuario.getNombre());
		resultado.setApellido(usuario.getApellido());		
		
		ArrayList<DTRol> listaRolesDeUsuario = new ArrayList<DTRol>();
		
		for (int i = 0; i < usuario.getRoles().size(); i ++) {
		   DTRol dtRol;
		   dtRol = manejadorRoles.obtenerDTRolAPartirDeRol(usuario.getRoles().get(i));
		   if (dtRol != null) {
			   listaRolesDeUsuario.add(dtRol);
		   }
		}
		
		resultado.setListaRoles(listaRolesDeUsuario);
		return resultado;
	}


	@Override
	public void agregarUsuario(String codigo, String nombre, String apellido,
			String password, List<DTRol> listaRolesSeleccionados) throws Exception {
        
		Usuario usuario = new Usuario(codigo, nombre, apellido, password);
        
		
		ArrayList<Rol> listaRolesUsuario = new ArrayList<Rol>();
		for (int i = 0; i < listaRolesSeleccionados.size(); i ++) {
			Rol unRol = manejadorRoles.obtenerRolPorCodigo(((DTRol)listaRolesSeleccionados.get(i)).getId());
			listaRolesUsuario.add(unRol);				
		}		
		
		usuario.setRoles(listaRolesUsuario);
		
        usuario.setPassword(Encriptacion.encriptarPassword(usuario.getPassword()));
		
        Usuario usuarioAux = usuarioDAO.obtenerPorCodigo(codigo);
		
		if (usuarioAux != null) {
			throw new LogicException("Ya existe un usuario con codigo: " + codigo);
		}
	
		usuarioDAO.agregar(usuario);				
	}
	
	private Rol obtenerRolAPartirDeDTRol(DTRol dtRol){
		return manejadorRoles.obtenerRolPorCodigo(dtRol.getId());
	}


	@Override
	public void eliminarUsuario(String id) {
       usuarioDAO.eliminar(id);
	}

	@Override
	public void modificarUsuario(String codigo, String nombre, String apellido,
			String contrasena, Boolean cambiarContrasena, List<DTRol> listaRolesSeleccionados) throws Exception {
	 
		Usuario usuario = new Usuario(codigo, nombre, apellido, contrasena);
		
		ArrayList<Rol> listaRolesUsuario = new ArrayList<Rol>();
		for (int i = 0; i < listaRolesSeleccionados.size(); i ++) {
			Rol unRol = manejadorRoles.obtenerRolPorCodigo(((DTRol)listaRolesSeleccionados.get(i)).getId());
			listaRolesUsuario.add(unRol);				
		}		
		
		usuario.setRoles(listaRolesUsuario);
		
		if (cambiarContrasena) {
           usuario.setPassword(Encriptacion.encriptarPassword(usuario.getPassword()));
		}
		
	    usuarioDAO.modificar(usuario, cambiarContrasena);
	}
	
	public void cambiarContrasena(String codigo, String contrasena) throws Exception {	
		String contrasenaEncriptada = "";
		
		Usuario usuario;
				
		contrasenaEncriptada = Encriptacion.encriptarPassword(contrasena);
		
		usuario = usuarioDAO.obtenerPorCodigo(codigo);
		
		usuario.setPassword(contrasenaEncriptada);
		
		usuarioDAO.modificar(usuario, true);			
	}
	
	public boolean validarContrasena(String contrasenaActualIngresada, String codigoUsuario) throws Exception{
		
   	   String contrasenaActualIngresadaEncript = Encriptacion.encriptarPassword(contrasenaActualIngresada);
	
   	   Usuario usuario;
   	   
   	   usuario = usuarioDAO.obtenerPorCodigo(codigoUsuario);
   	   
   	   if (usuario.getPassword().equals(contrasenaActualIngresadaEncript)) {
   		   return true;
   	   }
   	   else {
   		   return false;
   	   }						 
	}

	@Override
	public ArrayList<DTUsuario> buscarUsuarios(Integer buscarPor, String text) {
       ArrayList<DTUsuario> resultado = new ArrayList<DTUsuario>();
			
	   List<Usuario> listaUsuarios = usuarioDAO.buscar(buscarPor, text);  
		
	   cargarListaDTUsuarios(resultado, listaUsuarios);
		
	   return resultado;
	}
}
