package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.Remote;

import com.sistemas.presys.shared.datatypes.DTCliente;

@Remote
public interface IManejadorClientesEJB {

	public DTCliente agregarCliente(String codigo, String nombre, String email, String direccion,
            String rut, String telefono, String contactoNombre, String contactoEmail, String contactoTelefono,
            String codigoSegmento) throws Exception;
	
	public ArrayList<DTCliente> obtenerClientes();
	
	public void eliminarCliente(String codigo);
	
	public DTCliente obtenerClientePorCodigo(String codigo);

	public DTCliente modificarCliente(String codigo, String nombre,
			String email, String direccion, String rut, String telefono,
			String contactoNombre, String contactoEmail, String contactoTelefono,
			String codigoSegmento);

	public ArrayList<DTCliente> buscarClientes(Integer buscarPor, String cadena);
	
}
