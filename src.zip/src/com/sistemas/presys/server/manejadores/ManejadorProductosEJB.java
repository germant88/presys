package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.model.Producto;
import com.sistemas.presys.server.persistencia.ICorrelativoDAO;
import com.sistemas.presys.server.persistencia.IProductoDAO;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ManejadorProductosEJB implements IManejadorProductosEJB{

	@EJB
	IProductoDAO productoDAO;
	
	@EJB
	ICorrelativoDAO correlativoDAO;
	
	@Override
	public ArrayList<DTProducto> obtenerProductos() {
		ArrayList<DTProducto> resultado = new ArrayList<DTProducto>();
		
		List<Producto> listaProductos;
        
		listaProductos = productoDAO.obtenerTodos();
		
		cargarListaDTProductos(resultado, listaProductos);
		
		return resultado;
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void agregar(String xcodigo, String xnombre, String xdescripcion) throws LogicException{
		Producto producto = new Producto(xcodigo, xnombre, xdescripcion, true);
		
		Producto productoAux = productoDAO.obtenerPorCodigo(xcodigo);
		
		if (productoAux != null) {
			throw new LogicException("Ya existe un producto con codigo: " + xcodigo);
		}
	
		productoDAO.agregar(producto);
		
		correlativoDAO.actualizarCorrelativo(Ctes.K_CORR_PROD);		
	}
	
	
	
	
	
	// METODOS AUXILIARES
	
	private void cargarListaDTProductos(ArrayList<DTProducto> resultado,
			                            List<Producto> listaProductos) {

		for (int i = 0; i < listaProductos.size(); i ++) {
			
			DTProducto dtProducto = obtenerDTProductoAPartirDeProducto(listaProductos.get(i));
			
			resultado.add(dtProducto);
		}	
	}

	private DTProducto obtenerDTProductoAPartirDeProducto(Producto producto) {			
			DTProducto resultado = new  DTProducto();
			
			resultado.setCodigo(producto.getCodigo());
			resultado.setNombre(producto.getNombre());
			resultado.setDescripcion(producto.getDescripcion());
			resultado.setHabilitado(producto.getHabilitado());
								
			return resultado;
	}

	@Override
	public void eliminar(String xcodigo) {
       productoDAO.eliminar(xcodigo);		
	}

	
	public void modificar (String codigo, String nombre, String descripcion, Boolean habilitado) {
		
		Producto producto = new Producto(codigo, nombre, descripcion, habilitado);
		
		productoDAO.modificarProducto(producto);		
	}

	@Override
	public ArrayList<DTProducto> buscar(Integer buscarPor, String cadena) {
       
	   ArrayList<DTProducto> resultado = new ArrayList<DTProducto>();
	
       List<Producto> listaProductos = productoDAO.buscar(buscarPor, cadena);  
	
       cargarListaDTProducto(resultado, listaProductos);
	
       return resultado;
	}
	
	private void cargarListaDTProducto(ArrayList<DTProducto> resultado,
			List<Producto> listaProductos) {

		for (int i = 0; i < listaProductos.size(); i ++) {
			
			DTProducto dtProducto = obtenerDTProductoAPartirDeProducto(listaProductos.get(i));
			
			resultado.add(dtProducto);
		}
		
	}

	@Override
	public DTProducto obtenerPorCodigo(String xcodigoProducto) {
        Producto producto = productoDAO.obtenerPorCodigo(xcodigoProducto);
		
		DTProducto dtProducto = obtenerDTProductoAPartirDeProducto(producto);
		
		return dtProducto;
	}
	

}
