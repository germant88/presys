package com.sistemas.presys.server.manejadores;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.sistemas.presys.server.model.Correlativo;
import com.sistemas.presys.server.persistencia.ICorrelativoDAO;

@Stateless
public class ManejadorCorrelativosEJB implements IManejadorCorrelativosEJB {

@EJB
ICorrelativoDAO correlativoDAO;
	
	
	
	public String obtenerProximoCorrelativo(String codigo){
		Correlativo c;
		
		c = correlativoDAO.ObtenerPorCodigo(codigo);
		
		return c.getSiguiente();
	}
	
}
