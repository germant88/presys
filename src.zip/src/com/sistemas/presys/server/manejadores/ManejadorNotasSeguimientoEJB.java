package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.sistemas.presys.server.model.NotaSeguimiento;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.server.model.Usuario;
import com.sistemas.presys.server.persistencia.ICorrelativoDAO;
import com.sistemas.presys.server.persistencia.INotaSeguimientoDAO;
import com.sistemas.presys.server.persistencia.ISolicitudDAO;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.excepciones.LogicException;

@Stateless
public class ManejadorNotasSeguimientoEJB implements IManejadorNotasSeguimientoEJB{

@EJB
INotaSeguimientoDAO notaSeguimeintoDAO;

@EJB
ISolicitudDAO solicitudDAO;

@EJB
ICorrelativoDAO correlativoDAO;

public void agregar(Integer numeroNotaSeguimiento, String nota, Date fechaSeguimiento, SolicitudPresupuesto solicitudPresupuesto, Usuario usuario, String situacion) throws LogicException {
	NotaSeguimiento notaSeguimiento = new NotaSeguimiento(numeroNotaSeguimiento, nota, fechaSeguimiento, usuario, solicitudPresupuesto, new Date(), situacion);

	notaSeguimeintoDAO.agregar(notaSeguimiento);		
}

public List<DTNotaSeguimiento> obtenerNotasSeguimientoDeSolicitud(PK_SolicitudPresupuesto clave){
	List<DTNotaSeguimiento> listaDTNotas = new ArrayList<DTNotaSeguimiento>();
	
	List<NotaSeguimiento> listaNotas = notaSeguimeintoDAO.obtenerNotasDeSolicitud(clave);
	
	for (NotaSeguimiento nota : listaNotas) {
		listaDTNotas.add(obtenerDTAPartirDeNotaSeguimiento(nota));
	}
	
	return listaDTNotas;
}

public DTNotaSeguimiento obtenerDTAPartirDeNotaSeguimiento(NotaSeguimiento nota) {
	DTNotaSeguimiento dtnota = new DTNotaSeguimiento();
	dtnota.setNumeroNotaSeguimiento(nota.getPkNotaSeguimiento().getNumeroNotaSeguimiento());
	dtnota.setDescripcion(nota.getDescripcion());
	dtnota.setFechaSeguimiento(nota.getFechaSeguimiento());
	dtnota.setFechaIngreso(nota.getFechaIngreso());
	dtnota.setSituacion(nota.getSituacion());
	dtnota.setUsuario(nota.getUsuario().getUsuario_id());
	return dtnota;
}

	
}