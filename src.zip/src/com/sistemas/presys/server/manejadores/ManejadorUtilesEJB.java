package com.sistemas.presys.server.manejadores;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

@Stateless
public class ManejadorUtilesEJB implements IManejadorUtilesEJB {

@Resource
   SessionContext ctx;
	
	@Override
	public String obtenerCodigoUsuarioLogueado() throws Exception {				
		return ctx.getCallerPrincipal().getName();
	}

	@Override
	public void cerrarSesion() {
      		
	}
	
	

}
