package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.persistencia.IGarantiaDAO;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.Garantia;

@Stateless
public class ManejadorGarantiasEJB implements IManejadorGarantiasEJB{
    @EJB
    IGarantiaDAO garantiaDAO;

	@Override
	public ArrayList<Garantia> obtenerGarantias() {
	      ArrayList<Garantia> resultado = new ArrayList<Garantia>();
          
		  resultado = (ArrayList<Garantia>) garantiaDAO.obtenerTodos();
			    		
		  return resultado;
	}
	

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	@Override
	public void agregar(String xcodigo, String xnombre, Integer anios,
			Integer meses, Integer dias) throws LogicException {
        Garantia garantia = new Garantia(xcodigo, xnombre, anios, meses, dias);
		
        Garantia garantiaAux = garantiaDAO.obtenerPorCodigo(xcodigo);
		
		if (garantiaAux != null) {
			throw new LogicException("Ya existe una forma de pago con codigo: " + xcodigo);
		}
	
		garantiaDAO.agregar(garantia);		
	}

	@Override
	public void eliminar(String xcodigo) {
		garantiaDAO.eliminar(xcodigo);			
	}

	@Override
	public void modificar(String xcodigo, String xnombre, Integer anios,
			Integer meses, Integer dias) {
		Garantia garantia = new Garantia(xcodigo, xnombre, anios, meses, dias);		
		garantiaDAO.modificar(garantia);				  
	}

	@Override
	public ArrayList<Garantia> buscar(Integer buscarPor, String cadena) {
		ArrayList<Garantia> listaGarantias = (ArrayList<Garantia>) garantiaDAO.buscar(buscarPor, cadena);
		return listaGarantias;
	}

	@Override
	public Garantia obtenerPorCodigo(String xcodigo) {
		Garantia garantia = garantiaDAO.obtenerPorCodigo(xcodigo);
		
		return garantia;
	}
    	
}
