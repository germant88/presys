package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.sistemas.presys.server.model.Rol;
import com.sistemas.presys.server.persistencia.IRolesDAO;
import com.sistemas.presys.shared.datatypes.DTRol;

@Stateless
public class ManejadorRolesEJB implements IManejadorRolesEJB{

	@EJB
	IRolesDAO rolesDAO;
	
	@Override
	public ArrayList<DTRol> obtenerRoles() {
	
		ArrayList<DTRol> resultado = new ArrayList<DTRol>();
		
		List<Rol> listaRoles;
        
		listaRoles = rolesDAO.obtenerRoles();
		
		cargarListaDTRoles(resultado, listaRoles);
		
		return resultado;
	}
	
	public ArrayList<DTRol> obtenerRolesDeUsuario(String codigoUsuario){
        ArrayList<DTRol> resultado = new ArrayList<DTRol>();
		
		List<Rol> listaRoles;
        
		//listaRoles = rolesDAO.obtenerRolesDeUsuario(codigoUsuario);
		
	//	cargarListaDTRoles(resultado, listaRoles);
		
		return resultado;
	}

	private void cargarListaDTRoles(ArrayList<DTRol> resultado,
			List<Rol> listaRoles) {
       
		for (int i = 0; i < listaRoles.size(); i ++) {
			
			DTRol dtRol = obtenerDTRolAPartirDeRol(listaRoles.get(i));
			
			resultado.add(dtRol);
		}		
	}

	public DTRol obtenerDTRolAPartirDeRol(Rol rol) {
		DTRol resultado = new  DTRol();
		
		resultado.setId(rol.getRol_id());
		resultado.setNombre(rol.getRol_nombre());		
							
		return resultado;
	}

	@Override
	public Rol obtenerRolPorCodigo(String id) {		
		return rolesDAO.obtenerPorCodigo(id);
	}

}
