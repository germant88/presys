package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.model.Cliente;
import com.sistemas.presys.server.model.Edificio;
import com.sistemas.presys.server.persistencia.IClienteDAO;
import com.sistemas.presys.server.persistencia.ICorrelativoDAO;
import com.sistemas.presys.server.persistencia.IEdificioDAO;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ManejadorEdificiosEJB implements IManejadorEdificiosEJB{
    @EJB
    IEdificioDAO edificioDAO;
    
    @EJB
    ICorrelativoDAO  correlativoDAO;
	
    @EJB
    IClienteDAO clienteDAO;
    
    @EJB
    IManejadorClientesEJB manCliente;
	
	@Override
	public ArrayList<DTEdificio> obtenerEdificios() {
	      ArrayList<DTEdificio> resultado = new ArrayList<DTEdificio>();
			
		  List<Edificio> listaEdificios;
        
		  listaEdificios = edificioDAO.obtenerTodos();
		
	      cargarListaDTEdificios(resultado, listaEdificios);
		
		  return resultado;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	@Override
	public void agregar(String xcodigo, String xnombre, String xdireccion, String xcodigoCliente)
			throws LogicException {
        
		Cliente cliente = clienteDAO.obtenerPorCodigo(xcodigoCliente);
		
		Edificio edificio = new Edificio(xcodigo, xnombre, xdireccion, cliente);
		
        Edificio edificioAux = edificioDAO.obtenerPorCodigo(xcodigo);
		
		if (edificioAux != null) {
			throw new LogicException("Ya existe un edificio con codigo: " + xcodigo);
		}
	
		edificioDAO.agregar(edificio);
		
		correlativoDAO.actualizarCorrelativo(Ctes.K_CORR_EDI);
	}

	@Override
	public void eliminar(String xcodigo) {
		edificioDAO.eliminar(xcodigo);		
	}

	@Override
	public void modificar(String xcodigo, String xnombre, String xdireccion, String xcodigoCliente) {
       
	   Cliente cliente = clienteDAO.obtenerPorCodigo(xcodigoCliente);
	   Edificio edificio = new Edificio(xcodigo, xnombre, xdireccion, cliente);		
	   edificioDAO.modificarEdificio(edificio);		
	}

	@Override
	public ArrayList<DTEdificio> buscar(Integer buscarPor, String cadena) {
		  ArrayList<DTEdificio> resultado = new ArrayList<DTEdificio>();
			
	      List<Edificio> listaEdificios = edificioDAO.buscar(buscarPor, cadena);  
		
	      cargarListaDTEdificios(resultado, listaEdificios);
		
	      return resultado;
	}

	@Override
	public DTEdificio obtenerPorCodigo(String xcodigo) {
        Edificio edificio = edificioDAO.obtenerPorCodigo(xcodigo);
		
		DTEdificio dtEdificio = obtenerDTEdificioAPartirDeEdificio(edificio);
		
		return dtEdificio;
	}
	
	private void cargarListaDTEdificios(ArrayList<DTEdificio> resultado,
            List<Edificio> listaEdificios) {

		for (int i = 0; i < listaEdificios.size(); i ++) {
		
		DTEdificio dtEdificio = obtenerDTEdificioAPartirDeEdificio(listaEdificios.get(i));
		
		resultado.add(dtEdificio);
		}	
	}

	private DTEdificio obtenerDTEdificioAPartirDeEdificio(Edificio edificio) {			
		DTEdificio resultado = new  DTEdificio();
		
		resultado.setCodigo(edificio.getCodigo());
		resultado.setNombre(edificio.getNombre());
		resultado.setDireccion(edificio.getDireccion());
		
		if ( edificio.getCliente() != null) {					
			   DTCliente cliente = manCliente.obtenerClientePorCodigo(edificio.getCliente().getCodigo());
			   resultado.setCliente(cliente);
			}
				
		return resultado;
	}

	@Override
	public ArrayList<DTEdificio> obtenerEdificiosDeCliente(String codigoCliente) {
		ArrayList<DTEdificio> resultado = new ArrayList<DTEdificio>();
		
        List<Edificio> listaEdificios;
      
	    listaEdificios = edificioDAO.obtenerEdificiosDeCliente(codigoCliente);
		
	    cargarListaDTEdificios(resultado, listaEdificios);
		
		return resultado;	   
	}

	@Override
	public ArrayList<DTEdificio> buscarEdificioDeCliente(Integer buscarPor,
			String text, String codigoCliente) {
		  ArrayList<DTEdificio> resultado = new ArrayList<DTEdificio>();
			
	      List<Edificio> listaEdificios = edificioDAO.buscarEdificioDeCliente(buscarPor, text, codigoCliente);  
		
	      cargarListaDTEdificios(resultado, listaEdificios);
		
	      return resultado; 		
	}	
}
