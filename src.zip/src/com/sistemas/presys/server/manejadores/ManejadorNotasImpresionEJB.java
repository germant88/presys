package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.sistemas.presys.server.model.NotaImpresion;
import com.sistemas.presys.server.model.NotaImpresionPresupuesto;
import com.sistemas.presys.server.persistencia.INotaImpresionDAO;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.excepciones.LogicException;

@Stateless
public class ManejadorNotasImpresionEJB implements IManejadorNotasImpresionEJB{

	@EJB
	INotaImpresionDAO notaImpresionDAO;
	
	@Override
	public ArrayList<DTNotaImpresion> obtenerNotas() {
        ArrayList<DTNotaImpresion> resultado = new ArrayList<DTNotaImpresion>();

        List<NotaImpresion> listaNotasImpresion;
        
        listaNotasImpresion = notaImpresionDAO.obtenerTodos();
        
	    cargarListaDTNotasImpresion(resultado, listaNotasImpresion);
		
		return resultado;
						
	}

	@Override
	public void agregar(String xcodigo, String xnombre, String xdescripcion)
			throws LogicException {
        NotaImpresion notaImpresion = new NotaImpresion(xcodigo, xnombre, xdescripcion);
		
		NotaImpresion notaImpresionAux = notaImpresionDAO.obtenerPorCodigo(xcodigo);
		
		if (notaImpresionAux != null) {
			throw new LogicException("Ya existe una nota de impresion con codigo: " + xcodigo);
		}
	
		notaImpresionDAO.agregar(notaImpresion);						
	}

	@Override
	public void eliminar(String xcodigo) {
		notaImpresionDAO.eliminar(xcodigo);		
	}

	@Override
	public void modificar(String codigo, String nombre, String descripcion) {
        NotaImpresion notaImpresion = new NotaImpresion(codigo, nombre, descripcion);
		
		notaImpresionDAO.modificarNotaImpresion(notaImpresion);		
	}

	@Override
	public ArrayList<DTNotaImpresion> buscar(Integer buscarPor, String cadena) {
		   ArrayList<DTNotaImpresion> resultado = new ArrayList<DTNotaImpresion>();
			
	       List<NotaImpresion> listaNotasImpresion = notaImpresionDAO.buscar(buscarPor, cadena);  
			
	       cargarListaDTNotasImpresion(resultado, listaNotasImpresion);
		
	       return resultado;
	}

	@Override
	public DTNotaImpresion obtenerPorCodigo(String xcodigo) {
        NotaImpresion notaImpresion = notaImpresionDAO.obtenerPorCodigo(xcodigo);
		
		DTNotaImpresion dtNotaImpresion = obtenerDTNotaImpresionAPartirDeNotaImpresion(notaImpresion);
		
		return dtNotaImpresion;
	}
		
	// METODOS AUXILIARES
	private void cargarListaDTNotasImpresion(ArrayList<DTNotaImpresion> resultado,
			List<NotaImpresion> listaNotasImpresion) {

		for (int i = 0; i < listaNotasImpresion.size(); i ++) {
			
			DTNotaImpresion dtNotaImpresion = obtenerDTNotaImpresionAPartirDeNotaImpresion(listaNotasImpresion.get(i));
			
			resultado.add(dtNotaImpresion);
		}		
	}
	
	private DTNotaImpresion obtenerDTNotaImpresionAPartirDeNotaImpresion(NotaImpresion notaImpresion) {			
		DTNotaImpresion resultado = new DTNotaImpresion();
		
		resultado.setCodigo(notaImpresion.getCodigo());
		resultado.setNombre(notaImpresion.getNombre());
		resultado.setDescripcion(notaImpresion.getDescripcion());		
							
		return resultado;
}

	/*@Override
	public List<DTNotaImpresionPresupuesto> obtenerNotasImpresionDePresupuesto(String codigo) {
		List<DTNotaImpresionPresupuesto> listaDTNotas = new ArrayList<DTNotaImpresionPresupuesto>();
		
		List<NotaImpresionPresupuesto> listaNotas = notaImpresionDAO.obtener);
		
		for (NotaImpresion nota : listaNotas) {
			listaDTNotas.add(obtenerDTNotaImpresionAPartirDeNotaImpresion(nota));
		}
		
		return listaDTNotas;
	}*/

}
