package com.sistemas.presys.server.manejadores;

import javax.ejb.Remote;

@Remote
public interface IManejadorUtilesEJB {

	public String obtenerCodigoUsuarioLogueado() throws Exception;

	public void cerrarSesion();
}
