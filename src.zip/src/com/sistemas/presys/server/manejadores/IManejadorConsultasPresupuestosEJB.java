package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;

@Remote
public interface IManejadorConsultasPresupuestosEJB {

	public ArrayList<DTGridPresupuesto> obtenerListaDTGridPresupuestos(Date fechaDesde, Date fechaHasta, String codigo, ArrayList<Integer> xestados, ArrayList<String> xtiposDocumentos, String xcliente, String xedificio, String xproducto);
	
	public ArrayList<DTGridPresupuesto> obtenerDocumentosOrigenDeDocumento(PK_SolicitudPresupuesto claveDocumento);
	
	public ArrayList<DTGridPresupuesto> obtenerDocumentosDestinoDeDocumento(PK_SolicitudPresupuesto claveDocumento);
}