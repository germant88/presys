package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.server.persistencia.IConsultasPresupuestosDAO;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ManejadorConsultasPresupuestosEJB implements IManejadorConsultasPresupuestosEJB{

	@EJB
	IConsultasPresupuestosDAO consultasPresupuestoDAO;
	
	@EJB
	IManejadorClientesEJB manejadorClientesEJB;
	
	@EJB
	IManejadorEdificiosEJB manejadorEdificiosEJB;
	
	@EJB
	IManejadorSolicitudesPresupuestosEJB manejadorSolicitudesPresupuestosEJB;
	
	public ArrayList<DTGridPresupuesto> obtenerListaDTGridPresupuestos(Date fechaDesde, Date fechaHasta, String codigo, ArrayList<Integer> xestados, ArrayList<String> xtiposDocumentos, String xcliente, String xedificio, String xproducto) {
		List<Object>  listaResultados = consultasPresupuestoDAO.obtenerListaPresupuestos(fechaDesde, fechaHasta, codigo, xestados, xtiposDocumentos, xcliente, xedificio, xproducto);
		
        ArrayList<DTGridPresupuesto> listaResultado = new ArrayList<DTGridPresupuesto>();
		
		for (Object o : listaResultados) {
			Object[] unResultado = (Object[]) o;
			String id              = (String) unResultado[0];	
			Date   fecha           = (Date)   unResultado[1];
			String usuarioAsignado = (String) unResultado[2];
			String cliente         = (String) unResultado[3];
			String edificio        = (String) unResultado[4];
			String detalles        = (String) unResultado[5];
			Integer estado         = null;			
			if (unResultado[6] != null) {
				estado = (Integer) unResultado[6];
			}
			Date fechaSeguimiento = (Date) unResultado[7];
			String tipoDocumento = (String) unResultado[8];
			
			
		DTCliente dtCliente = manejadorClientesEJB.obtenerClientePorCodigo(cliente);
		
		String nombreCliente = "";
		
		if (dtCliente != null) {
	       nombreCliente = dtCliente.getNombre();			
		}
		
		DTEdificio dtEdificio = manejadorEdificiosEJB.obtenerPorCodigo(edificio);
		
		String nombreEdificio = "";
		
		if (dtEdificio != null) {
			nombreEdificio = dtEdificio.getNombre();
		}
		
		String nombreEstado = "";
		
		if (estado == Ctes.K_ESTADO_SOLICITUD_PENDIENTE) {
		   nombreEstado = "Pendiente";	
		}
		else if (estado == Ctes.K_ESTADO_SOLICITUD_PRESUPUESTADA) {
		   nombreEstado = "Presupuestada";
		}
		else if (estado == Ctes.K_ESTADO_PRESUPUESTO_MODIFICADO) {
		   nombreEstado = "Modificado";	
		}
		else if (estado == Ctes.K_ESTADO_PRESUPUESTO_CANCELADO) {
			nombreEstado = "Cancelado";
		}
		else if (estado == Ctes.K_ESTADO_PRESUPUESTO_GANADO) {
			nombreEstado = "Ganado";
		} 
		else if (estado == Ctes.K_ESTADO_PRESUPUESTO_PERDIDO) {
			nombreEstado = "Perdido";
		}
		String nombreTipoDocumento = "";
		
		if (tipoDocumento != null) {
			if (tipoDocumento.equals("PRESUP")) {
				nombreTipoDocumento = "Presupuesto";
			}
			else {
				nombreTipoDocumento = "Solicitud";
			}
		}
		DTGridPresupuesto dtGridPresupuesto = new DTGridPresupuesto(id, fecha, nombreCliente, nombreEdificio, estado, fechaSeguimiento, nombreEstado, tipoDocumento, nombreTipoDocumento);
		
		listaResultado.add(dtGridPresupuesto);
		
		}
		return listaResultado;
	}
	
	public ArrayList<DTGridPresupuesto> obtenerDocumentosOrigenDeDocumento(PK_SolicitudPresupuesto claveDocumento) {
	   ArrayList<DTGridPresupuesto> listaDocumentosOrigen = new ArrayList<DTGridPresupuesto> ();
	   	   	   
	   return obtenerDocumentosOrigenDeDocumentoAux(claveDocumento, listaDocumentosOrigen);		 	   	   					   
	}

	private ArrayList<DTGridPresupuesto> obtenerDocumentosOrigenDeDocumentoAux(PK_SolicitudPresupuesto claveDocumento, ArrayList<DTGridPresupuesto> listaDocumentosOrigen) {
       
		DTSolicitudPresupuesto documento = manejadorSolicitudesPresupuestosEJB.obtenerPorCodigo(claveDocumento);              
       
		if (documento.getSolicitudPresupuestoOrigen() == null) {
    	   return listaDocumentosOrigen;    		       	   
        }
		else {
			
			String nombreEstado = "";
			
			if (documento.getSolicitudPresupuestoOrigen().getEstado() == Ctes.K_ESTADO_SOLICITUD_PENDIENTE) {
			   nombreEstado = "Pendiente";	
			}
			else if (documento.getSolicitudPresupuestoOrigen().getEstado() == Ctes.K_ESTADO_SOLICITUD_PRESUPUESTADA) {
			   nombreEstado = "Presupuestada";
			}
			else if (documento.getSolicitudPresupuestoOrigen().getEstado() == Ctes.K_ESTADO_PRESUPUESTO_MODIFICADO) {
			   nombreEstado = "Modificado";	
			}
			
			String nombreTipoDocumento = "";
			
			if (documento.getSolicitudPresupuestoOrigen().getTipoDocumento() != null) {
				if (documento.getSolicitudPresupuestoOrigen().getTipoDocumento().equals("PRESUP")) {
					nombreTipoDocumento = "Presupuesto";
				}
				else {
					nombreTipoDocumento = "Solicitud";
				}
			}
			
			DTGridPresupuesto dtGridDocumentoOrigen = new DTGridPresupuesto(documento.getSolicitudPresupuestoOrigen().getCodigo(), documento.getSolicitudPresupuestoOrigen().getFecha(), documento.getSolicitudPresupuestoOrigen().getCliente().getNombre(), documento.getSolicitudPresupuestoOrigen().getEdificio().getNombre(), documento.getSolicitudPresupuestoOrigen().getEstado(), documento.getSolicitudPresupuestoOrigen().getFechaSeguimiento(), nombreEstado, documento.getSolicitudPresupuestoOrigen().getTipoDocumento(), nombreTipoDocumento);
			
			listaDocumentosOrigen.add(dtGridDocumentoOrigen);
		    
           PK_SolicitudPresupuesto claveDocumentoOrigen;
           claveDocumentoOrigen = new PK_SolicitudPresupuesto();
           claveDocumentoOrigen.setCodigo(documento.getSolicitudPresupuestoOrigen().getCodigo());
           claveDocumentoOrigen.setTipodocumento(documento.getSolicitudPresupuestoOrigen().getTipoDocumento());
           			
			return obtenerDocumentosOrigenDeDocumentoAux(claveDocumentoOrigen, listaDocumentosOrigen);	
		}		
	}
	
	public ArrayList<DTGridPresupuesto> obtenerDocumentosDestinoDeDocumento(PK_SolicitudPresupuesto claveDocumento){
		ArrayList<DTGridPresupuesto> listaDocumentosDestino = new ArrayList<DTGridPresupuesto> ();				
				
		DTSolicitudPresupuesto documento = manejadorSolicitudesPresupuestosEJB.obtenerPorCodigo(claveDocumento);
		
		return obtenerDocumentosDestinoDeDocumentoAux(claveDocumento, listaDocumentosDestino);
		
	}

	private ArrayList<DTGridPresupuesto> obtenerDocumentosDestinoDeDocumentoAux(PK_SolicitudPresupuesto claveDocumento,
			ArrayList<DTGridPresupuesto> listaDocumentosDestino) {
       
        SolicitudPresupuesto documentoDestino = consultasPresupuestoDAO.obtenerDocumentoPadreDeDocumento(claveDocumento);
        
        if (documentoDestino != null) {
        	DTSolicitudPresupuesto dtDocumentoDestino = manejadorSolicitudesPresupuestosEJB.obtenerPorCodigo(documentoDestino.getPkSolicitudPresupuesto());
        	

        	String nombreEstado = "";
			
			if (dtDocumentoDestino.getEstado() == Ctes.K_ESTADO_SOLICITUD_PENDIENTE) {
			   nombreEstado = "Pendiente";	
			}
			else if (dtDocumentoDestino.getEstado() == Ctes.K_ESTADO_SOLICITUD_PRESUPUESTADA) {
			   nombreEstado = "Presupuestada";
			}
			else if (dtDocumentoDestino.getEstado() == Ctes.K_ESTADO_PRESUPUESTO_MODIFICADO) {
			   nombreEstado = "Modificado";	
			}
			
			String nombreTipoDocumento = "";
			
			if (dtDocumentoDestino.getSolicitudPresupuestoOrigen().getTipoDocumento() != null) {
				if (dtDocumentoDestino.getTipoDocumento().equals("PRESUP")) {
					nombreTipoDocumento = "Presupuesto";
				}
				else {
					nombreTipoDocumento = "Solicitud";
				}
			}
			
			DTGridPresupuesto dtGridDocumentoDestino = new DTGridPresupuesto(dtDocumentoDestino.getCodigo(), dtDocumentoDestino.getFecha(), dtDocumentoDestino.getCliente().getNombre(), dtDocumentoDestino.getEdificio().getNombre(), dtDocumentoDestino.getEstado(), dtDocumentoDestino.getFechaSeguimiento(), nombreEstado, dtDocumentoDestino.getTipoDocumento(), nombreTipoDocumento);
			
			listaDocumentosDestino.add(dtGridDocumentoDestino);
			 
			PK_SolicitudPresupuesto claveDocumentoDestino;
			claveDocumentoDestino = new PK_SolicitudPresupuesto();
			claveDocumentoDestino.setCodigo(dtGridDocumentoDestino.getId());
			claveDocumentoDestino.setTipodocumento(dtGridDocumentoDestino.getTipoDoc());
			
			
			return obtenerDocumentosDestinoDeDocumentoAux(claveDocumentoDestino, listaDocumentosDestino);
        	
        }
        else {
           return listaDocumentosDestino;	
        }
						
	}
}
