package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Rol;
import com.sistemas.presys.shared.datatypes.DTRol;

@Remote
public interface IManejadorRolesEJB {

	public ArrayList<DTRol> obtenerRoles();

	public Rol obtenerRolPorCodigo(String id);
	
	public ArrayList<DTRol> obtenerRolesDeUsuario(String codigoUsuario);
	
	public DTRol obtenerDTRolAPartirDeRol(Rol rol);
	
}
