package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.model.Cliente;
import com.sistemas.presys.server.model.Segmento;
import com.sistemas.presys.server.persistencia.IClienteDAO;
import com.sistemas.presys.server.persistencia.ICorrelativoDAO;
import com.sistemas.presys.server.persistencia.ISegmentoDAO;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ManejadorClientesEJB implements IManejadorClientesEJB {

@EJB
IClienteDAO clienteDAO;

@EJB	
ISegmentoDAO segmentoDAO;


@EJB
ICorrelativoDAO correlativoDAO;

@EJB
IManejadorSegmentosEJB manSegmentos;

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public DTCliente agregarCliente(String codigo, String nombre, String email, String direccion,
            String rut, String telefono, String contactoNombre, String contactoEmail, String contactoTelefono,
            String codigoSegmento) throws LogicException{

        Segmento segmento = segmentoDAO.obtenerPorCodigo(codigoSegmento);
    	
    	Cliente cliente = new Cliente(codigo, nombre, email, direccion, rut, telefono, contactoNombre, contactoEmail, contactoTelefono, segmento);

		Cliente cliAux = clienteDAO.obtenerPorCodigo(codigo);
		
		if (cliAux != null) {
			throw new LogicException("Ya existe un cliente con codigo: " + codigo);
		}
		
		clienteDAO.agergarCliente(cliente);
		
		correlativoDAO.actualizarCorrelativo(Ctes.K_CORR_CLI);
		
		DTCliente dtCliente = new  DTCliente();
		dtCliente.setCodigo(codigo);
		dtCliente.setNombre(nombre);
		dtCliente.setDireccion(direccion);
		dtCliente.setEmail(email);
		return dtCliente;	
	}
	 
	public ArrayList<DTCliente> obtenerClientes(){
		ArrayList<DTCliente> resultado = new ArrayList<DTCliente>();
		
		List<Cliente> listaClientes = clienteDAO.obtenerClientes();  
		
        cargarListaDTClientes(resultado, listaClientes);
		
		return resultado;
	}
	
	public void eliminarCliente(String codigo){
		
		
		clienteDAO.eliminarCliente(codigo);
	}
	
	public DTCliente obtenerClientePorCodigo(String codigo) {
		Cliente cliente = clienteDAO.obtenerPorCodigo(codigo);
		
		DTCliente dtCliente = obtenerDTClienteAPartirDeCliente(cliente);
		
		return dtCliente;
	}

	private void cargarListaDTClientes(ArrayList<DTCliente> resultado,
			List<Cliente> listaClientes) {

		for (int i = 0; i < listaClientes.size(); i ++) {
			
			DTCliente dtCliente = obtenerDTClienteAPartirDeCliente(listaClientes.get(i));
			
			resultado.add(dtCliente);
		}
		
	}

	private DTCliente obtenerDTClienteAPartirDeCliente(Cliente cliente) {
		
		DTCliente resultado = new  DTCliente();
		
		resultado.setCodigo(cliente.getCodigo());
		resultado.setNombre(cliente.getNombre());
		resultado.setEmail(cliente.getEmail());
		resultado.setDireccion(cliente.getDireccion());
		resultado.setRut(cliente.getRut());
		resultado.setTelefono(cliente.getTelefono());
		resultado.setContactoEmail(cliente.getContactoEmail());
		resultado.setContactoNombre(cliente.getContactoNombre());
		resultado.setContactoTelefono(cliente.getContactoTelefono());		
		if ( cliente.getSegmento() != null) {					
		   DTSegmento segmento = manSegmentos.obtenerPorCodigo(cliente.getSegmento().getCodigo());
		   resultado.setSegmento(segmento);
		}
		
		return resultado;
	}

	@Override
	public DTCliente modificarCliente(String codigo, String nombre,
			String email, String direccion, String rut, String telefono,
			String contactoNombre, String contactoEmail, String contactoTelefono,
			String codigoSegmento) {
		
		Segmento segmento;
		segmento = segmentoDAO.obtenerPorCodigo(codigoSegmento);

		Cliente cliente = new Cliente(codigo, nombre, email, direccion, rut, telefono, contactoNombre, contactoEmail, contactoTelefono, segmento);
		
		Cliente clienteModificado = clienteDAO.modificarCliente(cliente);
		
		DTCliente dtCliente = obtenerDTClienteAPartirDeCliente(clienteModificado);
		
		return dtCliente;
	}
	
	public ArrayList<DTCliente> buscarClientes(Integer buscarPor, String cadena) {
       ArrayList<DTCliente> resultado = new ArrayList<DTCliente>();
		
	   List<Cliente> listaClientes = clienteDAO.buscarClientes(buscarPor, cadena);  
		
       cargarListaDTClientes(resultado, listaClientes);
		
	   return resultado;
	}	
}
