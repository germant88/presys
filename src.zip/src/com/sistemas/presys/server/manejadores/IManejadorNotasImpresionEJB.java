package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorNotasImpresionEJB {
    public ArrayList<DTNotaImpresion> obtenerNotas();
	
	public void agregar(String xcodigo, String xnombre, String xdescripcion)  throws LogicException;

	public void eliminar(String xcodigo); 
		
	public void modificar(String codigo, String nombre, String descripcion);

	public ArrayList<DTNotaImpresion> buscar(Integer buscarPor, String cadena);

	public DTNotaImpresion obtenerPorCodigo(String xcodigoProducto);
	
	//public List<DTNotaImpresionPresupuesto> obtenerNotasImpresionDePresupuesto(String codigo);

}
