package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import javax.ejb.Remote;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;

@Remote
public interface IManejadorFormasDePagosEJB {

	public ArrayList<FormaDePago> obtenerFormasDePago();

	public void agregar(String xcodigo, String xnombre, String xdescripcion)
			throws LogicException; 
		
	public void eliminar(String xcodigo);

	public void modificar(String xcodigo, String xnombre, String xdescripcion);
	
	public ArrayList<FormaDePago> buscar(Integer buscarPor, String cadena);
	
	public FormaDePago obtenerPorCodigo(String xcodigo);
	
}
