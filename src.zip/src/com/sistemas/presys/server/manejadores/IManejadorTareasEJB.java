package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.Remote;

import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorTareasEJB {
    public ArrayList<DTTarea> obtenerTareas();
	
	public void agregar(String xcodigo, String xnombre, String xdescripcion)  throws LogicException;

	public void eliminar(String xcodigo); 
		
	public void modificar(String codigo, String nombre, String descripcion);

	public ArrayList<DTTarea> buscar(Integer buscarPor, String cadena);

	public DTTarea obtenerPorCodigo(String xcodigoProducto);	
}
