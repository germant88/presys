package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.Remote;

import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorEdificiosEJB{

    public ArrayList<DTEdificio> obtenerEdificios();
	
	public void agregar(String xcodigo, String xnombre, String xdireccion, String xcodigoCliente)  throws LogicException;

	public void eliminar(String xcodigo); 
		
	public void modificar(String xcodigo, String xnombre, String xdireccion, String xcodigoCliente);

	public ArrayList<DTEdificio> buscar(Integer buscarPor, String cadena);

	public DTEdificio obtenerPorCodigo(String xcodigo);

	public ArrayList<DTEdificio> obtenerEdificiosDeCliente(String codigoCliente);

	public ArrayList<DTEdificio> buscarEdificioDeCliente(Integer buscarPor,
			String text, String codigoCliente);
}
