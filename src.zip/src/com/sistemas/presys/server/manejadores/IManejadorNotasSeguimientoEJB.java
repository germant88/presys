package com.sistemas.presys.server.manejadores;

import java.util.Date;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.server.model.Usuario;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorNotasSeguimientoEJB{

	public void agregar(Integer numeroNotaSeguimiento, String nota, Date fechaSeguimiento, SolicitudPresupuesto solicitudPresupuesto, Usuario usuario, String situacion) throws LogicException;
	
	public List<DTNotaSeguimiento> obtenerNotasSeguimientoDeSolicitud(PK_SolicitudPresupuesto clave);
}
