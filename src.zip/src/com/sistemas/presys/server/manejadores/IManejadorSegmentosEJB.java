package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.Remote;

import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorSegmentosEJB {
    
	public ArrayList<DTSegmento> obtenerSegmentos();
	
	public void agregar(String xcodigo, String xnombre, String xdescripcion)  throws LogicException;

	public void eliminar(String xcodigo); 
		
	public void modificar(String codigo, String nombre, String descripcion, Boolean habilitado);

	public ArrayList<DTSegmento> buscar(Integer buscarPor, String cadena);

	public DTSegmento obtenerPorCodigo(String xcodigoProducto);
	
}
