package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.NotaImpresionPresupuesto;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorSolicitudesPresupuestosEJB {

	public void agregar(String xcodigo, String xtipoDocumento, Date xfecha, String usuarioAsignado,
			            String xcodigoCliente, String xcodigoEdificio,
			            String xdetalles, Integer xestado, Date xfechaSeguimiento,
			            ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,Double total,
			            String xcodigoSolOPresOrigen, String xtipoDocumentoOrigen, ArrayList<DTRenglonPresupuesto> listaDtRenglonPresupuestos,String formaDePago, String garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
						Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
						Integer validezDias, Integer validezMeses, Integer validezAnios, 
					    ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresion) throws Exception;
	
	public DTSolicitudPresupuesto obtenerPorCodigo(PK_SolicitudPresupuesto clave);
	
	public List<DTNotaSeguimiento> obtenerNotasDeSolicitud(PK_SolicitudPresupuesto clave);
	
	public List<NotaImpresionPresupuesto> obtenerNotasDeImpresion(PK_SolicitudPresupuesto clave);

	public void modificarSolicitud(String xcodigo, String xtipoDocumento, Date xfecha,
			String xusuarioAsignado, String xcodigoCliente,
			String xcodigoEdificio, String xdetalles, Integer xestado,
			Date xfechaSeguimiento,
			ArrayList<DTNotaSeguimiento> listaNotasSeguimiento, String formaDePago, String garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
			Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios,
			ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresion) throws LogicException;
	
	public void cambiarEstadoSolicitud(PK_SolicitudPresupuesto xclave, Integer xestadoNuevo);
	
	
}
