package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.model.Cliente;
import com.sistemas.presys.server.model.Edificio;
import com.sistemas.presys.server.model.NotaImpresion;
import com.sistemas.presys.server.model.NotaImpresionPresupuesto;
import com.sistemas.presys.server.model.NotaSeguimiento;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.Producto;
import com.sistemas.presys.server.model.RenglonSolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.server.model.Tarea;
import com.sistemas.presys.server.model.TareaRenglon;
import com.sistemas.presys.server.model.Usuario;
import com.sistemas.presys.server.persistencia.IClienteDAO;
import com.sistemas.presys.server.persistencia.ICorrelativoDAO;
import com.sistemas.presys.server.persistencia.IEdificioDAO;
import com.sistemas.presys.server.persistencia.INotaImpresionDAO;
import com.sistemas.presys.server.persistencia.IProductoDAO;
import com.sistemas.presys.server.persistencia.ISolicitudDAO;
import com.sistemas.presys.server.persistencia.ITareaDAO;
import com.sistemas.presys.server.persistencia.IUsuarioDAO;
import com.sistemas.presys.server.utiles.IJasperReportsEJB;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.datatypes.DTTareaRenglon;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.model.Garantia;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ManejadorSolicitudesPresupuestosEJB implements IManejadorSolicitudesPresupuestosEJB{

	@EJB
	ISolicitudDAO solicitudDAO;

	@EJB
	IEdificioDAO manEdificios;
	
	@EJB
	IClienteDAO manClientes;
	
	@EJB
	IUsuarioDAO manUsuarios;
	
	@EJB
	IManejadorClientesEJB manejadorClientes;
	
	@EJB
	IManejadorUsuariosJEJB manejadorUsuarios;
	
	@EJB
	IManejadorEdificiosEJB manejadorEdificios;
	
	@EJB
    IManejadorFormasDePagosEJB manFormasDePago;
	
	@EJB
    IManejadorGarantiasEJB manGarantias;
	
	@EJB
	IManejadorNotasSeguimientoEJB manejadorNotasSeguimiento;
	
	@EJB
	IManejadorNotasImpresionEJB manejadorNotasImpresion;
	
	@EJB
	ICorrelativoDAO correlativoDAO;
	
	@EJB
	IProductoDAO  productosDAO;
	
	@EJB
	ITareaDAO tareasDAO;
	
	@EJB
	INotaImpresionDAO notaImpresionDAO;
	
    @EJB
    IJasperReportsEJB JasperReports;
    
    
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void agregar(String xcodigo, String xtipoDocumento, Date xfecha, String xusuarioAsignado,
            String xcodigoCliente, String xcodigoEdificio,
            String xdetalles, Integer xestado, Date xfechaSeguimiento, ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,
            Double total, String xcodigoSolOPresOrigen, String xtipoDocumentoOrigen, ArrayList<DTRenglonPresupuesto> listaDTRenglonesPresupuesto,
            String formaDePago, String garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
			Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios, ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresion) throws Exception {
		
		boolean cambiarEstadoSolicitudOPresupuesto = false;
			 		
		if ((xcodigoCliente == null) || (xcodigoCliente.trim().equals(""))) {
			throw new LogicException("El cliente ingresado no existe o no es valido: " + xcodigoCliente);
		}
	       
		Cliente cliente = manClientes.obtenerPorCodigo(xcodigoCliente);
		
		if (cliente == null) {
			throw new LogicException("El cliente ingresado no existe o no es valido: " + xcodigoCliente);
		}
		
		if ((xusuarioAsignado == null) || (xusuarioAsignado.trim().equals(""))) {
			throw new LogicException("El usuario asignado no existe o no es valido: " + xusuarioAsignado);	
		}
		
		Usuario usuario = manUsuarios.obtenerPorCodigo(xusuarioAsignado);
		
		if (usuario == null) {
			throw new LogicException("El usuario asignado no existe o no es valido: " + xusuarioAsignado);
		}
		
		if ((xcodigoEdificio == null) || (xcodigoEdificio.trim().equals(""))) {
			throw new LogicException("El edificio ingresadono no existe o no es valido: " + xcodigoEdificio);
		}
    	
		Edificio edificio = manEdificios.obtenerPorCodigo(xcodigoEdificio);
		
		if (edificio == null) {
			throw new LogicException("El edificio ingresadono no existe o no es valido: " + xcodigoEdificio);			
		}
    	    	    	    			
		ArrayList<NotaSeguimiento> notasSeguimiento = new ArrayList<NotaSeguimiento>();    	    	
    	
    	ObtenerNotaSeguimientoAPartirDeDT(notasSeguimiento, listaNotasSeguimiento, false);
    	
    	SolicitudPresupuesto solicitud = null;
    	
    	SolicitudPresupuesto solicitudOPresupuestoOrigen = null;
    	
    	if (xtipoDocumento.equals(Ctes.K_TDOC_PRESUPUESTO)) {
	    	
    		if ((formaDePago == null) || (formaDePago.trim().equals(""))) {
    			throw new LogicException("La forma de pago ingresada no existe o no es v\u00E1lida: " + formaDePago);
    		}
    		
    		FormaDePago formaDePagoAux = manFormasDePago.obtenerPorCodigo(formaDePago);
    		
    		if (formaDePagoAux == null) {
    			throw new LogicException("La forma de pago ingresada no existe o no es v\u00E1lida: " + formaDePago);
    		}
    		
    		if ((garantia == null) || (garantia.trim().equals(""))) {
    			throw new LogicException("La garant\u00EDa ingresada no existe o no es v\u00E1lida: " + garantia);
    		}
    		    		
    		Garantia garantiaAux = manGarantias.obtenerPorCodigo(garantia);
    		
    		if (garantiaAux == null) {
    			throw new LogicException("La garant\u00EDa ingresada no existe o no es v\u00E1lida: " + garantia);
    		}
    		
    		ArrayList<RenglonSolicitudPresupuesto> listaRenglones = new ArrayList<RenglonSolicitudPresupuesto>();
	    	
	    	if (listaDTRenglonesPresupuesto.size() <= 0) {
	    		throw new LogicException("Debe ingresarse al menos un rengl\u00F3n");	
	    	}
    		
    		obtenerRenglonesAPartirDeDTRenglones(listaRenglones, listaDTRenglonesPresupuesto);
    		
    		ArrayList<NotaImpresionPresupuesto> notasImpresion = new ArrayList<NotaImpresionPresupuesto>();    	    	
        	
        	ObtenerNotaImpresionAPartirDeDT(notasImpresion, listaNotasImpresion, false);
	    		    	 		    	
	    	if ((xcodigoSolOPresOrigen != null) && (xtipoDocumentoOrigen != null)) {
	    		if ((!xcodigoSolOPresOrigen.trim().equals("")) && (!xtipoDocumentoOrigen.trim().equals(""))) {
	        		PK_SolicitudPresupuesto claveDocumentoOrigen;
	        		claveDocumentoOrigen = new PK_SolicitudPresupuesto();
	        		claveDocumentoOrigen.setCodigo(xcodigoSolOPresOrigen);
	        		claveDocumentoOrigen.setTipodocumento(xtipoDocumentoOrigen);
	    			
	    			solicitudOPresupuestoOrigen = solicitudDAO.obtenerPorCodigo(claveDocumentoOrigen);
	        		if (solicitudOPresupuestoOrigen != null) {
	        			cambiarEstadoSolicitudOPresupuesto = true;	
	        		}        		
	        	}	
	    	}
	    		    	    
	    	solicitud = new SolicitudPresupuesto(xcodigo, xtipoDocumento, xfecha, usuario,
                    cliente, edificio, xdetalles, xestado, xfechaSeguimiento, notasSeguimiento,                    
                    total, solicitudOPresupuestoOrigen, listaRenglones, formaDePagoAux, garantiaAux,
                    superficie, leyesSocialesHasta, costoBQ, 
        			tiempoEjecDias, tiempoEjecMeses, tiempoEjecAnios,
        			validezDias, validezMeses, validezAnios, notasImpresion);
	    	
	    	solicitud.setRenglonesPresupuesto(listaRenglones);
	    	
	    	for (RenglonSolicitudPresupuesto renglonPresupuesto : listaRenglones) {
	    		renglonPresupuesto.getPkRenglonSolicitudPresupuesto().setSolicitudPresupuesto(solicitud);
	    	}
	    	
	    	for (NotaImpresionPresupuesto nota : notasImpresion) {
	    		nota.getPkNotaImpresionPresupuesto().setSolicitudPresupuesto(solicitud);
	    	}
	    	
    	}
    	else {
    	   if ((xdetalles == null) || (xdetalles.trim().equals(""))) {
    	      throw new LogicException("El detalle no puede ser vac\u00EDo");   
    	   }
    		
    		solicitud = new SolicitudPresupuesto(xcodigo, xtipoDocumento, xfecha, usuario,
    			                                                  cliente, edificio, xdetalles, xestado, xfechaSeguimiento, notasSeguimiento,
    			                                                  null, null, null, null,null, null,null,null, null, null, null, null, null, null,
    			                                                  null);
    	}

    	for (NotaSeguimiento notaSeg : notasSeguimiento) {
    		notaSeg.getPkNotaSeguimiento().setSolicitudPresupuesto(solicitud);
    	}
    	
    	solicitud.setNotasSeguimiento(notasSeguimiento);

		PK_SolicitudPresupuesto claveDocumentoAux;
		claveDocumentoAux = new PK_SolicitudPresupuesto();
		claveDocumentoAux.setCodigo(xcodigo);
		claveDocumentoAux.setTipodocumento(xtipoDocumento);
    	
    	SolicitudPresupuesto solicitudAux = solicitudDAO.obtenerPorCodigo(claveDocumentoAux);
				
		if (solicitudAux != null) {
			throw new LogicException("Ya existe una solicitud con codigo: " + xcodigo);
		}
			    				
	    solicitudDAO.ingresarSolicitud(solicitud);
	    
		
	    if (xtipoDocumento.equals(Ctes.K_TDOC_PRESUPUESTO)) {
	    	correlativoDAO.actualizarCorrelativo(Ctes.K_CORR_PRES);
	    }
	    else {
	       correlativoDAO.actualizarCorrelativo(Ctes.K_CORR_SOL);
	    }
		
		if (cambiarEstadoSolicitudOPresupuesto) {
			if (solicitudOPresupuestoOrigen.getPkSolicitudPresupuesto().getTipodocumento().equals(Ctes.K_TDOC_SOLICITUD)) {
				solicitudDAO.cambiarEstadoSolicitud(solicitudOPresupuestoOrigen.getPkSolicitudPresupuesto(), Ctes.K_ESTADO_SOLICITUD_PRESUPUESTADA);	
			}
			else if (solicitudOPresupuestoOrigen.getPkSolicitudPresupuesto().getTipodocumento().equals(Ctes.K_TDOC_PRESUPUESTO)) {
				solicitudDAO.cambiarEstadoSolicitud(solicitudOPresupuestoOrigen.getPkSolicitudPresupuesto(), Ctes.K_ESTADO_PRESUPUESTO_MODIFICADO);
			}			
		}
			
	}
	
	private void ObtenerNotaSeguimientoAPartirDeDT(
			ArrayList<NotaSeguimiento> notasSeguimiento,
			ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,
			Boolean CopiarCodigo) {
	
		for (DTNotaSeguimiento nota : listaNotasSeguimiento) {
		   NotaSeguimiento notaSeguimiento = new NotaSeguimiento();
		   
		   notaSeguimiento.getPkNotaSeguimiento().setNumeroNotaSeguimiento(nota.getNumeroNotaSeguimiento());		   
		   notaSeguimiento.setDescripcion(nota.getDescripcion());
		   notaSeguimiento.setFechaSeguimiento(nota.getFechaSeguimiento());
		   notaSeguimiento.setSituacion(nota.getSituacion());
		   notaSeguimiento.setFechaIngreso(new Date());
		   
		   Usuario usuario = manUsuarios.obtenerPorCodigo(nota.getUsuario());			
		   
		   notaSeguimiento.setUsuario(usuario);
		   
		   notasSeguimiento.add(notaSeguimiento);
		}		
	}
	
	private void ObtenerNotaImpresionAPartirDeDT(
			ArrayList<NotaImpresionPresupuesto> notasImpresion,
			ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresion,
			Boolean CopiarCodigo) throws LogicException {
	
		for (DTNotaImpresionPresupuesto nota : listaNotasImpresion) {
		   NotaImpresionPresupuesto notaImpresionPresupuesto = new NotaImpresionPresupuesto();
		   
		   notaImpresionPresupuesto.getPkNotaImpresionPresupuesto().setNumeroNotaImpresion(nota.getNumeroNotaImpresionPresupuesto());		   
		   notaImpresionPresupuesto.setDescripcion(nota.getDescripcion());

		   NotaImpresion notaXDef = notaImpresionDAO.obtenerPorCodigo(nota.getCodigoNotaImpresionXDefecto());
       	
	       	if(notaXDef == null) {
	       		throw new LogicException("No se pudo encontrar la tarea con codigo: " + nota.getCodigoNotaImpresionXDefecto());
	       	}
	       	
	       	notaImpresionPresupuesto.setNotaImpresionXDefecto(notaXDef);
		   
		   notasImpresion.add(notaImpresionPresupuesto);
		}		
	}
	
	private void obtenerRenglonesAPartirDeDTRenglones (ArrayList<RenglonSolicitudPresupuesto> renglonesPresupuesto,
			                                      ArrayList<DTRenglonPresupuesto> listaDTRenglonesPresupuesto) throws LogicException{			                                       
		
	    for (DTRenglonPresupuesto dtRenglon : listaDTRenglonesPresupuesto) {
		   RenglonSolicitudPresupuesto renglon = new RenglonSolicitudPresupuesto();
		   renglon.getPkRenglonSolicitudPresupuesto().setNumeroRenglon(dtRenglon.getNumeroRenglon());
		   
		   Producto producto = productosDAO.obtenerPorCodigo(dtRenglon.getProducto().getCodigo());
		   
		   if (producto == null) {
			   throw new LogicException("No se pudo encontrar el producto con codigo: " + dtRenglon.getProducto().getCodigo());
		   }
		   
		   renglon.setProducto(producto);
		   
		   renglon.setImporte(dtRenglon.getImporte());
		   renglon.setDescripcion(dtRenglon.getDescripcion());		   
		   
           for (DTTareaRenglon dtTarea : dtRenglon.getListaTareasRenglon()) {
        	TareaRenglon tarea = new TareaRenglon();
        	tarea.getPkTareaRenglon().setNumeroTarea(dtTarea.getNumeroTareaRenglon());
        	tarea.getPkTareaRenglon().setRenglonSolicitudPresupuesto(renglon);
        	tarea.setDescripcion(dtTarea.getDescripcion());
        	
        	Tarea tareaXDef = tareasDAO.obtenerPorCodigo(dtTarea.getCodigoTareaXDefecto());
        	
        	if(tareaXDef == null) {
        		throw new LogicException("No se pudo encontrar la tarea con codigo: " + dtTarea.getCodigoTareaXDefecto());
        	}
        	
        	tarea.setTareaXDefecto(tareaXDef);
        	
        	renglon.getTareasRenglon().add(tarea);
        	
           }
		   
		   renglonesPresupuesto.add(renglon);
		}			                                    	  			                                    	
	}

	public DTSolicitudPresupuesto obtenerPorCodigo(PK_SolicitudPresupuesto clave) {
		SolicitudPresupuesto solicitud = solicitudDAO.obtenerPorCodigo(clave);
		
		DTSolicitudPresupuesto dtSolicitud = obtenerDTSolicitudAPartirDeSolicitud(solicitud);
				
		
		ArrayList<DTRenglonPresupuesto> listaDTRenglones = obtenerListaDTRenglonesAPartirDeSolicitud(solicitud);
		
		dtSolicitud.setRenglonesSolicitud(listaDTRenglones);
		
		ArrayList<DTNotaImpresionPresupuesto> listaDTNotasImpresionPresupuesto = obtenerListaDTNotaImpresionPresupuestoAPartirDePresupuesto(dtSolicitud);
		
		dtSolicitud.setListaNotaImpresionPresupuesto(listaDTNotasImpresionPresupuesto);
		
		return dtSolicitud;		
	}
	
	private ArrayList<DTRenglonPresupuesto> obtenerListaDTRenglonesAPartirDeSolicitud(
			SolicitudPresupuesto solicitud) {
		
		ArrayList<DTRenglonPresupuesto> listaDTRenglones = new ArrayList<DTRenglonPresupuesto>();
		
		List<RenglonSolicitudPresupuesto> listaRenglones = this.obtenerRenglonesDeSolicitud(solicitud.getPkSolicitudPresupuesto());
						
		for (RenglonSolicitudPresupuesto unRenglon : listaRenglones) {
           
			DTRenglonPresupuesto dtRenglon = new DTRenglonPresupuesto();
			dtRenglon.setNumeroRenglon(unRenglon.getPkRenglonSolicitudPresupuesto().getNumeroRenglon());
			dtRenglon.setImporte(unRenglon.getImporte());
			
			DTProducto dtProducto = new DTProducto();
			dtProducto.setCodigo(unRenglon.getProducto().getCodigo());
			dtProducto.setNombre(unRenglon.getProducto().getNombre());
			dtProducto.setDescripcion(unRenglon.getProducto().getDescripcion());
			dtProducto.setHabilitado(unRenglon.getProducto().getHabilitado());
			
			dtRenglon.setProducto(dtProducto);
			
			DTSolicitudPresupuesto dtSolicitudPresupuesto = obtenerDTSolicitudAPartirDeSolicitud(unRenglon.getPkRenglonSolicitudPresupuesto().getSolicitudPresupuesto());
			
			dtRenglon.setPresupuesto(dtSolicitudPresupuesto);
			
			dtRenglon.setDescripcion(unRenglon.getDescripcion());
			
			List<TareaRenglon> listaTareasRenglon = obtenerTareasDeRenglon(unRenglon);
			
			if (listaTareasRenglon.size() > 0) {
			    for (TareaRenglon unaTarea : listaTareasRenglon) {
			    	DTTareaRenglon dtTareaRenglon = new DTTareaRenglon();
			    	dtTareaRenglon.setNumeroTareaRenglon(unaTarea.getPkTareaRenglon().getNumeroTarea());
			    	dtTareaRenglon.setDescripcion(unaTarea.getDescripcion());
			    	dtTareaRenglon.setRenglonSolicitudPresupuesto(dtRenglon);
			    	
			    	DTTarea tarea = new DTTarea();
			    	tarea.setCodigo(unaTarea.getTareaXDefecto().getCodigo());
			    	tarea.setDescripcion(unaTarea.getTareaXDefecto().getDescripcion());
			    	tarea.setNombre(unaTarea.getTareaXDefecto().getNombre());
			    	
			    	dtTareaRenglon.setTareaXDefecto(tarea);
			    	
			    	if (dtRenglon.getListaTareasRenglon() != null) { 
			    	   dtRenglon.getListaTareasRenglon().add(dtTareaRenglon);
			    	}
			    }
			}
			
			listaDTRenglones.add(dtRenglon);									
		}
		
		return listaDTRenglones;
	}
	
	public ArrayList<DTNotaImpresionPresupuesto> obtenerListaDTNotaImpresionPresupuestoAPartirDePresupuesto(DTSolicitudPresupuesto presupuesto) {
		PK_SolicitudPresupuesto clavePresupuesto = new PK_SolicitudPresupuesto();
		clavePresupuesto.setCodigo(presupuesto.getCodigo());
		clavePresupuesto.setTipodocumento(presupuesto.getTipoDocumento());
		
		List<NotaImpresionPresupuesto> notasImpresion = obtenerNotasDeImpresion(clavePresupuesto);
		ArrayList<DTNotaImpresionPresupuesto> listaDTNotasImpresionPresupuesto = new ArrayList<DTNotaImpresionPresupuesto>();
		
		if (notasImpresion.size() > 0) {
			for (NotaImpresionPresupuesto notaImpresionPresupuesto : notasImpresion) {
				DTNotaImpresionPresupuesto dtNotaImpresionPresupuesto = new DTNotaImpresionPresupuesto();
				dtNotaImpresionPresupuesto.setNumeroNotaImpresionPresupuesto(notaImpresionPresupuesto.getPkNotaImpresionPresupuesto().getNumeroNotaImpresion());
				dtNotaImpresionPresupuesto.setDescripcion(notaImpresionPresupuesto.getDescripcion());
				dtNotaImpresionPresupuesto.setPresupuesto(presupuesto);
				
				DTNotaImpresion dtNotaImpresion = new DTNotaImpresion();
				dtNotaImpresion.setCodigo(notaImpresionPresupuesto.getNotaImpresionXDefecto().getCodigo());
				dtNotaImpresion.setNombre(notaImpresionPresupuesto.getNotaImpresionXDefecto().getNombre());
				dtNotaImpresion.setDescripcion(notaImpresionPresupuesto.getNotaImpresionXDefecto().getDescripcion());
				
				dtNotaImpresionPresupuesto.setNotaImpresionXDefecto(dtNotaImpresion);
								
				listaDTNotasImpresionPresupuesto.add(dtNotaImpresionPresupuesto);
			}
			
		}
		return listaDTNotasImpresionPresupuesto;		
	}
	


	public List<DTNotaSeguimiento> obtenerNotasDeSolicitud(PK_SolicitudPresupuesto clave){
		return manejadorNotasSeguimiento.obtenerNotasSeguimientoDeSolicitud(clave);
	}
	
	public List<NotaImpresionPresupuesto> obtenerNotasDeImpresion(PK_SolicitudPresupuesto clave){
		List<NotaImpresionPresupuesto> notasImpresion = solicitudDAO.obtenerNotasImpresionDePresupuesto(clave);
		return notasImpresion;		
	}
	
	public List<RenglonSolicitudPresupuesto> obtenerRenglonesDeSolicitud(PK_SolicitudPresupuesto clave){
		List<RenglonSolicitudPresupuesto> renglones = solicitudDAO.obtenerRenglonesDeSolicitud(clave);
		
		return renglones;
	}
	
	public List<TareaRenglon> obtenerTareasDeRenglon(RenglonSolicitudPresupuesto xRenglon){
		List<TareaRenglon> tareasDeRenglon = solicitudDAO.obtenerTareasDeRenglon(xRenglon);
		return tareasDeRenglon;
	}
	
	
	private DTSolicitudPresupuesto obtenerDTSolicitudAPartirDeSolicitud(
			SolicitudPresupuesto solicitud) {

		DTSolicitudPresupuesto resultado = new DTSolicitudPresupuesto();
				
		resultado.setCodigo(solicitud.getPkSolicitudPresupuesto().getCodigo());
		resultado.setFecha(solicitud.getFecha());
		
		
		if (solicitud.getCliente() != null) {
			DTCliente dtCliente = manejadorClientes.obtenerClientePorCodigo(solicitud.getCliente().getCodigo());
			resultado.setCliente(dtCliente);
		}
		
		if (solicitud.getUsuarioAsignado() != null) {
			try {
				DTUsuario dtUsuario = manejadorUsuarios.obtenerPorCodigo(solicitud.getUsuarioAsignado().getUsuario_id());
				resultado.setUsuarioAsignado(dtUsuario);
			} catch (LogicException e) {
				e.printStackTrace();
			}
		}
		
		if (solicitud.getEdificio() != null) {
			DTEdificio dtEdificio = manejadorEdificios.obtenerPorCodigo(solicitud.getEdificio().getCodigo());
			resultado.setEdificio(dtEdificio);
		}
		
		resultado.setDetalles(solicitud.getDetalles());
		resultado.setEstado(solicitud.getEstado());
		resultado.setFechaSeguimiento(solicitud.getFechaSeguimiento());
		
		if (solicitud.getSolicitudOrigen() != null) {
			DTSolicitudPresupuesto origen = obtenerDTSolicitudAPartirDeSolicitud(solicitud.getSolicitudOrigen());
			
			if (origen != null){
				   resultado.setSolicitudPresupuestoOrigen(origen);
		    }
		}	
				
		resultado.setTipoDocumento(solicitud.getPkSolicitudPresupuesto().getTipodocumento());
		
		resultado.setFormaDePago(solicitud.getFormaDePago());
		
		resultado.setGarantia(solicitud.getGarantia());
		
		resultado.setSuperficie(solicitud.getSuperficie());
		
		resultado.setLeyesSociales(solicitud.getLeyesSociales());
		
		resultado.setCostoBQ(solicitud.getCostoBQ());
		
		resultado.setTiempoEjecucionDias(solicitud.getTiempoEjecucionDias());
		resultado.setTiempoEjecucionMeses(solicitud.getTiempoEjecucionMeses());
		resultado.setTiempoEjecucionAnios(solicitud.getTiempoEjecucionAnios());
		
		resultado.setValidezDias(solicitud.getValidezDias());
		resultado.setValidezMeses(solicitud.getValidezMeses());
		resultado.setValidezAnios(solicitud.getValidezAnios());
				
        return resultado;
					
	}

	@Override
	public void modificarSolicitud(String xcodigo, String xtipoDocumento, Date xfecha,
			String xusuarioAsignado, String xcodigoCliente,
			String xcodigoEdificio, String xdetalles, Integer xestado,
			Date xfechaSeguimiento,
			ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,String formaDePago, String garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
			Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios,
			ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresion) throws LogicException {       
		
		Cliente cliente = manClientes.obtenerPorCodigo(xcodigoCliente);
		
		Edificio edificio = manEdificios.obtenerPorCodigo(xcodigoEdificio);
		
		Usuario usuario = manUsuarios.obtenerPorCodigo(xusuarioAsignado);
								
		ArrayList<NotaSeguimiento> listaNotas = new ArrayList<NotaSeguimiento>();
		
		ObtenerNotaSeguimientoAPartirDeDT(listaNotas, listaNotasSeguimiento, true );
		
		
		
		
		
		if (xtipoDocumento.equals(Ctes.K_TDOC_PRESUPUESTO)) {
			
			ArrayList<NotaImpresionPresupuesto> notasImpresion = new ArrayList<NotaImpresionPresupuesto>();    	    		    	
	    	ObtenerNotaImpresionAPartirDeDT(notasImpresion, listaNotasImpresion, false);
	    	
			FormaDePago formaDePagoAux = manFormasDePago.obtenerPorCodigo(formaDePago);			
			Garantia garantiaAux = manGarantias.obtenerPorCodigo(garantia);	
		
			SolicitudPresupuesto solicitud = new SolicitudPresupuesto(xcodigo, xtipoDocumento, xfecha, usuario, cliente, edificio, xdetalles, xestado, xfechaSeguimiento, listaNotas,null, null, null, formaDePagoAux, garantiaAux, superficie, leyesSocialesHasta, costoBQ, 
					tiempoEjecDias, tiempoEjecMeses,  tiempoEjecAnios,
					 validezDias, validezMeses, validezAnios, notasImpresion);
			solicitudDAO.modificarSolicitud(solicitud);
		}
		else {
			SolicitudPresupuesto solicitud = new SolicitudPresupuesto(xcodigo, xtipoDocumento, xfecha, usuario, cliente, edificio, xdetalles, xestado, xfechaSeguimiento, listaNotas,null, null, null, null, null, superficie, leyesSocialesHasta, costoBQ, 
					tiempoEjecDias, tiempoEjecMeses,  tiempoEjecAnios,
					 validezDias, validezMeses, validezAnios, null);
			solicitudDAO.modificarSolicitud(solicitud);
		}
							
        				
	}
	
	public void cambiarEstadoSolicitud(PK_SolicitudPresupuesto xclave, Integer xestadoNuevo) {
		solicitudDAO.cambiarEstadoSolicitud(xclave, xestadoNuevo);
		
	}
	
}
