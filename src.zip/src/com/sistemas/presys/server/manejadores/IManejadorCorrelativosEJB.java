package com.sistemas.presys.server.manejadores;

import javax.ejb.Remote;

@Remote
public interface IManejadorCorrelativosEJB {

	public String obtenerProximoCorrelativo(String codigo);
	
}
