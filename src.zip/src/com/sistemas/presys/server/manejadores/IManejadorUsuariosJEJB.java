package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.shared.datatypes.DTRol;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorUsuariosJEJB {
   public ArrayList<DTUsuario> obtenerUsuarios();

public void agregarUsuario(String codigo, String nombre, String apellido,
		String password, List<DTRol> listaRolesSeleccionados) throws LogicException, Exception;

public void eliminarUsuario(String id);

public DTUsuario obtenerPorCodigo(String xcodigo) throws LogicException;

public void modificarUsuario(String codigo, String nombre, String apellido,
		String contrasena, Boolean cambiarContrasena, List<DTRol> listaRolesSeleccionados) throws Exception;

public void cambiarContrasena(String codigo, String contrasena) throws Exception;

public ArrayList<DTUsuario> buscarUsuarios(Integer buscarPor, String text);

public boolean validarContrasena(String contrasenaActualIngresada, String codigoUsuario) throws Exception;

}