package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.Remote;

import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.Garantia;

@Remote
public interface IManejadorGarantiasEJB {

	public ArrayList<Garantia> obtenerGarantias();

	public void agregar(String xcodigo, String xnombre, Integer anios, Integer meses, Integer dias)
			throws LogicException; 
		
	public void eliminar(String xcodigo);

	public void modificar(String xcodigo, String xnombre, Integer anios, Integer meses, Integer dias);
	
	public ArrayList<Garantia> buscar(Integer buscarPor, String cadena);
	
	public Garantia obtenerPorCodigo(String xcodigo);	
}
