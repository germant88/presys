package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.model.Tarea;
import com.sistemas.presys.server.persistencia.ITareaDAO;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.excepciones.LogicException;

@Stateless
public class ManejadorTareasEJB implements IManejadorTareasEJB{

	@EJB
	ITareaDAO tareasDAO;
		
	@Override
	public ArrayList<DTTarea> obtenerTareas() {
        ArrayList<DTTarea> resultado = new ArrayList<DTTarea>();
		
		List<Tarea> listaTareas;
        
		listaTareas = tareasDAO.obtenerTodos();
		
		cargarListaDTTareas(resultado, listaTareas);
		
		return resultado;
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void agregar(String xcodigo, String xnombre, String xdescripcion)
			throws LogicException {
        Tarea tarea = new Tarea(xcodigo, xnombre, xdescripcion);
		
		Tarea tareaAux = tareasDAO.obtenerPorCodigo(xcodigo);
		
		if (tareaAux != null) {
			throw new LogicException("Ya existe una tarea con codigo: " + xcodigo);
		}
	
		tareasDAO.agregar(tarea);				
	}

	@Override
	public void eliminar(String xcodigo) {
		tareasDAO.eliminar(xcodigo);	
	}

	@Override
	public void modificar(String codigo, String nombre, String descripcion) {
	   
		Tarea tarea = new Tarea(codigo, nombre, descripcion);
		
		tareasDAO.modificarTarea(tarea);		
	}

	@Override
	public ArrayList<DTTarea> buscar(Integer buscarPor, String cadena) {
		   ArrayList<DTTarea> resultado = new ArrayList<DTTarea>();
		
	       List<Tarea> listaTareas = tareasDAO.buscar(buscarPor, cadena);  
		
	       cargarListaDTTareas(resultado, listaTareas);
		
	       return resultado;
	}

	@Override
	public DTTarea obtenerPorCodigo(String xcodigoTarea) {
        Tarea tarea = tareasDAO.obtenerPorCodigo(xcodigoTarea);
		
		DTTarea dtTarea = obtenerDTTareaAPartirDeTarea(tarea);
		
		return dtTarea;
	}
	
	// METODOS AUXILIARES
	private void cargarListaDTTareas(ArrayList<DTTarea> resultado,
			List<Tarea> listaTareas) {

		for (int i = 0; i < listaTareas.size(); i ++) {
			
			DTTarea dtTarea = obtenerDTTareaAPartirDeTarea(listaTareas.get(i));
			
			resultado.add(dtTarea);
		}		
	}
	
	private DTTarea obtenerDTTareaAPartirDeTarea(Tarea tarea) {			
		DTTarea resultado = new DTTarea();
		
		resultado.setCodigo(tarea.getCodigo());
		resultado.setNombre(tarea.getNombre());
		resultado.setDescripcion(tarea.getDescripcion());		
							
		return resultado;
}


}
