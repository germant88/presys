package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.Remote;

import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IManejadorProductosEJB {

	public ArrayList<DTProducto> obtenerProductos();
	
	public void agregar(String xcodigo, String xnombre, String xdescripcion)  throws LogicException;

	public void eliminar(String xcodigo); 
		
	public void modificar(String codigo, String nombre, String descripcion, Boolean habilitado);

	public ArrayList<DTProducto> buscar(Integer buscarPor, String cadena);

	public DTProducto obtenerPorCodigo(String xcodigoProducto);
}
