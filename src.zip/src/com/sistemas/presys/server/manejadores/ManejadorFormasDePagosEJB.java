package com.sistemas.presys.server.manejadores;

import java.util.ArrayList;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.sistemas.presys.server.persistencia.IFormaDePagoDAO;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;

@Stateless
public class ManejadorFormasDePagosEJB implements IManejadorFormasDePagosEJB{
    @EJB
    IFormaDePagoDAO formaDePagoDAO;
	
	
	@Override
	public ArrayList<FormaDePago> obtenerFormasDePago() {
	      ArrayList<FormaDePago> resultado = new ArrayList<FormaDePago>();
					          
		  resultado = (ArrayList<FormaDePago>) formaDePagoDAO.obtenerTodos();
			    		
		  return resultado;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	@Override
	public void agregar(String xcodigo, String xnombre, String xdescripcion)
			throws LogicException {
        FormaDePago formaDePago = new FormaDePago(xcodigo, xnombre, xdescripcion);
		
        FormaDePago formaDePagoAux = formaDePagoDAO.obtenerPorCodigo(xcodigo);
		
		if (formaDePagoAux != null) {
			throw new LogicException("Ya existe una forma de pago con codigo: " + xcodigo);
		}
	
		formaDePagoDAO.agregar(formaDePago);	
	}

	@Override
	public void eliminar(String xcodigo) {
		formaDePagoDAO.eliminar(xcodigo);		
	}

	@Override
	public void modificar(String xcodigo, String xnombre, String xdescripcion) {
       FormaDePago formaDePago = new FormaDePago(xcodigo, xnombre, xdescripcion);		
	   formaDePagoDAO.modificar(formaDePago);		
	}

	@Override
	public ArrayList<FormaDePago> buscar(Integer buscarPor, String cadena) {		  			
	      ArrayList<FormaDePago> listaFormaDePago = (ArrayList<FormaDePago>) formaDePagoDAO.buscar(buscarPor, cadena);  			      		
	      return listaFormaDePago;
	}

	@Override
	public FormaDePago obtenerPorCodigo(String xcodigo) {
        FormaDePago formaDePago = formaDePagoDAO.obtenerPorCodigo(xcodigo);
						
		return formaDePago;
	}	
}
