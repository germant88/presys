package com.sistemas.presys.server.utiles;

import java.security.MessageDigest;

import com.sun.org.apache.xerces.internal.impl.dv.util.HexBin;



public class Encriptacion {
   
	public static String encriptarPassword(String textoPlano) throws Exception {
	   MessageDigest msgDigest = null;
	   //String md5;
	   String generatedPassword = null;
	   
	   msgDigest = MessageDigest.getInstance("MD5");
	   
	   msgDigest.update(textoPlano.getBytes());
	   
	   byte hash[] = msgDigest.digest();
	   
	   StringBuilder sb = new StringBuilder();
       for(int i=0; i< hash.length ;i++)
       {
           sb.append(Integer.toString((hash[i] & 0xff) + 0x100, 16).substring(1));
       }
       //Get complete hashed password in hex format
       generatedPassword = sb.toString();
	  
	   
	   return generatedPassword;	   
	   
	   /*
	    *   // Create MessageDigest instance for MD5
            MessageDigest md = MessageDigest.getInstance("MD5");
            //Add password bytes to digest
            md.update(passwordToHash.getBytes());
            //Get the hash's bytes
            byte[] bytes = md.digest();
            //This bytes[] has bytes in decimal format;
            //Convert it to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            //Get complete hashed password in hex format
            generatedPassword = sb.toString();
        }
	    * */
	   
   }
}
