package com.sistemas.presys.server.utiles;

import java.sql.SQLException;
import java.util.Map;

import javax.ejb.Remote;
import javax.servlet.ServletOutputStream;

@Remote
public interface IJasperReportsEJB {
   
	public void exportarReporte() throws SQLException;
	
	public String exportarReportePDF(final String idReporte, Map parametros, final String idSubReporte);
	
	public String ejecutarReporteSolicitudPresupuesto(String codigoSolPres);	
}
