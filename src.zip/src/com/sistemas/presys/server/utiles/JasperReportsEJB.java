package com.sistemas.presys.server.utiles;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletOutputStream;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

import org.hibernate.Session;
import org.hibernate.jdbc.Work;

import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class JasperReportsEJB implements IJasperReportsEJB{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
	public String exportarReportePDF(final String idReporte, final Map parametros, final String idSubReporte) {
		  			
		org.hibernate.Session session = em.unwrap(Session.class);
				 		
		final String fechaMilisegundos = String.valueOf(System.currentTimeMillis());					
		
		Random random  = new Random();
												
		final String numeroAleatorio = String.valueOf(random.nextInt(4));   
		
		final String nombreReporte = idReporte + fechaMilisegundos + numeroAleatorio;
		
		session.doWork(new Work() {
			
			@Override
			public void execute(Connection arg0) throws SQLException {
				// TODO Auto-generated method stub
				Connection conn = arg0;
				
				JasperDesign jasperDesign = null;
				
				ServletOutputStream streamReporte;
				
				JasperDesign jasperDesignSubReporte = null; 
											
				try {
					String pathApp = System.getProperty("jboss.home.dir");
					
					if (idReporte.equals(Ctes.K_REPORTE_PRESUPUESTO)) {
						String rutaLogoCotexsa = "logo_cotexsa.png";
						
						parametros.put("LogoCotexsa", getClass().getResourceAsStream(rutaLogoCotexsa));
						
						String rutaFirmaDigital = "FirmaDigital.JPG";
						parametros.put("FirmaDigital", getClass().getResourceAsStream(rutaFirmaDigital));
					}
																				
					jasperDesign = JRXmlLoader.load(getClass().getResourceAsStream(idReporte + ".jrxml"));
									
				    JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign); 
												
				
				    if ((idSubReporte != null) && (idSubReporte.trim() != "")) {
				    	jasperDesignSubReporte = JRXmlLoader.load(getClass().getResourceAsStream(idSubReporte + ".jrxml"));
						
					    JasperReport subReporte = JasperCompileManager.compileReport(jasperDesignSubReporte);
					    
					    parametros.put("SubReporte", subReporte);
				    }
				    
				    
				    JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parametros, conn);
				    							
				    JasperExportManager.exportReportToPdfFile(jasperPrint, pathApp + "/standalone/TempReports/" + nombreReporte + ".pdf");
				
				} catch (JRException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
       
		return idReporte + fechaMilisegundos + numeroAleatorio + ".pdf";
	}
		
	public String ejecutarReporteSolicitudPresupuesto(final String codigoSolPres){
		
		org.hibernate.Session session = em.unwrap(Session.class);
						
		session.doWork(new Work() {
			
			@Override
			public void execute(Connection arg0) throws SQLException {
				// TODO Auto-generated method stub
				Connection conn = arg0;
				
				JasperDesign jasperDesign = null;
				
				ServletOutputStream streamReporte;
											
				try {
					String pathApp = System.getProperty("jboss.home.dir");
					
					jasperDesign = JRXmlLoader.load(getClass().getResourceAsStream("Pendientes.jrxml"));
					
				
				JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
				
				HashMap map=new HashMap();
				map.put("Codigo", codigoSolPres);
				
				JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, conn);
				
				JasperExportManager.exportReportToPdfFile(jasperPrint, "C:/reportePendientes.pdf");
				
				} catch (JRException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		return "";		
	}	

	public void exportarReporte() throws SQLException{					
			org.hibernate.Session session = em.unwrap(Session.class);
									
			session.doWork(new Work() {
				
				@Override
				public void execute(Connection arg0) throws SQLException {
					// TODO Auto-generated method stub
					Connection conn = arg0;
					
					JasperDesign jasperDesign = null;	
					
					try {
						jasperDesign = JRXmlLoader.load("C:/Pendientes.jrxml");
			
					
					JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
					
					JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, conn);
					JasperExportManager.exportReportToPdfFile(jasperPrint, "C:/reportePendientes.pdf");
					
					} catch (JRException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});			 													
	}	
}
