package com.sistemas.presys.server.utiles;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class JasperReportServlet extends HttpServlet{
	
	@EJB
	IJasperReportsEJB jasperReportEJB;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        
		String pathApp = System.getProperty("jboss.home.dir");
		
		String nombreReporte = req.getParameter("nombreReporte");
		
		File file = new File(pathApp + "/standalone/TempReports/" + nombreReporte);			       
		
        String filename = file.getName();
       	
        int length = 0; 
        
        resp.setContentType("application/pdf");
        resp.setContentLength((int) file.length());
        resp.setHeader("Content-Disposition", "filename=" + filename);
        ServletOutputStream op =  resp.getOutputStream();
                    	               
        byte[] bbuf = new byte[1024];
        DataInputStream in = new DataInputStream(new FileInputStream(file));
        while ((in != null) && ((length = in.read(bbuf)) != -1)) {
                op.write(bbuf, 0, length);
        }	                	        					
        
        in.close();
        op.flush();
        op.close();	

	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		File file = new File("c:/reportePendientes.pdf");			       
		
        String filename = file.getName();
       	
        int length = 0; 
        
        resp.setContentType("application/pdf");
        resp.setContentLength((int) file.length());
        resp.setHeader("Content-Disposition", "filename=" + filename);
        ServletOutputStream op =  resp.getOutputStream();
                    	               
        byte[] bbuf = new byte[1024];
        DataInputStream in = new DataInputStream(new FileInputStream(file));
        while ((in != null) && ((length = in.read(bbuf)) != -1)) {
                op.write(bbuf, 0, length);
        }	                	        					
        
        in.close();
        op.flush();
        op.close();	
	}
	
}
