package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorProductos;
import com.sistemas.presys.server.manejadores.IManejadorProductosEJB;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.excepciones.LogicException;

public class ManejadorProductosImpl extends RemoteServiceServlet implements IRPCManejadorProductos{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@EJB
	IManejadorProductosEJB manejadorProductosEJB;
	
	@Override
	public ArrayList<DTProducto> obtenerProductos() {
		return manejadorProductosEJB.obtenerProductos();
	}
	
	public void agregarProducto(String xcodigo, String xnombre, String xdescripcion) throws LogicException{
		manejadorProductosEJB.agregar(xcodigo, xnombre, xdescripcion);
	}

	@Override
	public void eliminarProducto(String xcodigo) {
		manejadorProductosEJB.eliminar(xcodigo);	
	}
	
	public void modificarProducto(String codigo, String nombre, String descripcion,
			Boolean habilitado) {
		manejadorProductosEJB.modificar(codigo, nombre, descripcion, habilitado);
	}
	
	@Override
	public ArrayList<DTProducto> buscarProducto(Integer buscarPor, String cadena) {		
		return manejadorProductosEJB.buscar(buscarPor, cadena);
	}
	
	public DTProducto obtenerPorCodigo(String xcodigoProducto)	{
		return manejadorProductosEJB.obtenerPorCodigo(xcodigoProducto);		
	}
	
	

}
