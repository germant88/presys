package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorEdificios;
import com.sistemas.presys.server.manejadores.IManejadorEdificiosEJB;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.excepciones.LogicException;

public class ManejadorEdificiosImpl extends RemoteServiceServlet implements
IRPCManejadorEdificios{
	
	@EJB
	IManejadorEdificiosEJB manEdificios;

	@Override
	public void agregarEdificio(String codigo, String nombre,
			String direccion, String xcodigoCliente) throws LogicException {		
			   manEdificios.agregar(codigo, nombre, direccion, xcodigoCliente);						
	}

	@Override
	public void modificarEdificio(String codigo, String nombre,
			String direccion, String xcodigoCliente) {
		manEdificios.modificar(codigo, nombre, direccion, xcodigoCliente);
	}

	@Override
	public void eliminarEdificio(String codigo) {
		manEdificios.eliminar(codigo);	
	}

	@Override
	public ArrayList<DTEdificio> obtenerEdificios() {
		return manEdificios.obtenerEdificios();
	}

	@Override
	public DTEdificio obtenerEdificioPorCodigo(String Codigo) {
		return manEdificios.obtenerPorCodigo(Codigo);
	}

	@Override
	public ArrayList<DTEdificio> buscarEdificio(Integer buscarPor, String cadena) {
		return manEdificios.buscar(buscarPor, cadena);
	}

	@Override
	public ArrayList<DTEdificio> obtenerEdificiosDeCliente(String codigoCliente) {
	   return manEdificios.obtenerEdificiosDeCliente(codigoCliente);
	}

	@Override
	public ArrayList<DTEdificio> buscarEdificioDeCliente(Integer buscarPor,
			String text, String codigoCliente) {
       return manEdificios.buscarEdificioDeCliente(buscarPor, text, codigoCliente);
	}
}
