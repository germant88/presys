package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorNotasImpresion;
import com.sistemas.presys.server.manejadores.IManejadorNotasImpresionEJB;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.excepciones.LogicException;


public class ManejadorNotasImpresionImpl extends RemoteServiceServlet implements
IRPCManejadorNotasImpresion{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@EJB
	IManejadorNotasImpresionEJB manNotasImpresionEJB;

	@Override
	public ArrayList<DTNotaImpresion> obtenerNotasImpresion() {
		return manNotasImpresionEJB.obtenerNotas();		
	}

	@Override
	public void agregarNotaImpresion(String xcodigo, String xnombre,
			String xdescripcion) throws LogicException {
		manNotasImpresionEJB.agregar(xcodigo, xnombre, xdescripcion);
	}

	@Override
	public void eliminarNotaImpresion(String xcodigo) {
		manNotasImpresionEJB.eliminar(xcodigo);
	}

	@Override
	public void modificarNotaImpresion(String codigo, String nombre,
			String descripcion) {
		manNotasImpresionEJB.modificar(codigo, nombre, descripcion);		
	}

	@Override
	public ArrayList<DTNotaImpresion> buscarNotaImpresion(Integer buscarPor, String cadena) {
		return manNotasImpresionEJB.buscar(buscarPor, cadena);
	}

	@Override
	public DTNotaImpresion obtenerPorCodigo(String xcodigo) {
		return manNotasImpresionEJB.obtenerPorCodigo(xcodigo);
	}
}
