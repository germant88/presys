package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorClientes;
import com.sistemas.presys.server.manejadores.IManejadorClientesEJB;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.excepciones.LogicException;

public class ManejadorClientesImpl extends RemoteServiceServlet implements
IRPCManejadorClientes{

@EJB
IManejadorClientesEJB manClientes;
	
	@Override
	public DTCliente agregarCliente(String codigo, String nombre, String email,
			String direccion, String rut, String telefono,
			String contactoNombre, String contactoEmail, String contactoTelefono, String codigoSegmento) throws LogicException {
		try {
		return manClientes.agregarCliente(codigo, nombre, email, direccion, rut, telefono, contactoNombre, contactoEmail, contactoTelefono, codigoSegmento);
		} catch(Exception e) {
			throw new LogicException(e.getMessage());
		}
	}
	
	public DTCliente modificarCliente(String codigo, String nombre, String email,
			String direccion, String rut, String telefono,
			String contactoNombre, String contactoEmail, String contactoTelefono,
			String codigoSegmento) {
		return manClientes.modificarCliente(codigo, nombre, email, direccion, rut, telefono, contactoNombre, contactoEmail, contactoTelefono, codigoSegmento);
	}
	
	public ArrayList<DTCliente> obtenerClientes(){
		
		return manClientes.obtenerClientes();
	}
	
	public void eliminarCliente(String codigo){
		 manClientes.eliminarCliente(codigo);
	}
	
	public DTCliente obtenerClientePorCodigo (String codigo) {
		return manClientes.obtenerClientePorCodigo(codigo);
	}

	@Override
	public ArrayList<DTCliente> buscarCliente(Integer buscarPor, String cadena) {		
		return manClientes.buscarClientes(buscarPor, cadena);
	}
}
