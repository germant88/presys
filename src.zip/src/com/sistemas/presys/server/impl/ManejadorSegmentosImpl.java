package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorSegmentos;
import com.sistemas.presys.server.manejadores.IManejadorSegmentosEJB;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;

public class ManejadorSegmentosImpl extends RemoteServiceServlet implements IRPCManejadorSegmentos{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	IManejadorSegmentosEJB manejadorSegmentosEJB;
	
	@Override
	public void agregarSegmento(String xcodigo, String xnombre,
			String xdescripcion) throws LogicException {
		manejadorSegmentosEJB.agregar(xcodigo, xnombre, xdescripcion);
	}

	@Override
	public void eliminarSegmento(String xcodigo) {
		manejadorSegmentosEJB.eliminar(xcodigo);		
	}

	@Override
	public void modificarSegmento(String codigo, String nombre,
			String descripcion, Boolean habilitado) {
		manejadorSegmentosEJB.modificar(codigo, nombre, descripcion, habilitado);		
	}

	@Override
	public ArrayList<DTSegmento> obtenerSegmentos() {
		return manejadorSegmentosEJB.obtenerSegmentos();
	}

	@Override
	public ArrayList<DTSegmento> buscarSegmento(Integer buscarPor, String cadena) {
		return manejadorSegmentosEJB.buscar(buscarPor, cadena);
	}

	@Override
	public DTSegmento obtenerPorCodigo(String xcodigoSegmento) {
		return manejadorSegmentosEJB.obtenerPorCodigo(xcodigoSegmento);
	}		
}
