package com.sistemas.presys.server.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorConsultasPresupuestos;
import com.sistemas.presys.server.manejadores.IManejadorConsultasPresupuestosEJB;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;

public class ManejadorConsultasPresupuestosImpl extends RemoteServiceServlet implements IRPCManejadorConsultasPresupuestos{

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@EJB
IManejadorConsultasPresupuestosEJB manejadorConsultas;
	
	@Override
	public ArrayList<DTGridPresupuesto> buscarPresupuestos(String codigo, Date fechaDesde, Date fechaHasta, ArrayList<Integer> xestados, ArrayList<String> xtipos, String cliente, String edificio, String producto) {
	   
	   return manejadorConsultas.obtenerListaDTGridPresupuestos(fechaDesde, fechaHasta, codigo, xestados, xtipos, cliente, edificio, producto);	
			   		  
	}
	
	public ArrayList<DTGridPresupuesto> obtenerDocumentosOrigenDeDocumento(String codigoDocumento, String tipoDocumento) {	
		PK_SolicitudPresupuesto claveDocumento;
		claveDocumento = new PK_SolicitudPresupuesto();
	    claveDocumento.setCodigo(codigoDocumento);
	    claveDocumento.setTipodocumento(tipoDocumento);
		
		return manejadorConsultas.obtenerDocumentosOrigenDeDocumento(claveDocumento);
	}

	public ArrayList<DTGridPresupuesto> obtenerDocumentosDestinoDeDocumento(String codigo, String tipoDocumento){
		PK_SolicitudPresupuesto claveDocumento;
		claveDocumento = new PK_SolicitudPresupuesto();
	    claveDocumento.setCodigo(codigo);
	    claveDocumento.setTipodocumento(tipoDocumento);
	    
		return manejadorConsultas.obtenerDocumentosDestinoDeDocumento(claveDocumento);
	}
}
