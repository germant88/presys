package com.sistemas.presys.server.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuarios;
import com.sistemas.presys.server.manejadores.IManejadorUsuariosJEJB;
import com.sistemas.presys.shared.datatypes.DTRol;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;

public class ManejadorUsuariosImpl  extends RemoteServiceServlet implements
IRPCManejadorUsuarios{

	@EJB
	IManejadorUsuariosJEJB manejadorUsuarios;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ArrayList<DTUsuario> obtenerUsuarios() {
        return manejadorUsuarios.obtenerUsuarios();
	}
	
	public DTUsuario obtenerPorCodigo(String xcodigo) throws LogicException {
		return manejadorUsuarios.obtenerPorCodigo(xcodigo);
	}

	

	@Override
	public void eliminarUsuario(String id) {
		manejadorUsuarios.eliminarUsuario(id);
	}

	@Override
	public void modificar(String codigo, String nombre, String apellido,
			String contrasena, Boolean cambiarContrasena, List<DTRol> listaRolesSeleccionados) throws Exception {
		manejadorUsuarios.modificarUsuario(codigo, nombre, apellido, contrasena, cambiarContrasena, listaRolesSeleccionados);		
	}

	@Override
	public ArrayList<DTUsuario> buscarUsuario(Integer buscarPor, String text) {
		return manejadorUsuarios.buscarUsuarios(buscarPor, text);
	}

	@Override
	public void agregarUsuario(String codigo, String nombre, String apellido,
			String password, List<DTRol> listaRolesSeleccionados) throws LogicException, Exception {
		manejadorUsuarios.agregarUsuario(codigo, nombre, apellido, password, listaRolesSeleccionados);		
	}

	@Override
	public void cambiarContrasena(String codigo, String contrasena)
			throws Exception {
		manejadorUsuarios.cambiarContrasena(codigo, contrasena);		
	}

	@Override
	public boolean validarContrasena(String contrasena, String codigoUsuario)
			throws Exception {		
		return manejadorUsuarios.validarContrasena(contrasena, codigoUsuario);
	}	
}
