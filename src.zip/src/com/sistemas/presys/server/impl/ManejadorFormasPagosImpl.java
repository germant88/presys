package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorFormasPagos;
import com.sistemas.presys.server.manejadores.IManejadorFormasDePagosEJB;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;

public class ManejadorFormasPagosImpl extends RemoteServiceServlet implements
IRPCManejadorFormasPagos{

	@EJB
	IManejadorFormasDePagosEJB manFormasDePagosEJB;
	
	@Override
	public void agregar(String codigo, String nombre, String descripcion)
			throws LogicException {
	   manFormasDePagosEJB.agregar(codigo, nombre, descripcion);		
	}

	@Override
	public void modificar(String codigo, String nombre, String descripcion) {
       manFormasDePagosEJB.modificar(codigo, nombre, descripcion);		
	}

	@Override
	public void eliminar(String codigo) {
       manFormasDePagosEJB.eliminar(codigo);		
	}

	@Override
	public ArrayList<FormaDePago> obtenerFormasDePago() {
		return manFormasDePagosEJB.obtenerFormasDePago();
	}

	@Override
	public FormaDePago obtenerFormaDePagoPorCodigo(String Codigo) {
       return manFormasDePagosEJB.obtenerPorCodigo(Codigo);
	}

	@Override
	public ArrayList<FormaDePago> buscarFormaDePago(Integer buscarPor,
			String cadena) {
		return manFormasDePagosEJB.buscar(buscarPor, cadena);
	}

}
