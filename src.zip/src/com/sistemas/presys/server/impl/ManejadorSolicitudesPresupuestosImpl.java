package com.sistemas.presys.server.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorSolicitudesPresupuestos;
import com.sistemas.presys.server.manejadores.IManejadorSolicitudesPresupuestosEJB;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;
import com.sistemas.presys.shared.excepciones.LogicException;


public class ManejadorSolicitudesPresupuestosImpl extends RemoteServiceServlet implements
IRPCManejadorSolicitudesPresupuestos{

	@EJB
	IManejadorSolicitudesPresupuestosEJB manSolicitudes;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void agregar(String xcodigo, String xtipoDocumento, Date xfecha, String xusuarioAsignado,
			String xcodigoCliente, String xcodigoEdificio, String xdetalles,
			Integer xestado, Date xfechaSeguimiento, ArrayList<DTNotaSeguimiento> listaNotasSeguimiento, Double xtotal, String xcodigoSolOPresOrigen, String tipoDocumentoOrigen,			
			ArrayList<DTRenglonPresupuesto> listaDTRenglonesPresupuesto,String formaDePago, String garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
			Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios, ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresionPresupuesto) throws LogicException {

		    try {
			   manSolicitudes.agregar(xcodigo, xtipoDocumento, xfecha, xusuarioAsignado, xcodigoCliente, xcodigoEdificio, xdetalles, xestado, xfechaSeguimiento, listaNotasSeguimiento, xtotal, xcodigoSolOPresOrigen, tipoDocumentoOrigen, listaDTRenglonesPresupuesto, formaDePago,  garantia,  superficie,  leyesSocialesHasta,  costoBQ, 
						 tiempoEjecDias,  tiempoEjecMeses,  tiempoEjecAnios,
						 validezDias,  validezMeses, validezAnios, listaNotasImpresionPresupuesto);
			} catch(Exception e) {
				throw new LogicException(e.getMessage());
			}
	} 

	@Override
	public DTSolicitudPresupuesto obtenerPorCodigo(String codigo, String tipoDocumento) {
	    PK_SolicitudPresupuesto claveDocumento;
	    claveDocumento = new PK_SolicitudPresupuesto();
	    claveDocumento.setCodigo(codigo);
	    claveDocumento.setTipodocumento(tipoDocumento);
		return manSolicitudes.obtenerPorCodigo(claveDocumento);
	}
	
	public List<DTNotaSeguimiento> obtenerNotasDeSolicitud(String codigo, String tipoDocumento) {
		PK_SolicitudPresupuesto clave = new PK_SolicitudPresupuesto();
		clave.setCodigo(codigo);
		clave.setTipodocumento(tipoDocumento);
		
		return manSolicitudes.obtenerNotasDeSolicitud(clave);
	}

	@Override
	public void modificar(String xcodigo, String xtipoDocumento, Date xfecha, String xusuarioAsignado,
			String xcodigoCliente, String xcodigoEdificio, String xdetalles,
			Integer xestado, Date xfechaSeguimiento,
			ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,String formaDePago, String garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
			Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios, ArrayList<DTNotaImpresionPresupuesto> notasImpresion)
			throws LogicException {
		manSolicitudes.modificarSolicitud(xcodigo, xtipoDocumento, xfecha, xusuarioAsignado, xcodigoCliente,
				                                 xcodigoEdificio, xdetalles, xestado, xfechaSeguimiento,
				                                 listaNotasSeguimiento, formaDePago, garantia, superficie, leyesSocialesHasta, costoBQ, 
				         						 tiempoEjecDias, tiempoEjecMeses, tiempoEjecAnios,
				        						 validezDias, validezMeses, validezAnios, notasImpresion);		
	}

	@Override
	public void cambiarEstado(String codigoSolicitudPresupuesto, String tipoDocumento, Integer estado) {
       PK_SolicitudPresupuesto clave  = new PK_SolicitudPresupuesto();
       clave.setCodigo(codigoSolicitudPresupuesto);
       clave.setTipodocumento(tipoDocumento);
		manSolicitudes.cambiarEstadoSolicitud(clave,  estado);	
	}

	@Override
	public List<DTNotaImpresionPresupuesto> obtenerNotasDeImpresion(String codigo) {
		return null;
		//return manSolicitudes.obtenerNotasDeImpresion(codigo);
	}

}
