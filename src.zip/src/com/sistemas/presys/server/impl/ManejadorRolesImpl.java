package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorRoles;
import com.sistemas.presys.server.manejadores.IManejadorRolesEJB;
import com.sistemas.presys.shared.datatypes.DTRol;

public class ManejadorRolesImpl extends RemoteServiceServlet implements
IRPCManejadorRoles{

	@EJB
	IManejadorRolesEJB manejadorRoles;
	
	@Override
	public ArrayList<DTRol> obtenerRoles() {
		return manejadorRoles.obtenerRoles();		
	}

}
