package com.sistemas.presys.server.impl;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativos;
import com.sistemas.presys.server.manejadores.IManejadorCorrelativosEJB;

public class ManejadorCorrelativosImpl extends RemoteServiceServlet implements
IRPCManejadorCorrelativos{

@EJB
IManejadorCorrelativosEJB manCorrelativos;
	
	
	@Override
	public String obtenerProximoCorrelativo(String codigo) {
		return manCorrelativos.obtenerProximoCorrelativo(codigo);
	}

}
