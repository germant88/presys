package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorGarantias;
import com.sistemas.presys.server.manejadores.IManejadorGarantiasEJB;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.Garantia;

public class ManejadorGarantiasImpl extends RemoteServiceServlet implements
IRPCManejadorGarantias{

	@EJB
	IManejadorGarantiasEJB manGarantiasEJB;	
	
	@Override
	public void agregar(String codigo, String nombre, Integer anios,
			Integer meses, Integer dias) throws LogicException {
		manGarantiasEJB.agregar(codigo, nombre, anios, meses, dias);
	}

	@Override
	public void modificar(String codigo, String nombre, Integer anios,
			Integer meses, Integer dias) {
		manGarantiasEJB.modificar(codigo, nombre, anios, meses, dias);
	}

	@Override
	public void eliminar(String codigo) {
		manGarantiasEJB.eliminar(codigo);	
	}

	@Override
	public ArrayList<Garantia> obtenerGarantias() {
		return manGarantiasEJB.obtenerGarantias();
	}

	@Override
	public Garantia obtenerGarantiaPorCodigo(String Codigo) {
		return manGarantiasEJB.obtenerPorCodigo(Codigo);
	}

	@Override
	public ArrayList<Garantia> buscar(Integer buscarPor, String cadena) {
		return manGarantiasEJB.buscar(buscarPor, cadena);
	}

}
