package com.sistemas.presys.server.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

import org.hibernate.Session;
import org.hibernate.jdbc.Work;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorUtiles;
import com.sistemas.presys.server.manejadores.IManejadorUtilesEJB;
import com.sistemas.presys.server.utiles.IJasperReportsEJB;


public class ManejadorUtilesImpl extends RemoteServiceServlet implements
IRPCManejadorUtiles {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
@EJB
IManejadorUtilesEJB manejadorUtiles;

@EJB
IJasperReportsEJB jasperEJB;
	
	@Override
	public String obtenerUsuarioLogueado() throws Exception {
		return manejadorUtiles.obtenerCodigoUsuarioLogueado();
	}

	@Override
	public void cerrarSesion() {       
		HttpServletRequest request = this.getThreadLocalRequest(); 				
		
		if(request.getSession(false)!=null){
	            request.getSession(false).invalidate();//remove session.
        }
        
        try {
			request.logout();
		} catch (ServletException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}                
	}
	
	

	@Override
	public Boolean ejecutarReporteSolicitudPresupuesto(String codigoSolPres) {

		
		
		final HttpServletResponse respuesta = this.getThreadLocalResponse();
		
		/*
		 *   resp.setContentType("application/pdf");
                resp.setDateHeader("Expires", 0);
                final String name = getReportName(request);
                resp.setHeader("Content-description", "Pendientes.pdf");
                resp.setHeader("Content-disposition", "attachment; filename=\Pendientes.pdf");
 
                final String reportFileName = getServletConfig().getServletContext().getRealPath(
                        "/WEB-INF/reports/" + getJasperFilename(request));
                final File reportFile = new File(reportFileName);
                final Map<string , Object> parameters = new HashMap</string><string , Object>();
                parameters.put("BaseDir", reportFile.getParentFile());
                addParameters(request, parameters);
                final JasperPrint jasperPrint = JasperFillManager.fillReport(reportFileName, parameters, conn);
                JasperExportManager.exportReportToPdfStream(jasperPrint, resp.getOutputStream());
		 * */
		
		respuesta.setContentType("application/pdf");
		respuesta.setDateHeader("Expires", 0);
		respuesta.setHeader("Content-description", "Pendientes.pdf");
        respuesta.setHeader("Content-disposition", "attachment; filename=\"Pendientes.pdf\"");        
        

			
								
			//jasperEJB.ejecutarReporteSolicitudPresupuesto("00000061", op);
		
			
        	org.hibernate.Session session = em.unwrap(Session.class);
			
    		session.doWork(new Work() {
    			
    			@Override
    			public void execute(Connection arg0) throws SQLException {
    				// TODO Auto-generated method stub
    				Connection conn = arg0;
    				
    				JasperDesign jasperDesign = null;
    				
    				ServletOutputStream streamReporte;
    											
    				try {
    					String pathApp = System.getProperty("jboss.home.dir");
    					
    					jasperDesign = JRXmlLoader.load(getClass().getResourceAsStream("Pendientes.jrxml"));
    					
    				
    				JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
    				
    				HashMap map=new HashMap();
    				map.put("Codigo", "00000061");
    				
    				JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, conn);
    				try {
						JasperExportManager.exportReportToPdfStream(jasperPrint, respuesta.getOutputStream());
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}				
    				
    				} catch (JRException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
    			}
    		});  		
        return true;
	}

	@Override
	public String exportarReportePDF(String idReporte, Map parametros, String idSubReporte) {
	   return jasperEJB.exportarReportePDF(idReporte, parametros, idSubReporte);
	}
}
