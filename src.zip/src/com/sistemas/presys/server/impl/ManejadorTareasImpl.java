package com.sistemas.presys.server.impl;

import java.util.ArrayList;

import javax.ejb.EJB;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.sistemas.presys.client.rpc.IRPCManejadorTareas;
import com.sistemas.presys.server.manejadores.IManejadorTareasEJB;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.excepciones.LogicException;

public class ManejadorTareasImpl extends RemoteServiceServlet implements IRPCManejadorTareas{

	@EJB
	IManejadorTareasEJB manejadorTareasEJB;
	
	@Override
	public ArrayList<DTTarea> obtenerTareas() {
		return manejadorTareasEJB.obtenerTareas();
	}

	@Override
	public void agregarTarea(String xcodigo, String xnombre, String xdescripcion)
			throws LogicException {
       manejadorTareasEJB.agregar(xcodigo, xnombre, xdescripcion);		
	}

	@Override
	public void eliminarTarea(String xcodigo) {
       manejadorTareasEJB.eliminar(xcodigo);		
	}

	@Override
	public void modificarTarea(String codigo, String nombre, String descripcion) {
       manejadorTareasEJB.modificar(codigo, nombre, descripcion);		
	}

	@Override
	public ArrayList<DTTarea> buscarTarea(Integer buscarPor, String cadena) {
		return manejadorTareasEJB.buscar(buscarPor, cadena);
	}

	@Override
	public DTTarea obtenerPorCodigo(String xcodigoTarea) {
		return manejadorTareasEJB.obtenerPorCodigo(xcodigoTarea);
	}
}
