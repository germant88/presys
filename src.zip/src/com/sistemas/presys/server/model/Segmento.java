package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="SEGMENTO")
public class Segmento implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="SEGMENTO_COD")
	private String codigo;
	
	@Column(name="SEGMENTO_NOM")
	private String nombre;
	
	@Column(name="SEGMENTO_DESC")
	@Lob
	private String descripcion;
	
	@Column(name="SEGMENTO_HAB")
	private Boolean habilitado;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Boolean getHabilitado() {
		return habilitado;
	}

	public void setHabilitado(Boolean habilitado) {
		this.habilitado = habilitado;
	}

    public Segmento(){
    	super();
    }
    
    public Segmento(String xcodigo, String xnombre, String xdescripcion, Boolean xhabilitado) {
		super();
		this.codigo = xcodigo;
		this.nombre = xnombre;
		this.descripcion = xdescripcion;
		this.habilitado = xhabilitado;		
	}
	
}
