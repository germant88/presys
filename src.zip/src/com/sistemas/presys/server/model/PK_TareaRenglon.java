package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Embeddable
public class PK_TareaRenglon implements Serializable{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ManyToOne
    @JoinColumns({
		@JoinColumn(name = "renglonsolicitudpresupuesto_pres_cod",  referencedColumnName = "PRES_COD"),
		@JoinColumn(name = "renglonsolicitudpresupuesto_pres_tdoc", referencedColumnName = "PRES_TDOC"),
		@JoinColumn(name = "renglonsolicitudpresupuesto_ren_num",   referencedColumnName = "REN_NUM")})
    private RenglonSolicitudPresupuesto renglonSolicitudPresupuesto;
        
	@Column(name = "NUM_TAREA")		
	private Integer numeroTarea;

	public RenglonSolicitudPresupuesto getRenglonSolicitudPresupuesto() {
		return renglonSolicitudPresupuesto;
	}

	public void setRenglonSolicitudPresupuesto(
			RenglonSolicitudPresupuesto renglonSolicitudPresupuesto) {
		this.renglonSolicitudPresupuesto = renglonSolicitudPresupuesto;
	}

	public Integer getNumeroTarea() {
		return numeroTarea;
	}

	public void setNumeroTarea(Integer numeroTarea) {
		this.numeroTarea = numeroTarea;
	}
	
	
	
}
