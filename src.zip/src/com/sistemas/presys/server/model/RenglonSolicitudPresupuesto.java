package com.sistemas.presys.server.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="RENG_SOL_PRES")
public class RenglonSolicitudPresupuesto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    private PK_RenglonSolicitudPresupuesto pkRenglonSolicitudPresupuesto;
       
    @ManyToOne
    @JoinColumn(name="REN_PROD")
    private Producto producto;
    
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER,  mappedBy = "pkTareaRenglon.renglonSolicitudPresupuesto")    
	private List<TareaRenglon> tareasRenglon;
    
    @Column(name="REN_IMP")
    private Double importe;
    
    @Column(name="REN_DESC")
    private String descripcion;
    
	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public Double getImporte() {
		return importe;
	}

	public void setImporte(Double importe) {
		this.importe = importe;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}		

	public List<TareaRenglon> getTareasRenglon() {
		return tareasRenglon;
	}

	public void setTareasRenglon(List<TareaRenglon> tareasRenglon) {
		this.tareasRenglon = tareasRenglon;
	}

	public RenglonSolicitudPresupuesto(Integer numeroRenglon,
			SolicitudPresupuesto solicitudPresupuesto, Producto producto,
			Double importe, String descripcion) {
		super();
		this.pkRenglonSolicitudPresupuesto.setNumeroRenglon(numeroRenglon);
		this.pkRenglonSolicitudPresupuesto.setSolicitudPresupuesto(solicitudPresupuesto);
		this.producto = producto;
		this.importe = importe;
		this.descripcion = descripcion;
		this.tareasRenglon = new ArrayList<TareaRenglon>();
	}

	public RenglonSolicitudPresupuesto() {
		super();
		tareasRenglon = new ArrayList<TareaRenglon>();
		pkRenglonSolicitudPresupuesto = new PK_RenglonSolicitudPresupuesto();
	}

	public PK_RenglonSolicitudPresupuesto getPkRenglonSolicitudPresupuesto() {
		return pkRenglonSolicitudPresupuesto;
	}

	public void setPkRenglonSolicitudPresupuesto(
			PK_RenglonSolicitudPresupuesto pkRenglonSolicitudPresupuesto) {
		this.pkRenglonSolicitudPresupuesto = pkRenglonSolicitudPresupuesto;
	}
	
	
}
