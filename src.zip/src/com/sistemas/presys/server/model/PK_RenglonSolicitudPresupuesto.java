package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;


@Embeddable
public class PK_RenglonSolicitudPresupuesto implements Serializable{
	
    @Column(name="REN_NUM")
	private Integer numeroRenglon;
        
    @ManyToOne
    @JoinColumns({
		@JoinColumn(name = "PRES_COD", referencedColumnName = "SOL_COD"),
		@JoinColumn(name = "PRES_TDOC", referencedColumnName = "SOL_TDOC") })
    private SolicitudPresupuesto solicitudPresupuesto;

	public Integer getNumeroRenglon() {
		return numeroRenglon;
	}

	public void setNumeroRenglon(Integer numeroRenglon) {
		this.numeroRenglon = numeroRenglon;
	}

	public SolicitudPresupuesto getSolicitudPresupuesto() {
		return solicitudPresupuesto;
	}

	public void setSolicitudPresupuesto(SolicitudPresupuesto solicitudPresupuesto) {
		this.solicitudPresupuesto = solicitudPresupuesto;
	}
	    
}
