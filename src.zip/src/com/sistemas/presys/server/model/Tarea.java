package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tareas")
public class Tarea implements Serializable{

	@Id
	@Column(name="tarea_codigo")
	private String codigo;
	
	@Column(name="tarea_nombre")
	private String nombre;
	
	@Column(name="tarea_descripcion")
	private String descripcion;
	
	public Tarea (String xcodigo, String xnombre, String xdescripcion){
		super();
		codigo = xcodigo;
		nombre = xnombre;
		descripcion = xdescripcion;
	}
	
	public Tarea(){
		super();
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
