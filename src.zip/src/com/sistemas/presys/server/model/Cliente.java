package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CLIENTES")
public class Cliente implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="CLI_COD")
	private String codigo;	
	@Column(name="CLI_NOM")
	private String nombre;
	@Column(name="CLI_EMAIL")
	private String email;
	@Column(name="CLI_DIRE")
	private String direccion;
	@Column(name="CLI_RUT")
	private String rut;
	@Column(name="CLI_TEL")
	private String telefono;
	@Column(name="CLI_CONTNOM")
	private String contactoNombre;
	@Column(name="CLI_CONTEMAIL")
	private String contactoEmail;
	@Column(name="CLI_CONTTTEL")
	private String contactoTelefono;
	 @ManyToOne
	 @JoinColumn(name="SEGMENTO_COD")
	 private Segmento segmento;
	
	
	//TODO: Tipo de cliente, habilitado
	
	public Cliente() {
		super();
	}
	
	public Cliente(String xcodigo, String xnombre, String xemail, String xdireccion,
			       String xrut, String xtelefono, String xcontactoNombre, String xcontactoEmail,
			       String xcontactoTelefono, Segmento xsegmento){
		super();
		this.codigo           = xcodigo;
		this.nombre           = xnombre;
		this.email            = xemail;
		this.direccion        = xdireccion;
		this.rut              = xrut;
		this.telefono         = xtelefono;
		this.contactoNombre   = xcontactoNombre;
		this.contactoEmail    = xcontactoEmail;
		this.contactoTelefono = xcontactoTelefono;
		this.segmento         = xsegmento;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getContactoNombre() {
		return contactoNombre;
	}

	public void setContactoNombre(String contactoNombre) {
		this.contactoNombre = contactoNombre;
	}

	public String getContactoEmail() {
		return contactoEmail;
	}

	public void setContactoEmail(String contactoEmail) {
		this.contactoEmail = contactoEmail;
	}

	public String getContactoTelefono() {
		return contactoTelefono;
	}

	public void setContactoTelefono(String contactoTelefono) {
		this.contactoTelefono = contactoTelefono;
	}

	public Segmento getSegmento() {
		return segmento;
	}

	public void setSegmento(Segmento segmento) {
		this.segmento = segmento;
	}
	
	

}
