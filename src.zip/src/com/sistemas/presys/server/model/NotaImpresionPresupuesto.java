package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="NOTAIMP_PRES")
public class NotaImpresionPresupuesto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    private PK_NotaImpresionPresupuesto pkNotaImpresionPresupuesto;
	
	@ManyToOne
	@JoinColumn(name="NOTAIMP_X_DEF")
	private NotaImpresion notaImpresionXDefecto;
	
	@Column
	private String Descripcion;

	public NotaImpresion getNotaImpresionXDefecto() {
		return notaImpresionXDefecto;
	}

	public void setNotaImpresionXDefecto(NotaImpresion notaImpresionXDefecto) {
		this.notaImpresionXDefecto = notaImpresionXDefecto;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	public PK_NotaImpresionPresupuesto getPkNotaImpresionPresupuesto() {
		return pkNotaImpresionPresupuesto;
	}

	public void setPkNotaImpresionPresupuesto(
			PK_NotaImpresionPresupuesto pkNotaImpresionPresupuesto) {
		this.pkNotaImpresionPresupuesto = pkNotaImpresionPresupuesto;
	}

	public NotaImpresionPresupuesto() {
		super();
		pkNotaImpresionPresupuesto = new PK_NotaImpresionPresupuesto();
	}

	public NotaImpresionPresupuesto(
			PK_NotaImpresionPresupuesto pkNotaImpresionPresupuesto,
			NotaImpresion notaImpresionXDefecto, String descripcion) {
		super();
		this.pkNotaImpresionPresupuesto = pkNotaImpresionPresupuesto;
		this.notaImpresionXDefecto = notaImpresionXDefecto;
		Descripcion = descripcion;
	}
}
