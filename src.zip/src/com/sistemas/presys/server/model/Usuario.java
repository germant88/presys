package com.sistemas.presys.server.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;



@Entity
@Table(name="usuarios")
public class Usuario implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column
	private String usuario_id;
	
	@Column(name="usuario_pass")
	private String password;
	
	@Column(name="usuario_nombre")
	private String nombre;
	
	@Column(name="usuario_apellido")
	private String apellido;
	
	@ManyToMany(fetch = FetchType.EAGER)	
	@JoinTable(name="usuarios_roles")
	private List<Rol> roles;

	public Usuario(String codigo, String nombre, String apellido,
			String password) {
	    super();
	    this.usuario_id = codigo;
	    this.nombre = nombre;
	    this.apellido = apellido;
	    this.password = password;
	}
	
	public Usuario() {
		super();
	}

	public String getUsuario_id() {
		return usuario_id;
	}		

	public void setUsuario_id(String usuario_id) {
		this.usuario_id = usuario_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public List<Rol> getRoles() {
		return roles;
	}

	public void setRoles(List<Rol> roles) {
		this.roles = roles;
	}	
}
