package com.sistemas.presys.server.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.model.Garantia;

@Entity
@Table(name="SOLICITUD_PRESUPUESTO")
public class SolicitudPresupuesto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    private PK_SolicitudPresupuesto pkSolicitudPresupuesto;

	@Column(name="SOL_FEC")
	private Date fecha;
	
	
	@ManyToOne
	@JoinColumn(name="USU_COD")
	private Usuario usuarioAsignado;
	
	//@Column(name="SOL_USU_ASIGNADO")
	//private String usuarioAsignado;
	
	@ManyToOne
	@JoinColumn(name="CLI_COD")
	private Cliente cliente;
	
	@ManyToOne
	@JoinColumn(name="EDIFICIO_COD")
	private Edificio edificio;
	
	@Column(name="SOL_DETALLES")
	private String detalles;
	
	@Column(name="SOL_ESTADO")
	private Integer estado;
	
	@Column(name="SOL_FECSEGUIMIENTO")	
	private Date fechaSeguimiento;
	
	@Column(name="SOL_TOTAL")
	private Double total;
	
	@ManyToOne
	@JoinColumn(name="SOL_FOPAGO")
	private FormaDePago formaDePago;
	
	@ManyToOne
	@JoinColumn(name="SOL_GARANTIA")
	private Garantia garantia;
	
	@Column(name="SOL_SUPERFICIE")
	private Integer superficie;
	
	@Column(name="SOL_LEYES_SOCIALES")
	private Double leyesSociales;
	
	@Column(name="SOL_COSTO_BQ")
	private Double costoBQ;
	
	@Column(name="SOL_TIEMPO_EJECUCION_D")
	private Integer tiempoEjecucionDias;
	
	@Column(name="SOL_TIEMPO_EJECUCION_M")
	private Integer tiempoEjecucionMeses;
	
	@Column(name="SOL_TIEMPO_EJECUCION_A")
	private Integer tiempoEjecucionAnios;
	
	@Column(name="SOL_VALIDEZ_D")
	private Integer validezDias;
	
	@Column(name="SOL_VALIDEZ_M")
	private Integer validezMeses;
	
	@Column(name="SOL_VALIDEZ_A")
	private Integer validezAnios;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "pkNotaSeguimiento.solicitudPresupuesto")
	private List<NotaSeguimiento> notasSeguimiento;	
	
	@ManyToOne	
	@JoinColumns({
		@JoinColumn(name = "SOL_ORI_COD", referencedColumnName = "SOL_COD"),
		@JoinColumn(name = "SOL_ORI_TDOC", referencedColumnName = "SOL_TDOC") })
	private SolicitudPresupuesto solicitudOrigen;
		
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "pkRenglonSolicitudPresupuesto.solicitudPresupuesto")
	private List<RenglonSolicitudPresupuesto> renglonesPresupuesto;
	
	@OneToMany(cascade = CascadeType.ALL, /*FetchType = EAGER,*/  mappedBy = "pkNotaImpresionPresupuesto.solicitudPresupuesto")    
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<NotaImpresionPresupuesto> notasImpresionPresupuesto;

	public SolicitudPresupuesto(String codigo, String xtipoDocumento, Date fecha,
			Usuario usuarioAsignado, Cliente cliente, Edificio edificio,
			String detalles, Integer estado, Date fechaSeguimiento, ArrayList<NotaSeguimiento> notasSeguimiento,Double total, SolicitudPresupuesto solicitudOPresupuestoOrigen,
			ArrayList<RenglonSolicitudPresupuesto> renglonesSolicitudPresupuesto,
			FormaDePago formaDePago, Garantia garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
			Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios,
			ArrayList<NotaImpresionPresupuesto> notasImpresionPresup) {
		
		super();
		pkSolicitudPresupuesto = new PK_SolicitudPresupuesto();
		this.pkSolicitudPresupuesto.setCodigo(codigo);
		this.pkSolicitudPresupuesto.setTipodocumento(xtipoDocumento);
		this.fecha = fecha;
		this.usuarioAsignado = usuarioAsignado;
		this.cliente = cliente;
		this.edificio = edificio;
		this.detalles = detalles;
		this.estado = estado;
		this.fechaSeguimiento = fechaSeguimiento;
		this.notasSeguimiento = notasSeguimiento;
		this.total = total;
		this.solicitudOrigen = solicitudOPresupuestoOrigen;
		this.renglonesPresupuesto = renglonesSolicitudPresupuesto;
		this.formaDePago = formaDePago;
		this.garantia = garantia;
		this.superficie = superficie;
		this.leyesSociales = leyesSocialesHasta;
		this.costoBQ = costoBQ;
		this.tiempoEjecucionDias = tiempoEjecDias;
		this.tiempoEjecucionMeses = tiempoEjecMeses;
		this.tiempoEjecucionAnios = tiempoEjecAnios;
		this.validezDias = validezDias;
		this.validezMeses = validezMeses;
		this.validezAnios = validezAnios;
		this.notasImpresionPresupuesto = notasImpresionPresup;
	}
	
	public SolicitudPresupuesto(){
		super();
		pkSolicitudPresupuesto = new PK_SolicitudPresupuesto();
		notasSeguimiento = new ArrayList<NotaSeguimiento>();
	}


	public PK_SolicitudPresupuesto getPkSolicitudPresupuesto() {
		return pkSolicitudPresupuesto;
	}

	public void setPkSolicitudPresupuesto(
			PK_SolicitudPresupuesto pkSolicitudPresupuesto) {
		this.pkSolicitudPresupuesto = pkSolicitudPresupuesto;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Usuario getUsuarioAsignado() {
		return usuarioAsignado;
	}

	public void setUsuarioAsignado(Usuario usuarioAsignado) {
		this.usuarioAsignado = usuarioAsignado;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Edificio getEdificio() {
		return edificio;
	}

	public void setEdificio(Edificio edificio) {
		this.edificio = edificio;
	}

	public String getDetalles() {
		return detalles;
	}

	public void setDetalles(String detalles) {
		this.detalles = detalles;
	}

	public Integer getEstado() {
		return estado;
	}

	public void setEstado(Integer estado) {
		this.estado = estado;
	}

	public Date getFechaSeguimiento() {
		return fechaSeguimiento;
	}

	public void setFechaSeguimiento(Date fechaSeguimiento) {
		this.fechaSeguimiento = fechaSeguimiento;
	}

	public List<NotaSeguimiento> getNotasSeguimiento() {
		return notasSeguimiento;
	}

	public void setNotasSeguimiento(List<NotaSeguimiento> notasSeguimiento) {
		this.notasSeguimiento = notasSeguimiento;
	}

	
	public FormaDePago getFormaDePago() {
		return formaDePago;
	}

	public void setFormaDePago(FormaDePago formaDePago) {
		this.formaDePago = formaDePago;
	}

	public Garantia getGarantia() {
		return garantia;
	}

	public void setGarantia(Garantia garantia) {
		this.garantia = garantia;
	}

	public Integer getSuperficie() {
		return superficie;
	}

	public void setSuperficie(Integer superficie) {
		this.superficie = superficie;
	}

	public Double getLeyesSociales() {
		return leyesSociales;
	}

	public void setLeyesSociales(Double leyesSociales) {
		this.leyesSociales = leyesSociales;
	}

	public Double getCostoBQ() {
		return costoBQ;
	}

	public void setCostoBQ(Double costoBQ) {
		this.costoBQ = costoBQ;
	}

	public Integer getTiempoEjecucionDias() {
		return tiempoEjecucionDias;
	}

	public void setTiempoEjecucionDias(Integer tiempoEjecucionDias) {
		this.tiempoEjecucionDias = tiempoEjecucionDias;
	}

	public Integer getTiempoEjecucionMeses() {
		return tiempoEjecucionMeses;
	}

	public void setTiempoEjecucionMeses(Integer tiempoEjecucionMeses) {
		this.tiempoEjecucionMeses = tiempoEjecucionMeses;
	}

	public Integer getTiempoEjecucionAnios() {
		return tiempoEjecucionAnios;
	}

	public void setTiempoEjecucionAnios(Integer tiempoEjecucionAnios) {
		this.tiempoEjecucionAnios = tiempoEjecucionAnios;
	}

	public Integer getValidezDias() {
		return validezDias;
	}

	public void setValidezDias(Integer validezDias) {
		this.validezDias = validezDias;
	}

	public Integer getValidezMeses() {
		return validezMeses;
	}

	public void setValidezMeses(Integer validezMeses) {
		this.validezMeses = validezMeses;
	}

	public Integer getValidezAnios() {
		return validezAnios;
	}

	public void setValidezAnios(Integer validezAnios) {
		this.validezAnios = validezAnios;
	}

	public SolicitudPresupuesto getSolicitudOrigen() {
		return solicitudOrigen;
	}

	public void setSolicitudOrigen(SolicitudPresupuesto solicitudOrigen) {
		this.solicitudOrigen = solicitudOrigen;
	}

	public List<RenglonSolicitudPresupuesto> getRenglonesPresupuesto() {
		return renglonesPresupuesto;
	}

	public void setRenglonesPresupuesto(
			List<RenglonSolicitudPresupuesto> renglonesPresupuesto) {
		this.renglonesPresupuesto = renglonesPresupuesto;
	}

	public List<NotaImpresionPresupuesto> getNotasImpresionPresupuesto() {
		return notasImpresionPresupuesto;
	}

	public void setNotasImpresionPresupuesto(
			List<NotaImpresionPresupuesto> notasImpresionPresupuesto) {
		this.notasImpresionPresupuesto = notasImpresionPresupuesto;
	}	

	
	
}
