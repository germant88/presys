package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;



@Embeddable
public class PK_NotaSeguimiento implements Serializable {
	
	@ManyToOne
	private SolicitudPresupuesto solicitudPresupuesto;
	
	@Column(name="NUM_NOTA_SEGUIMIENTO")
	private Integer numeroNotaSeguimiento;

	public SolicitudPresupuesto getSolicitudPresupuesto() {
		return solicitudPresupuesto;
	}

	public void setSolicitudPresupuesto(SolicitudPresupuesto solicitudPresupuesto) {
		this.solicitudPresupuesto = solicitudPresupuesto;
	}

	public Integer getNumeroNotaSeguimiento() {
		return numeroNotaSeguimiento;
	}

	public void setNumeroNotaSeguimiento(Integer numeroNotaSeguimiento) {
		this.numeroNotaSeguimiento = numeroNotaSeguimiento;
	}
	
	
	
	
	
	

}
