package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TAREA_RENGLON")
public class TareaRenglon implements Serializable{
  	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    @EmbeddedId
    private PK_TareaRenglon pkTareaRenglon;
	
	@ManyToOne
	@JoinColumn(name="COD_TAREA_X_DEFECTO")
	private Tarea tareaXDefecto;
	
	@Column
	private String Descripcion;


	public Tarea getTareaXDefecto() {
		return tareaXDefecto;
	}

	public void setTareaXDefecto(Tarea tareaXDefecto) {
		this.tareaXDefecto = tareaXDefecto;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	public TareaRenglon() {
		super();
        pkTareaRenglon = new PK_TareaRenglon();
	}	
	
	public PK_TareaRenglon getPkTareaRenglon() {
		return pkTareaRenglon;
	}

	public void setPkTareaRenglon(PK_TareaRenglon pkTareaRenglon) {
		this.pkTareaRenglon = pkTareaRenglon;
	}

	public TareaRenglon(Integer numeroTarea,
			RenglonSolicitudPresupuesto renglonSolicitudPresupuesto,
			Tarea tareaXDefecto, String descripcion) {
		super();
		pkTareaRenglon = new PK_TareaRenglon();
		this.pkTareaRenglon.setNumeroTarea(numeroTarea);				
		this.pkTareaRenglon.setRenglonSolicitudPresupuesto(renglonSolicitudPresupuesto);
		this.tareaXDefecto = tareaXDefecto;
		Descripcion = descripcion;
	}
}
