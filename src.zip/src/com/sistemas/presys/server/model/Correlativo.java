package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CORRELATIVOS")
public class Correlativo implements Serializable{
	
	@Id
	@Column(name="CORR_COD")
	private String codigo;
	@Column(name="CORR_SIG")
	private String siguiente;
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getSiguiente() {
		return siguiente;
	}
	public void setSiguiente(String siguiente) {
		this.siguiente = siguiente;
	}
}
