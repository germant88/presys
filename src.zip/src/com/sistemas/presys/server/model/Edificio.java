package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="EDIFICIO")
public class Edificio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="EDIFICIO_COD")
	private String codigo;
	
	@Column(name="EDIFICIO_NOM")
	private String nombre;
	

	@Column(name="EDIFICIO_DIR")
	private String direccion;
	
	@ManyToOne
	@JoinColumn(name="CLI_COD")
	private Cliente cliente;
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}	
	
	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Edificio(){
		super();
	}		
	
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Edificio(String xcodigo, String xnombre, String xdireccion, Cliente xcliente){
       super();
	   this.codigo    = xcodigo;
       this.nombre    = xnombre;
       this.direccion = xdireccion;
       this.cliente   = xcliente;
	}	
}
