package com.sistemas.presys.server.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;


@Embeddable
public class PK_NotaImpresionPresupuesto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumns({
		@JoinColumn(name = "solicitudpresupuesto_sol_cod", referencedColumnName = "SOL_COD"),
		@JoinColumn(name = "solicitudpresupuesto_sol_tdoc", referencedColumnName = "SOL_TDOC") })
    private SolicitudPresupuesto solicitudPresupuesto;
        
	@Column(name = "NUM_NOTA_IMPRESION")
	private Integer numeroNotaImpresion;

	public SolicitudPresupuesto getSolicitudPresupuesto() {
		return solicitudPresupuesto;
	}

	public void setSolicitudPresupuesto(SolicitudPresupuesto solicitudPresupuesto) {
		this.solicitudPresupuesto = solicitudPresupuesto;
	}

	public Integer getNumeroNotaImpresion() {
		return numeroNotaImpresion;
	}

	public void setNumeroNotaImpresion(Integer numeroNotaImpresion) {
		this.numeroNotaImpresion = numeroNotaImpresion;
	}	
}
