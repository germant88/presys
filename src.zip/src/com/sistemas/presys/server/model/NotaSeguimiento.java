package com.sistemas.presys.server.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="NOTA_SEGUIMIENTO")
public class NotaSeguimiento implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="NOTA_ID")
	private int codigo;*/
	
	@EmbeddedId
	private PK_NotaSeguimiento pkNotaSeguimiento;
			
	@Column(name="NOTA_DESC")
	private String descripcion;
	
	@Column(name="NOTA_SITUACION")
	private String situacion;	
	
	@Column(name="NOTA_FECHA")
	private Date fechaSeguimiento;
	
	@Column(name="NOTA_FECHA_INGRESO")
	private Date fechaIngreso;		
	
	@ManyToOne
	@JoinColumn(name="USU_COD")
	private Usuario usuario;
	/*
	@ManyToOne
	@JoinColumn(name="SOL_COD")
	private SolicitudPresupuesto solicitudPresupuesto;*/
	

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFechaSeguimiento() {
		return fechaSeguimiento;
	}

	public void setFechaSeguimiento(Date fechaSeguimiento) {
		this.fechaSeguimiento = fechaSeguimiento;
	}
	
	
	
	public String getSituacion() {
		return situacion;
	}

	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}

	public Date getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public NotaSeguimiento(Integer numeroNotaSeguimiento, String descripcion,
			Date fechaSeguimiento, Usuario usuario, SolicitudPresupuesto solicitudPresupuesto,
			Date fechaIngreso, String situacion) {
		super();
		pkNotaSeguimiento = new PK_NotaSeguimiento();
		pkNotaSeguimiento.setNumeroNotaSeguimiento(numeroNotaSeguimiento);
		pkNotaSeguimiento.setSolicitudPresupuesto(solicitudPresupuesto);
		this.descripcion = descripcion;
		this.fechaSeguimiento = fechaSeguimiento;
		this.usuario = usuario;
		this.situacion = situacion;
		this.fechaIngreso = fechaIngreso;
	}

	public NotaSeguimiento() {
		super();
		pkNotaSeguimiento = new PK_NotaSeguimiento();
	}
    
	/*public SolicitudPresupuesto getSolicitudPresupuesto() {
		return solicitudPresupuesto;
	}

	public void setSolicitudPresupuesto(SolicitudPresupuesto solicitudPresupuesto) {
		this.solicitudPresupuesto = solicitudPresupuesto;
	}*/

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public PK_NotaSeguimiento getPkNotaSeguimiento() {
		return pkNotaSeguimiento;
	}

	public void setPkNotaSeguimiento(PK_NotaSeguimiento pkNotaSeguimiento) {
		this.pkNotaSeguimiento = pkNotaSeguimiento;
	}	
	
	
}
