package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.NotaImpresion;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface INotaImpresionDAO {

    public List<NotaImpresion> obtenerTodos();
	
	public void agregar(NotaImpresion xnotaimpresion) throws LogicException;
	
	public NotaImpresion obtenerPorCodigo(String xcodigo);
	
	public void eliminar (String xcodigo);
	
	public void modificarNotaImpresion(NotaImpresion xnotaimpresion) ;
	
	public List<NotaImpresion> buscar(Integer buscarPor, String cadena);
	
	public List<NotaImpresion> obtenerNotasDeImpresion(String codigo);
}

