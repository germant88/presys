package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.NotaImpresionPresupuesto;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.RenglonSolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.server.model.TareaRenglon;

@Remote
public interface ISolicitudDAO {

	public void ingresarSolicitud(SolicitudPresupuesto xsolicitud);

	public SolicitudPresupuesto obtenerPorCodigo(PK_SolicitudPresupuesto clave);

	public void modificarSolicitud(SolicitudPresupuesto xsolicitudPresupuesto);
	
	public void cambiarEstadoSolicitud(PK_SolicitudPresupuesto xclave, Integer xestadoNuevo);

	public List<RenglonSolicitudPresupuesto> obtenerRenglonesDeSolicitud(PK_SolicitudPresupuesto clave);
	
	public List<TareaRenglon> obtenerTareasDeRenglon(RenglonSolicitudPresupuesto xRenglon);
	
	public List<NotaImpresionPresupuesto> obtenerNotasImpresionDePresupuesto(PK_SolicitudPresupuesto clave);
			
}
