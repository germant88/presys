package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.NotaSeguimiento;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.shared.excepciones.LogicException;

@Stateless
public class NotaSeguimientoDAO implements INotaSeguimientoDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	@Override
	public void agregar(NotaSeguimiento xnotaSeguimiento) throws LogicException {	
		if (xnotaSeguimiento != null) {
			em.persist(xnotaSeguimiento);
		}
		else {
			throw new LogicException("No se puede agregar la nota se seguimiento porque es \"null\"");
		}
	}	
	
	public List<NotaSeguimiento> obtenerNotasDeSolicitud(PK_SolicitudPresupuesto clave){
		 List<NotaSeguimiento> resultado;
		 
		 SolicitudPresupuesto solicitudPresupuesto = em.find(SolicitudPresupuesto.class, clave);
		 			
		String query = "SELECT n FROM NotaSeguimiento n WHERE pkNotaSeguimiento.solicitudPresupuesto = :solicitud";
		
		resultado = em.createQuery(query).setParameter("solicitud", solicitudPresupuesto).getResultList();
		
		return resultado;
	}
}
