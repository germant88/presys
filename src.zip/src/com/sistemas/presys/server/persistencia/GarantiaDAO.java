package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.model.Garantia;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class GarantiaDAO implements IGarantiaDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
	@Override
	public List<Garantia> obtenerTodos() {
        List<Garantia> resultado;
		
		String query = "SELECT g FROM  Garantia g";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}

	@Override
	public void agregar(Garantia garantia) throws LogicException {
		if (garantia != null) {			
			em.persist(garantia);
		}
		else {
			throw new LogicException("No se puede agregar la garantia porque se recibi� un valor \"null\"");
		}		
	}

	@Override
	public Garantia obtenerPorCodigo(String codigo) {
        Garantia garantia;
		
        garantia = em.find(Garantia.class, codigo);
		
		return garantia;
	}

	@Override
	public void eliminar(String codigo) {
        Garantia garantia;
		
        garantia = em.find(Garantia.class, codigo);
		
		em.remove(garantia);
	}

	@Override
	public void modificar(Garantia garantia) {
		if (garantia != null) {
			Garantia garantiaAModificar;
			
			garantiaAModificar = em.find(Garantia.class, garantia.getCodigo());
			
			garantiaAModificar.setNombre(garantia.getNombre());
			
			garantiaAModificar.setAnios(garantia.getAnios());
			garantiaAModificar.setMeses(garantia.getMeses());
			garantiaAModificar.setDias(garantia.getDias());
		}
	}

	@Override
	public List<Garantia> buscar(Integer buscarPor, String cadena) {
        List<Garantia> resultado;
		
		String query = "SELECT g FROM Garantia g ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(g.codigo) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(g.nombre) LIKE LOWER('%" + cadena +"%') ";
		}		
				
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
}
