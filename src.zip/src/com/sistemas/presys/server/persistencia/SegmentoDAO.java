package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Segmento;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class SegmentoDAO implements ISegmentoDAO {
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
		
	@Override
	public List<Segmento> obtenerTodos() {
        List<Segmento> resultado;
		
		String query = "SELECT s FROM Segmento s";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}

	@Override
	public void agregar(Segmento xsegmento) throws LogicException {
		if (xsegmento != null) {
			em.persist(xsegmento);
		}
		else {
			throw new LogicException("No se puede agregar el segmento porque el segmento recibido es \"null\"");
		}
	}

	@Override
	public Segmento obtenerPorCodigo(String xcodigo) {
		Segmento segmento;
		
		segmento = em.find(Segmento.class, xcodigo);
		
		return segmento;
	}

	@Override
	public void eliminar(String xcodigo) {
        Segmento segmento;
		
        segmento = em.find(Segmento.class, xcodigo);
		
		em.remove(segmento);
	}

	@Override
	public void modificarSegmento(Segmento xsegmento) {
		if (xsegmento != null) {
			Segmento segmentoAModificar;
			
			segmentoAModificar = em.find(Segmento.class, xsegmento.getCodigo());
			
			segmentoAModificar.setNombre(xsegmento.getNombre());
			segmentoAModificar.setDescripcion(xsegmento.getDescripcion());
			segmentoAModificar.setHabilitado(xsegmento.getHabilitado());			
		}
	}

	@Override
	public List<Segmento> buscar(Integer buscarPor, String cadena) {
        List<Segmento> resultado;
		
		String query = "SELECT s FROM Segmento s ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(s.codigo) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(s.nombre) LIKE LOWER('%" + cadena +"%') ";
		}
				
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
}
