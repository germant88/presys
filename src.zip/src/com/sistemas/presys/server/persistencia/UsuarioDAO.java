package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Usuario;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class UsuarioDAO implements IUsuarioDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
	public List<Usuario> obtenerTodos(){
       List<Usuario> resultado;
		
		String query = "SELECT u FROM Usuario u";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}


	@Override
	public Usuario obtenerPorCodigo(String codigo) {
		Usuario usuario;
		
		usuario = em.find(Usuario.class, codigo);
		
		return usuario;
		
	}


	@Override
	public void agregar(Usuario usuario) throws LogicException {
		if (usuario != null) {
			em.persist(usuario);
		}
		else {
			throw new LogicException("No se puede agregar el usuario porque el usuario recibido es \"null\"");
		}		
	}


	@Override
	public void eliminar(String id) {
        Usuario usuario;
		
		usuario = em.find(Usuario.class, id);
		
		em.remove(usuario);		
	}


	@Override
	public void modificar(Usuario xusuario, Boolean cambiarContrasena) {
		if (xusuario != null) {
			Usuario usuarioAModificar;
			
			usuarioAModificar = em.find(Usuario.class, xusuario.getUsuario_id());
			
			usuarioAModificar.setNombre(xusuario.getNombre());
			usuarioAModificar.setApellido(xusuario.getApellido());			
			if (cambiarContrasena) {
			   usuarioAModificar.setPassword(xusuario.getPassword());
			}
			usuarioAModificar.setRoles(xusuario.getRoles());
		}		
	}


	@Override
	public List<Usuario> buscar(Integer buscarPor, String text) {
        List<Usuario> resultado;
		
		String query = "SELECT u FROM Usuario u ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(u.usuario_id) LIKE LOWER('%" + text +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(u.nombre) LIKE LOWER('%" + text +"%') ";
		}
				
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
}