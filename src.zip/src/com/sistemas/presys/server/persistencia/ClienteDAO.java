package com.sistemas.presys.server.persistencia;


import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Cliente;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ClienteDAO implements IClienteDAO{

	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
	public void agergarCliente(Cliente xcliente) {
			if (xcliente != null) {
				em.persist(xcliente);
			}
	}
	
	public Cliente modificarCliente(Cliente xcliente) {
		if (xcliente != null) {
			Cliente clienteAModificar;
			
			clienteAModificar = em.find(Cliente.class, xcliente.getCodigo());
			
			clienteAModificar.setNombre(xcliente.getNombre());
			clienteAModificar.setDireccion(xcliente.getDireccion());
			clienteAModificar.setEmail(xcliente.getEmail());
			clienteAModificar.setRut(xcliente.getRut());
			clienteAModificar.setTelefono(xcliente.getTelefono());
			clienteAModificar.setContactoEmail(xcliente.getContactoEmail());
			clienteAModificar.setContactoNombre(xcliente.getContactoNombre());
			clienteAModificar.setContactoTelefono(xcliente.getContactoTelefono());
			clienteAModificar.setSegmento(xcliente.getSegmento());
			
			return clienteAModificar;
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<Cliente> obtenerClientes(){
		List<Cliente> resultado;
		
		String query = "SELECT c FROM Cliente c";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
	
	public List<Cliente> buscarClientes(Integer buscarPor, String cadena){
        List<Cliente> resultado;
		
		String query = "SELECT c FROM Cliente c ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(c.codigo) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(c.nombre) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_RUT) {
			query += "WHERE LOWER(c.rut) LIKE LOWER('%" + cadena + "%') ";
		}
		
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
	
	public void eliminarCliente(String codigo){
		Cliente clienteAEliminar;
		
		clienteAEliminar = em.find(Cliente.class, codigo);
	
		em.remove(clienteAEliminar);		
	}
	
	public Cliente obtenerPorCodigo(String codigo) {
		Cliente cliente;
		
		cliente = em.find(Cliente.class, codigo);
		
	    return cliente;
	}
}
