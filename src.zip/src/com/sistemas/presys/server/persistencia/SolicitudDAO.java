package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.NotaImpresionPresupuesto;
import com.sistemas.presys.server.model.NotaSeguimiento;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.RenglonSolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.server.model.TareaRenglon;

@Stateless	
public class SolicitudDAO implements ISolicitudDAO{
	
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	@EJB
	INotaSeguimientoDAO notaSeguimientoDAO;
	
	
	@Override
	public void ingresarSolicitud(SolicitudPresupuesto xsolicitud) {
	   if (xsolicitud != null) {
		   em.persist(xsolicitud);
	   }
	}
	
	@Override
	public SolicitudPresupuesto obtenerPorCodigo(PK_SolicitudPresupuesto clave) {
		SolicitudPresupuesto solicitud;
		
		solicitud = em.find(SolicitudPresupuesto.class, clave);
		
		return solicitud;
	}
	
	public void modificarSolicitud(SolicitudPresupuesto xsolicitudPresupuesto) {
		if (xsolicitudPresupuesto != null) {
			
			//List<NotaSeguimiento> lista = notaSeguimientoDAO.obtenerNotasDeSolicitud(xsolicitudPresupuesto.getCodigo());
			
			//for (NotaSeguimiento unaNota : lista) {				
			//	em.remove(unaNota);
			//}
			
			SolicitudPresupuesto solicitudAModificar;
			
			solicitudAModificar = em.find(SolicitudPresupuesto.class, xsolicitudPresupuesto.getPkSolicitudPresupuesto());
			
			solicitudAModificar.setCliente(xsolicitudPresupuesto.getCliente());
			solicitudAModificar.setEdificio(xsolicitudPresupuesto.getEdificio());
			solicitudAModificar.setDetalles(xsolicitudPresupuesto.getDetalles());
			solicitudAModificar.setEstado(xsolicitudPresupuesto.getEstado());
			solicitudAModificar.setFecha(xsolicitudPresupuesto.getFecha());
			solicitudAModificar.setFormaDePago(xsolicitudPresupuesto.getFormaDePago());
			solicitudAModificar.setGarantia(xsolicitudPresupuesto.getGarantia());
			solicitudAModificar.setSuperficie(xsolicitudPresupuesto.getSuperficie());
			solicitudAModificar.setLeyesSociales(xsolicitudPresupuesto.getLeyesSociales());
			solicitudAModificar.setCostoBQ(xsolicitudPresupuesto.getCostoBQ());
			solicitudAModificar.setTiempoEjecucionDias(xsolicitudPresupuesto.getTiempoEjecucionDias());
			solicitudAModificar.setTiempoEjecucionMeses(xsolicitudPresupuesto.getTiempoEjecucionMeses());
			solicitudAModificar.setTiempoEjecucionAnios(xsolicitudPresupuesto.getTiempoEjecucionAnios());
			solicitudAModificar.setValidezDias(xsolicitudPresupuesto.getValidezDias());
			solicitudAModificar.setValidezMeses(xsolicitudPresupuesto.getValidezMeses());
			solicitudAModificar.setValidezAnios(xsolicitudPresupuesto.getValidezAnios());
			//solicitudAModificar.setNotasSeguimiento(xsolicitudPresupuesto.getNotasSeguimiento());
			
			for (NotaSeguimiento nota : solicitudAModificar.getNotasSeguimiento()) {
				em.remove(nota);				
			}
			
			solicitudAModificar.getNotasSeguimiento().clear();
			
			em.flush();
			
			
			for (NotaSeguimiento nota : xsolicitudPresupuesto.getNotasSeguimiento()) {                   				
				nota.getPkNotaSeguimiento().setSolicitudPresupuesto(solicitudAModificar);
				solicitudAModificar.getNotasSeguimiento().add(nota);								
			}
			
			solicitudAModificar.setUsuarioAsignado(xsolicitudPresupuesto.getUsuarioAsignado());
			solicitudAModificar.setFechaSeguimiento(xsolicitudPresupuesto.getFechaSeguimiento());
													
			//for (NotaSeguimiento nota : solicitudAModificar.getNotasSeguimiento()) {                   
			//	nota.getPkNotaSeguimiento().setSolicitudPresupuesto(solicitudAModificar);				
			//}
			
			em.merge(solicitudAModificar);									
		}		
	}

	@Override
	public void cambiarEstadoSolicitud(PK_SolicitudPresupuesto xclave, Integer xestadoNuevo) {
       if (xclave != null) {
    	   if (!xclave.getCodigo().trim().equals("")) {
    		   SolicitudPresupuesto solicitudAModificar;
    		   solicitudAModificar = em.find(SolicitudPresupuesto.class, xclave);
    		   
    		   solicitudAModificar.setEstado(xestadoNuevo);    		       		  
    	   }
       }
		
	}

	@Override
	public List<RenglonSolicitudPresupuesto> obtenerRenglonesDeSolicitud(PK_SolicitudPresupuesto clave) {
    
		 List<RenglonSolicitudPresupuesto> resultado;
		 
		 SolicitudPresupuesto solicitudPresupuesto = em.find(SolicitudPresupuesto.class, clave);
		 			
		String query = "SELECT r FROM RenglonSolicitudPresupuesto r WHERE pkRenglonSolicitudPresupuesto.solicitudPresupuesto = :solicitud";
		
		resultado = em.createQuery(query).setParameter("solicitud", solicitudPresupuesto).getResultList();			
		
		return resultado;
	}
	
	public List<TareaRenglon> obtenerTareasDeRenglon(RenglonSolicitudPresupuesto xRenglon){
		
		List<TareaRenglon> resultado;
		
		RenglonSolicitudPresupuesto renglon = em.find(RenglonSolicitudPresupuesto.class, xRenglon.getPkRenglonSolicitudPresupuesto());
		
		String query = "SELECT t from TareaRenglon t WHERE pkTareaRenglon.renglonSolicitudPresupuesto = :rengSolicitudPresupuesto";
		
		resultado = em.createQuery(query).setParameter("rengSolicitudPresupuesto", xRenglon).getResultList();
		
		return resultado;		
		
	}

	@Override
	public List<NotaImpresionPresupuesto> obtenerNotasImpresionDePresupuesto(PK_SolicitudPresupuesto clave) {
	   List<NotaImpresionPresupuesto> resultado;
	   
	   SolicitudPresupuesto presupuesto = em.find(SolicitudPresupuesto.class,  clave);
	   
	   String query = "SELECT n from NotaImpresionPresupuesto n WHERE pkNotaImpresionPresupuesto.solicitudPresupuesto = :presupuesto";
	   
	   resultado = em.createQuery(query).setParameter("presupuesto", presupuesto).getResultList();
	   
	   return resultado;
	}

}
