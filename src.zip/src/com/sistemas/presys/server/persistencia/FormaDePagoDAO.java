package com.sistemas.presys.server.persistencia;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class FormaDePagoDAO implements IFormaDePagoDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
	public List<FormaDePago> obtenerTodos() {
        List<FormaDePago> resultado;
		
		String query = "SELECT f FROM  FormaDePago f";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}

	
	public void agregar(FormaDePago formaDePago) throws LogicException {
		if (formaDePago != null) {			
			em.persist(formaDePago);
		}
		else {
			throw new LogicException("No se puede agregar la forma de pago porque se recibi� un valor \"null\"");
		}
	}

	
	public FormaDePago obtenerPorCodigo(String codigo) {
        FormaDePago formaDePago;
		
		formaDePago = em.find(FormaDePago.class, codigo);
		
		return formaDePago;
	}

	
	public void eliminar(String codigo) {
        FormaDePago formaDePago;
		
        formaDePago = em.find(FormaDePago.class, codigo);
		
		em.remove(formaDePago);		
	}

	
	public void modificar(FormaDePago formaDePago) {
		if (formaDePago != null) {
			FormaDePago FPAModificar;
			
			FPAModificar = em.find(FormaDePago.class, formaDePago.getCodigo());
			
			FPAModificar.setNombre(formaDePago.getNombre());
			FPAModificar.setDescripcion(formaDePago.getDescripcion());
		}
	}

	
	public List<FormaDePago> buscar(Integer buscarPor, String cadena) {
        List<FormaDePago> resultado;
		
		String query = "SELECT f FROM FormaDePago f ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(f.codigo) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(f.nombre) LIKE LOWER('%" + cadena +"%') ";
		}		
				
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
		
}
