package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.NotaSeguimiento;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface INotaSeguimientoDAO {

	public void agregar(NotaSeguimiento notaSeguimiento) throws LogicException;
	
	public List<NotaSeguimiento> obtenerNotasDeSolicitud(PK_SolicitudPresupuesto clave);
}
