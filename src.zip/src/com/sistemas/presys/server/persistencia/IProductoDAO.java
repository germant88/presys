package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Producto;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IProductoDAO {

	public List<Producto> obtenerTodos();
	
	public void agregar(Producto xproducto) throws LogicException;
	
	public Producto obtenerPorCodigo(String xcodigo);
	
	public void eliminar (String xcodigo);
	
	public void modificarProducto(Producto xproducto) ;
	
	public List<Producto> buscar(Integer buscarPor, String cadena);
}
