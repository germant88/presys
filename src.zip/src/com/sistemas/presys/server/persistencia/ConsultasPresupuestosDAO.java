package com.sistemas.presys.server.persistencia;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;

@Stateless
public class ConsultasPresupuestosDAO  implements IConsultasPresupuestosDAO{

	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	public List<Object> obtenerListaPresupuestos(Date fechaDesde,
			Date fechaHasta, String codigo, ArrayList<Integer> estados, ArrayList<String> tiposDocumentos, String xcliente, String xedificio, String xproducto){
		List<Object> resultado = null;
		
		boolean primerCondicion  = true;
		boolean filtrarCodigo    = false;
		boolean filtrarFechas    = false;
		boolean filtrarEstados   = false;
		boolean filtrarTiposDocs = false;
		boolean filtrarCliente   = false;
		boolean filtrarEdificio  = false;
		boolean filtrarProducto  = false;
				
		try {
					
		String sentencia = "SELECT SOL_COD, SOL_FEC, USU_COD, CLI_COD, EDIFICIO_COD, SOL_DETALLES, SOL_ESTADO, SOL_FECSEGUIMIENTO, SOL_TDOC FROM solicitud_presupuesto";
		
		
		
		SimpleDateFormat formateador = new SimpleDateFormat("dd/MM/yyyy");
		
		if ((fechaDesde != null) &&(fechaHasta != null)) { 
			if  (fechaDesde.after(formateador.parse("01/01/1900")) && fechaHasta.after(formateador.parse("01/01/1900"))) {	
			   filtrarFechas = true;
			}
		}
		
		if (codigo != null){
			if (codigo != "") {
				filtrarCodigo = true;	
			}
		}	
		
		if (estados != null) {
			if (estados.size() > 0) {
				filtrarEstados = true;
			}			
		}
		
		if (tiposDocumentos != null) {
			if (tiposDocumentos.size() > 0) {
				filtrarTiposDocs = true;
			}
		}
		
		if (xcliente != null) {
			if (xcliente.trim().equals("") == false) {
				filtrarCliente = true;
			}
		}
		
		if (xedificio != null) {
			if (xedificio.trim().equals("") == false){
				filtrarEdificio = true;
			}
		}
		
		if (xproducto != null) {
			if (xproducto.trim().equals("") == false) {
				filtrarProducto = true;
			}
			
		}
		
		if (filtrarProducto) {
			sentencia += " S INNER JOIN reng_sol_pres R ON S.sol_cod = R.pres_cod "; // ... joinear con renglones para poder filtrar por producto, terminar filtros por producto y edificio.
			
		}
		
		
		if (filtrarFechas || filtrarCodigo || filtrarEstados || filtrarTiposDocs || filtrarCliente  || filtrarEdificio) {			
	           sentencia += " WHERE ";				
		}		
		
			if (filtrarCodigo) {
				sentencia += " LOWER(SOL_COD) LIKE :codigo ";
				primerCondicion = false;
			}
		
			
			if (filtrarFechas) {					
				   if (primerCondicion == false) {
					   sentencia += " AND ";
				   }				   
				   sentencia += " to_date(to_char(SOL_FEC, 'dd/MM/yyyy'), 'dd/MM/yyyy') BETWEEN :fechaDesde AND :fechaHasta ";
				   primerCondicion = false;
			}
			
			if (filtrarEstados) {
				if (primerCondicion == false) {
					sentencia += " AND ";
				}
				
				String cadenaEstados = "";
				boolean primerPasada = true;
				
				for (Integer unEstado : estados) {				   
					cadenaEstados += (primerPasada ? "" : "," ) + unEstado.toString();
					primerPasada = false;
				}
				 				
				sentencia += " SOL_ESTADO IN (" + cadenaEstados + ") " ;
				primerCondicion = false;
			}
			
			if (filtrarTiposDocs) {
				if (primerCondicion == false) {
					sentencia += " AND ";
				}
				
				String cadenaTiposDocumentos = "";
				boolean primerPasada = true;
				
				for (String unTipoDoc : tiposDocumentos) {
					cadenaTiposDocumentos += (primerPasada ? "" : ", ") + "'" + unTipoDoc + "' ";
					primerPasada = false;
				}
				
				sentencia += " SOL_TDOC IN (" + cadenaTiposDocumentos + ")";
				primerCondicion = false;
			}
			
			if (filtrarCliente) {
				if (primerCondicion == false) {
					sentencia += " AND ";
				}
				
				sentencia += " CLI_COD = :cliente ";
			}
			
			if (filtrarEdificio) {
				if (primerCondicion == false) {
					sentencia += " AND ";
				}
				
				sentencia += " EDIFICIO_COD = :edificio ";
			}
			
			if (filtrarProducto) {
				if (primerCondicion == false) {
					sentencia += " AND ";
				}
				sentencia += " R.ren_prod = :producto ";
			}
			
			
		Query  q = 	em.createNativeQuery(sentencia);
		
		if (filtrarCodigo) {
			q.setParameter("codigo","%" + codigo.toLowerCase().trim() + "%");	
		}
		
		if (filtrarFechas) {			
			q.setParameter("fechaDesde", fechaDesde);
			q.setParameter("fechaHasta", fechaHasta);	
		}
		
		if (filtrarCliente) {
			q.setParameter("cliente", xcliente);
		}
		
		if (filtrarEdificio) {
			q.setParameter("edificio", xedificio);
		}
		
		if (filtrarProducto) {
			q.setParameter("producto", xproducto);
		}
		
		resultado = q.getResultList();
		
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return resultado;			
	}
	
	public SolicitudPresupuesto obtenerDocumentoPadreDeDocumento(PK_SolicitudPresupuesto claveDocumento) {
        List<SolicitudPresupuesto> resultado;
        
        SolicitudPresupuesto solicitud = em.find(SolicitudPresupuesto.class, claveDocumento);
        
        String query = " SELECT d FROM SolicitudPresupuesto d WHERE d.solicitudOrigen = :documento  ";
        
        resultado = em.createQuery(query).setParameter("documento", solicitud).getResultList();
		
		if (resultado.size() > 0)  {
			return resultado.get(0);	
		}
		else {
			return null;
		}
	}
	
}
