package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Producto;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class ProductoDAO implements IProductoDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Producto> obtenerTodos() {
		List<Producto> resultado;
		
		String query = "SELECT p FROM Producto p";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}	
	
	public void agregar(Producto xproducto) throws LogicException {
		if (xproducto != null) {
			em.persist(xproducto);
		}
		else {
			throw new LogicException("No se puede agregar el producto porque el producto recibido es \"null\"");
		}
	}
	
	public Producto obtenerPorCodigo (String xcodigo) {
		Producto producto;
		
		producto = em.find(Producto.class, xcodigo);
		
		return producto;
	}
	
	public void eliminar (String xcodigo) {
		Producto producto;
		
		producto = em.find(Producto.class, xcodigo);
		
		em.remove(producto);
	}
	
	
	public void modificarProducto(Producto xproducto) {
		if (xproducto != null) {
			Producto productoAModificar;
			
			productoAModificar = em.find(Producto.class, xproducto.getCodigo());
			
			productoAModificar.setNombre(xproducto.getNombre());
			productoAModificar.setDescripcion(xproducto.getDescripcion());
			productoAModificar.setHabilitado(xproducto.getHabilitado());			
		}
	}
	
	
	public List<Producto> buscar(Integer buscarPor, String cadena){
        List<Producto> resultado;
		
		String query = "SELECT p FROM Producto p ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(p.codigo) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(p.nombre) LIKE LOWER('%" + cadena +"%') ";
		}
				
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
}
