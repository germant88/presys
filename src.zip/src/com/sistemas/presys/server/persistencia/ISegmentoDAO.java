package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Segmento;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface ISegmentoDAO {

    public List<Segmento> obtenerTodos();
	
	public void agregar(Segmento xsegmento) throws LogicException;
	
	public Segmento obtenerPorCodigo(String xcodigo);
	
	public void eliminar (String xcodigo);
	
	public void modificarSegmento(Segmento xsegmento) ;
	
	public List<Segmento> buscar(Integer buscarPor, String cadena);

	
}
