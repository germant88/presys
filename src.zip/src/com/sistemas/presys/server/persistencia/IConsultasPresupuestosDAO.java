package com.sistemas.presys.server.persistencia;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.server.model.SolicitudPresupuesto;

@Remote
public interface IConsultasPresupuestosDAO {
	
	public List<Object> obtenerListaPresupuestos(Date fechaDesde,
			Date fechaHasta, String codigo, ArrayList<Integer> estados, ArrayList<String> tiposDocumentos, String xcliente, String xedificio, String xproducto); 
	
	public SolicitudPresupuesto obtenerDocumentoPadreDeDocumento(PK_SolicitudPresupuesto claveDocumento);
}
