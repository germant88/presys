package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Tarea;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface ITareaDAO {

    public List<Tarea> obtenerTodos();
	
	public void agregar(Tarea xtarea) throws LogicException;
	
	public Tarea obtenerPorCodigo(String xcodigo);
	
	public void eliminar (String xcodigo);
	
	public void modificarTarea(Tarea xtarea) ;
	
	public List<Tarea> buscar(Integer buscarPor, String cadena);
	
}

