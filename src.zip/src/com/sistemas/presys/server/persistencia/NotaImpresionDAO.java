package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.NotaImpresion;
import com.sistemas.presys.server.model.SolicitudPresupuesto;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class NotaImpresionDAO implements INotaImpresionDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	@SuppressWarnings("unchecked")	
	@Override
	public List<NotaImpresion> obtenerTodos() {
		List<NotaImpresion> resultado;
			
		String query = "SELECT n FROM NotaImpresion n";
			
		resultado = em.createQuery(query).getResultList();
			
		return resultado;
	}

	@Override
	public void agregar(NotaImpresion xnotaimpresion) throws LogicException {
		if (xnotaimpresion != null) {
			em.persist(xnotaimpresion);
		}
		else {
			throw new LogicException("No se puede agregar la nota de impresi�n porque se recibio \"null\"");
		}		
	}

	@Override
	public NotaImpresion obtenerPorCodigo(String xcodigo) {
        NotaImpresion notaImpresion;
		
		notaImpresion = em.find(NotaImpresion.class, xcodigo);
		
		return notaImpresion;
	}

	@Override
	public void eliminar(String xcodigo) {
        NotaImpresion notaImpresion;
		
		notaImpresion = em.find(NotaImpresion.class, xcodigo);
		
		em.remove(notaImpresion);		
	}

	@Override
	public void modificarNotaImpresion(NotaImpresion xnotaimpresion) {
		if (xnotaimpresion != null) {
			NotaImpresion notaAModificar;
			
			notaAModificar = em.find(NotaImpresion.class, xnotaimpresion.getCodigo());
			
			notaAModificar.setNombre(xnotaimpresion.getNombre());
			notaAModificar.setDescripcion(xnotaimpresion.getDescripcion());
		}		
	}

	@Override
	public List<NotaImpresion> buscar(Integer buscarPor, String cadena) {
	    List<NotaImpresion> resultado;
		
		String query = "SELECT n FROM NotaImpresion n ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(n.codigo) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(n.nombre) LIKE LOWER('%" + cadena +"%') ";
		}
				
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}
	
	public List<NotaImpresion> obtenerNotasDeImpresion(String codigo){
		 List<NotaImpresion> resultado;
		 
		 SolicitudPresupuesto solicitudPresupuesto = em.find(SolicitudPresupuesto.class, codigo);
		 			
		String query = "SELECT n FROM NotaImpresion n WHERE pkNotaImpresion.solicitudPresupuesto = :solicitud";
		
		resultado = em.createQuery(query).setParameter("solicitud", solicitudPresupuesto).getResultList();
		
		return resultado;
	}

}
