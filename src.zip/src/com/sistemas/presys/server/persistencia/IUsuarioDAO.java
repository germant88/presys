package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Usuario;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IUsuarioDAO {

	public List<Usuario> obtenerTodos();

	public Usuario obtenerPorCodigo(String codigo);

	public void agregar(Usuario usuario) throws LogicException;

	public void eliminar(String id);

	public void modificar(Usuario usuario, Boolean cambiarContrasena);

	public List<Usuario> buscar(Integer buscarPor, String text);	
	
}
