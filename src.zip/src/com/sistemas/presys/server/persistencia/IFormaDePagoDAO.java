package com.sistemas.presys.server.persistencia;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;

@Remote
public interface IFormaDePagoDAO {
	
	public List<FormaDePago> obtenerTodos();
	
	public void agregar(FormaDePago formaDePago) throws LogicException;
	
	public FormaDePago obtenerPorCodigo(String codigo);

	
	public void eliminar(String codigo);
	
	public void modificar(FormaDePago formaDePago) ;
	
	public List<FormaDePago> buscar(Integer buscarPor, String cadena);
}
