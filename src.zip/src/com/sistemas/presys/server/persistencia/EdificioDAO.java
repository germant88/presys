package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Cliente;
import com.sistemas.presys.server.model.Edificio;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class EdificioDAO implements IEdificioDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
		
	@Override
	public List<Edificio> obtenerTodos() {
        List<Edificio> resultado;
		
		String query = "SELECT e FROM Edificio e";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}

	@Override
	public void agregar(Edificio xedificio) throws LogicException {
		if (xedificio != null) {			
			em.persist(xedificio);
		}
		else {
			throw new LogicException("No se puede agregar el edificio porque el edificio recibido es \"null\"");
		}
	}

	@Override
	public Edificio obtenerPorCodigo(String xcodigo) {
        Edificio edificio;
		
		edificio = em.find(Edificio.class, xcodigo);
		
		return edificio;
	}

	@Override
	public void eliminar(String xcodigo) {
        Edificio edificio;
		
        edificio = em.find(Edificio.class, xcodigo);
		
		em.remove(edificio);		
	}

	@Override
	public void modificarEdificio(Edificio xedificio) {
		if (xedificio != null) {
			Edificio edificioAModificar;
			
			edificioAModificar = em.find(Edificio.class, xedificio.getCodigo());
			
			edificioAModificar.setNombre(xedificio.getNombre());
			edificioAModificar.setDireccion(xedificio.getDireccion());
			edificioAModificar.setCliente(xedificio.getCliente());
		}
	}

	@Override
	public List<Edificio> buscar(Integer buscarPor, String cadena) {
        List<Edificio> resultado;		
        
        String query = "SELECT e FROM Edificio e ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(e.codigo) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(e.nombre) LIKE LOWER('%" + cadena +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_DIR) {
			query += " WHERE LOWER(e.direccion) LIKE LOWER('%" + cadena +"%') ";
		}
				
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
				
	}

	@Override
	public List<Edificio> obtenerEdificiosDeCliente(String codigoCliente) {
		List<Edificio> resultado;
		
		Cliente cliente = em.find(Cliente.class, codigoCliente);
		
		String query = "SELECT e FROM Edificio e WHERE e.cliente = :cliente";
		
		resultado = em.createQuery(query).setParameter("cliente", cliente).getResultList();
		
        return resultado;		
	}

	@Override
	public List<Edificio> buscarEdificioDeCliente(Integer buscarPor,
			String text, String codigoCliente) {
        List<Edificio> resultado;
        
        Cliente cliente = em.find(Cliente.class, codigoCliente);
        
        String query = "SELECT e FROM Edificio e ";
		
		if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
			query += " WHERE LOWER(e.codigo) LIKE LOWER('%" + text +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
			query += " WHERE LOWER(e.nombre) LIKE LOWER('%" + text +"%') ";
		}
		else if (buscarPor == Ctes.K_BUSCAR_X_DIR) {
			query += " WHERE LOWER(e.direccion) LIKE LOWER('%" + text +"%') ";
		}		
		if ((codigoCliente != null) && (codigoCliente.trim() != null) ) {
			query += " AND e.cliente = :cliente";
			resultado = em.createQuery(query).setParameter("cliente", cliente).getResultList();
		}
		else {
			resultado = em.createQuery(query).getResultList();	
		}								
		
		return resultado;
	}
	

}
