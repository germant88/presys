package com.sistemas.presys.server.persistencia;

import java.util.Formatter;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Correlativo;

@Stateless
public class CorrelativoDAO implements ICorrelativoDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	
	public Correlativo ObtenerPorCodigo(String codigo){
		Correlativo correlativo;
		
		correlativo = em.find(Correlativo.class, codigo);
		
		if (correlativo != null) {
			return correlativo;
		}
		
		return null;
	}
	
	public void actualizarCorrelativo(String codigo){
		Integer siguiente;
		
		Correlativo correlativoAActualizar;
		
		correlativoAActualizar = em.find(Correlativo.class, codigo);
		
		siguiente = Integer.parseInt(correlativoAActualizar.getSiguiente());
		
		siguiente += 1;
			 
		Formatter fmt = new Formatter();
		
		fmt.format("%010d",siguiente);
		
		correlativoAActualizar.setSiguiente(fmt.toString());		
	}
}
