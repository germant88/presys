package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Tarea;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

@Stateless
public class TareaDAO implements ITareaDAO{
	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	@Override	
	public List<Tarea> obtenerTodos() {
	    List<Tarea> resultado;
		
		String query = "SELECT t FROM Tarea t";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}

	@Override
	public void agregar(Tarea xtarea) throws LogicException {
		if (xtarea != null) {
			em.persist(xtarea);
		}
		else {
			throw new LogicException("No se puede agregar el producto porque el producto recibido es \"null\"");
		}		
	}

	@Override
	public Tarea obtenerPorCodigo(String xcodigo) {
        Tarea tarea;
		
		tarea = em.find(Tarea.class, xcodigo);
		
		return tarea;
	}

	@Override
	public void eliminar(String xcodigo) {
        Tarea tarea;
		
		tarea = em.find(Tarea.class, xcodigo);
		
		em.remove(tarea);		
	}

	@Override
	public void modificarTarea(Tarea xtarea) {
		if (xtarea != null) {
			Tarea tareaAModificar;
			
			tareaAModificar = em.find(Tarea.class, xtarea.getCodigo());
			
			tareaAModificar.setNombre(xtarea.getNombre());
			tareaAModificar.setDescripcion(xtarea.getDescripcion());
		}		
	}

	@Override
	public List<Tarea> buscar(Integer buscarPor, String cadena) {
		    List<Tarea> resultado;
			
			String query = "SELECT t FROM Tarea t ";
			
			if (buscarPor ==  Ctes.K_BUSCAR_X_COD) {
				query += " WHERE LOWER(t.codigo) LIKE LOWER('%" + cadena +"%') ";
			}
			else if (buscarPor == Ctes.K_BUSCAR_X_NOM) {
				query += " WHERE LOWER(t.nombre) LIKE LOWER('%" + cadena +"%') ";
			}
					
			resultado = em.createQuery(query).getResultList();
			
			return resultado;
	}

}
