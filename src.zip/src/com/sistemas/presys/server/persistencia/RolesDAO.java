package com.sistemas.presys.server.persistencia;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sistemas.presys.server.model.Rol;
import com.sistemas.presys.shared.datatypes.DTRol;

@Stateless
public class RolesDAO implements IRolesDAO{

	@PersistenceContext(unitName="PRESYS")
	private EntityManager em;
	
	@Override
	public List<Rol> obtenerRoles() {
		List<Rol> resultado;
		
		String query = "SELECT r FROM Rol r";
		
		resultado = em.createQuery(query).getResultList();
		
		return resultado;
	}

	@Override
	public Rol obtenerPorCodigo(String id) {
	    Rol rol;
		
	    rol = em.find(Rol.class, id);
		
		return rol;
	}

	@Override
	public ArrayList<DTRol> obtenerRolesDeUsuario(String codigoUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

}
