package com.sistemas.presys.server.persistencia;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Rol;
import com.sistemas.presys.shared.datatypes.DTRol;

@Remote
public interface IRolesDAO {
   public List<Rol> obtenerRoles();

public Rol obtenerPorCodigo(String id);

public ArrayList<DTRol> obtenerRolesDeUsuario(String codigoUsuario);
}
