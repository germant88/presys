package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Cliente;

@Remote
public interface IClienteDAO {

	public void agergarCliente(Cliente xcliente);
	
	public Cliente modificarCliente(Cliente xcliente);
	
	public List<Cliente> obtenerClientes();
	
	public List<Cliente> buscarClientes(Integer buscarPor, String cadena);
	
	public void eliminarCliente(String codigo);
	
	public Cliente obtenerPorCodigo(String codigo);
}
