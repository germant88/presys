package com.sistemas.presys.server.persistencia;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Correlativo;

@Remote
public interface ICorrelativoDAO {
	
	public Correlativo ObtenerPorCodigo(String codigo);
	
	public void actualizarCorrelativo(String codigo);

}
