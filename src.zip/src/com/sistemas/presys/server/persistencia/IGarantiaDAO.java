package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.Garantia;

@Remote
public interface IGarantiaDAO {

	public List<Garantia> obtenerTodos();
	
	public void agregar(Garantia garantia) throws LogicException;
	
	public Garantia obtenerPorCodigo(String codigo);

	
	public void eliminar(String codigo);
	
	public void modificar(Garantia garantia) ;
	
	public List<Garantia> buscar(Integer buscarPor, String cadena);

}
