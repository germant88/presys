package com.sistemas.presys.server.persistencia;

import java.util.List;

import javax.ejb.Remote;

import com.sistemas.presys.server.model.Edificio;
import com.sistemas.presys.shared.excepciones.LogicException;

@Remote
public interface IEdificioDAO {

    public List<Edificio> obtenerTodos();
	
	public void agregar(Edificio xedificio) throws LogicException;
	
	public Edificio obtenerPorCodigo(String xcodigo);
	
	public void eliminar (String xcodigo);
	
	public void modificarEdificio(Edificio xedificio) ;
	
	public List<Edificio> buscar(Integer buscarPor, String cadena);

	public List<Edificio> obtenerEdificiosDeCliente(String codigoCliente);

	public List<Edificio> buscarEdificioDeCliente(Integer buscarPor,
			String text, String codigoCliente);
	
}


