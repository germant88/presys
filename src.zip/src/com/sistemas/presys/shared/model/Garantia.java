package com.sistemas.presys.shared.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="GARANTIA")
public class Garantia implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="GTIA_COD")
	private String codigo;
	
	@Column(name="GTIA_NOM")
	private String nombre;
	
	@Column(name="GTIA_ANIOS")
	private Integer anios;
	
	@Column(name="GTIA_MESES")
	private Integer meses;
	
	@Column(name="GTIA_DIAS")
	private Integer dias;
	
	public Garantia() {
		super();
	}

	public Garantia(String codigo, String nombre, Integer anios, Integer meses, Integer dias) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.anios  = anios;
		this.meses  = meses;
		this.dias   = dias;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getAnios() {
		return anios;
	}

	public void setAnios(Integer anios) {
		this.anios = anios;
	}

	public Integer getMeses() {
		return meses;
	}

	public void setMeses(Integer meses) {
		this.meses = meses;
	}

	public Integer getDias() {
		return dias;
	}

	public void setDias(Integer dias) {
		this.dias = dias;
	}
	
	public String getDuracion() {
		String resultado = "";
		
		if ( anios > 0 ) {
			resultado = String.valueOf(anios) + " a\u00F1os "; 
		}
		if (meses > 0) {
			resultado += String.valueOf(meses) + " meses ";
		}
		if (dias > 0) {
			resultado += String.valueOf(dias) + " dias";
		}
		
		return resultado;
	}

	
	
}
