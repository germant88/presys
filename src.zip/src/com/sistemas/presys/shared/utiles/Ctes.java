package com.sistemas.presys.shared.utiles;

public final class Ctes {

	 // MODOS
	 public static final Integer K_MODO_ALTA         = 1;
	 public static final Integer K_MODO_MODIFICACION = 2;
	 public static final Integer K_MODO_CONSULTA     = 3;
	 public static final Integer K_MODO_SELECCION_SOL_ORIGEN = 4;
	 public static final Integer K_MODO_CONSULTA_PENDIENTES = 5;
	 public static final Integer K_MODO_CONSULTA_PRESUPUESTOS_PENDIENTES = 6;
	 
	 // Buscar por...
	 public static final Integer K_BUSCAR_X_COD = 0;
	 public static final Integer K_BUSCAR_X_NOM = 1;
	 public static final Integer K_BUSCAR_X_RUT = 3;
	 public static final Integer K_BUSCAR_X_DIR = 4;
	 
	      
	 // CODIGOS CORRELATIVOS
	 public static final String K_CORR_CLI  = "CLIENTES";
	 public static final String K_CORR_PROD = "PRODUCTOS";
	 public static final String K_CORR_SEG  = "SEGMENTOS";
	 public static final String K_CORR_EDI  = "EDIFICIOS";
	 public static final String K_CORR_SOL  = "SOLICITUDPRESUPUESTOS";
	 public static final String K_CORR_PRES = "PRESUPUESTOS";
	 public static final String K_CORR_NOT  = "NOTASSEGUIMIENTO";
	 
	 // TIPOS DOCUMENTOS
	 public static final String K_TDOC_SOLICITUD   = "SOLPRES";
	 public static final String K_TDOC_PRESUPUESTO = "PRESUP";
	 
	 // ESTADOS
	 public static final Integer K_ESTADO_SOLICITUD_PENDIENTE      = 1;
	 public static final Integer K_ESTADO_SOLICITUD_PRESUPUESTADA  = 2;
	 public static final Integer K_ESTADO_PRESUPUESTO_MODIFICADO   = 3;
	 public static final Integer K_ESTADO_PRESUPUESTO_GANADO       = 4;
	 public static final Integer K_ESTADO_PRESUPUESTO_PERDIDO       = 5;
	 public static final Integer K_ESTADO_PRESUPUESTO_CANCELADO    = 6;

	 
	 // REPORTES
	 public static final String K_REPORTE_PENDIENTES  = "Pendientes";
	 public static final String K_REPORTE_PRESUPUESTO = "Presupuesto";
	 public static final String K_SUB_REPORTE_PRESUPUESTO = "NotaImpresionPresupuesto";
	 
	 //COOKIES
	 public static final String  K_COOKIE_FILTRO_ESTADO = "FiltroEstado";
	 	 	
	 public static String[][] getFiltrarPorClientes() {  
	        return new String[][]{  
	           new String[]{"Codigo"},
	           new String[]{"Nombre"},
	           new String[] {"RUT"}
	        };  
	    }

	public static String[][] getFiltrarPorEdificios() {
		 return new String[][]{  
		           new String[]{"Codigo"},
		           new String[]{"Nombre"},
		           new String[] {"Direccion"}
		        };  
	}  
	
	public static String[][]getFiltrarPorUsuarios() {
		return new String [][]{
	        new String[]{"Codigo"},
	        new String[]{"Nombre"},
	        new String[] {"Apellido"}
		};
	}
	
	public static String[][] getFiltrarPorProductos() {
		return new String [][] {
				new String[]{"Codigo"},
				new String[]{"Nombre"}				
		};
	}	 
	
	public static String[][] getFiltrarPorFormasDePago() {
		return new String [][] {
				new String[]{"Codigo"},
				new String[]{"Nombre"}				
		};
	}
	
	public static String[][] getFiltrarPorGarantias() {
		return new String [][] {
				new String[]{"Codigo"},
				new String[]{"Nombre"}				
		};
	}
}
