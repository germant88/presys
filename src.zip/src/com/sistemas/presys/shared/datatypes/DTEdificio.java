package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;

public class DTEdificio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String codigo;
	private String nombre;
    private String direccion;
    private DTCliente cliente;
    
	public DTCliente getCliente() {
		return cliente;
	}
	public void setCliente(DTCliente cliente) {
		this.cliente = cliente;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
		
}
