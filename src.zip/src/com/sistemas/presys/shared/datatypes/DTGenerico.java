package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;

public class DTGenerico implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	


	
	
}
