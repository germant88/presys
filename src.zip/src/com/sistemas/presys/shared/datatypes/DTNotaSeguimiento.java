package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;
import java.util.Date;

public class DTNotaSeguimiento implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int numeroNotaSeguimiento;
	private String descripcion;
	private Date   fechaSeguimiento;
	private String usuario;
	private Date fechaIngreso;
	private String situacion;

	public int getNumeroNotaSeguimiento() {
		return numeroNotaSeguimiento;
	}
	public void setNumeroNotaSeguimiento(Integer numeroNotaSeguimiento) {
		this.numeroNotaSeguimiento = numeroNotaSeguimiento;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Date getFechaSeguimiento() {
		return fechaSeguimiento;
	}
	public void setFechaSeguimiento(Date fechaSeguimiento) {
		this.fechaSeguimiento = fechaSeguimiento;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public Date getFechaIngreso() {
		return fechaIngreso;
	}
	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	public String getSituacion() {
		return situacion;
	}
	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}	
}
