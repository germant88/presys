package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;

public class DTRol extends DTGenerico implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String nombre;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}		
	
	@Override
	public boolean equals(Object objeto){
		boolean resultado = false;
		if (objeto instanceof DTRol) {
			if ( ((DTRol) objeto).id.equals(this.id) ) {
				resultado = true;
			}
		}			
		return resultado;
	}
}
