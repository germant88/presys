package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;

public class DTSegmento implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String  codigo;
	private String  nombre;
	private String  descripcion;
	private Boolean habilitado;
	private String  estaHabilitado;
		
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Boolean getHabilitado() {
		return habilitado;
	}
	public void setHabilitado(Boolean habilitado) {
		this.habilitado = habilitado;
	}
	public String getEstaHabilitado() {
		if (habilitado){
			return "S";
		} 
		else {
			return "N";	
		}
		
	}
	public void setEstaHabilitado(String estaHabilitado) {
		this.estaHabilitado = estaHabilitado;
	}
		
	
}
