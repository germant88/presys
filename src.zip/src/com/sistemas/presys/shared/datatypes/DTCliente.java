package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;

public class DTCliente extends DTGenerico implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String codigo;
	private String nombre;
	private String email;
	private String direccion;
	private String rut;
	private String telefono;
	private String contactoNombre;
	private String contactoEmail;
	private String contactoTelefono;
	private DTSegmento segmento;
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getRut() {
		return rut;
	}
	public void setRut(String rut) {
		this.rut = rut;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getContactoNombre() {
		return contactoNombre;
	}
	public void setContactoNombre(String contactoNombre) {
		this.contactoNombre = contactoNombre;
	}
	public String getContactoEmail() {
		return contactoEmail;
	}
	public void setContactoEmail(String contactoEmail) {
		this.contactoEmail = contactoEmail;
	}
	public String getContactoTelefono() {
		return contactoTelefono;
	}
	public void setContactoTelefono(String contactoTelefono) {
		this.contactoTelefono = contactoTelefono;
	}
	public DTSegmento getSegmento() {
		return segmento;
	}
	public void setSegmento(DTSegmento segmento) {
		this.segmento = segmento;
	}	
}
