package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;
import java.util.List;

public class DTUsuario extends DTGenerico implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String password;
	private String nombre;
	private String apellido;
	private List<DTRol> listaRoles;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public List<DTRol> getListaRoles() {
		return listaRoles;
	}
	public void setListaRoles(List<DTRol> listaRoles) {
		this.listaRoles = listaRoles;
	}
	
	
}
