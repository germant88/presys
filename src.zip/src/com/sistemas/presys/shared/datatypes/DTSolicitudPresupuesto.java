package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.model.Garantia;

/**
 * @author Germ�n
 *
 */
public class DTSolicitudPresupuesto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String     codigo;
	private Date       fecha;
	private DTUsuario     usuarioAsignado;
	private DTCliente  cliente;
	private DTEdificio edificio;
	private String     detalles;
	private Integer    estado;
	private Date       fechaSeguimiento;
	private ArrayList<DTNotaSeguimiento> notaSeguimiento;
	private DTSolicitudPresupuesto solicitudPresupuestoOrigen;
	private ArrayList<DTRenglonPresupuesto> renglonesSolicitud;
	private ArrayList<DTNotaImpresionPresupuesto> listaNotaImpresionPresupuesto;
	private String tipoDocumento;	
	private FormaDePago formaDePago;	
	private Garantia garantia;
	private Integer superficie;
	private Double leyesSociales;
	private Double costoBQ;
	private Integer tiempoEjecucionDias;
	private Integer tiempoEjecucionMeses;
	private Integer tiempoEjecucionAnios;
	private Integer validezDias;
	private Integer validezMeses;
	private Integer validezAnios;
	
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public DTUsuario getUsuarioAsignado() {
		return usuarioAsignado;
	}
	public void setUsuarioAsignado(DTUsuario usuarioAsignado) {
		this.usuarioAsignado = usuarioAsignado;
	}
	public DTCliente getCliente() {
		return cliente;
	}
	public void setCliente(DTCliente cliente) {
		this.cliente = cliente;
	}
	public DTEdificio getEdificio() {
		return edificio;
	}
	public void setEdificio(DTEdificio edificio) {
		this.edificio = edificio;
	}
	public String getDetalles() {
		return detalles;
	}
	public void setDetalles(String detalles) {
		this.detalles = detalles;
	}
	public Integer getEstado() {
		return estado;
	}
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	public Date getFechaSeguimiento() {
		return fechaSeguimiento;
	}
	public void setFechaSeguimiento(Date fechaSeguimiento) {
		this.fechaSeguimiento = fechaSeguimiento;
	}
	public ArrayList<DTNotaSeguimiento> getNotaSeguimiento() {
		return notaSeguimiento;
	}
	public void setNotaSeguimiento(ArrayList<DTNotaSeguimiento> notaSeguimiento) {
		this.notaSeguimiento = notaSeguimiento;
	}
	public DTSolicitudPresupuesto getSolicitudPresupuestoOrigen() {
		return solicitudPresupuestoOrigen;
	}
	public void setSolicitudPresupuestoOrigen(DTSolicitudPresupuesto solicitudPresupuestoOrigen) {
		this.solicitudPresupuestoOrigen = solicitudPresupuestoOrigen;
	}
	public ArrayList<DTRenglonPresupuesto> getRenglonesSolicitud() {
		return renglonesSolicitud;
	}
	public void setRenglonesSolicitud(ArrayList<DTRenglonPresupuesto> renglonesSolicitud) {
		this.renglonesSolicitud = renglonesSolicitud;
	}
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public FormaDePago getFormaDePago() {
		return formaDePago;
	}
	public void setFormaDePago(FormaDePago formaDePago) {
		this.formaDePago = formaDePago;
	}
	public Garantia getGarantia() {
		return garantia;
	}
	public void setGarantia(Garantia garantia) {
		this.garantia = garantia;
	}
	public Integer getSuperficie() {
		return superficie;
	}
	public void setSuperficie(Integer superficie) {
		this.superficie = superficie;
	}
	public Double getLeyesSociales() {
		return leyesSociales;
	}
	public void setLeyesSociales(Double leyesSociales) {
		this.leyesSociales = leyesSociales;
	}
	public Double getCostoBQ() {
		return costoBQ;
	}
	public void setCostoBQ(Double costoBQ) {
		this.costoBQ = costoBQ;
	}
	public Integer getTiempoEjecucionDias() {
		return tiempoEjecucionDias;
	}
	public void setTiempoEjecucionDias(Integer tiempoEjecucionDias) {
		this.tiempoEjecucionDias = tiempoEjecucionDias;
	}
	public Integer getTiempoEjecucionMeses() {
		return tiempoEjecucionMeses;
	}
	public void setTiempoEjecucionMeses(Integer tiempoEjecucionMeses) {
		this.tiempoEjecucionMeses = tiempoEjecucionMeses;
	}
	public Integer getTiempoEjecucionAnios() {
		return tiempoEjecucionAnios;
	}
	public void setTiempoEjecucionAnios(Integer tiempoEjecucionAnios) {
		this.tiempoEjecucionAnios = tiempoEjecucionAnios;
	}
	public Integer getValidezDias() {
		return validezDias;
	}
	public void setValidezDias(Integer validezDias) {
		this.validezDias = validezDias;
	}
	public Integer getValidezMeses() {
		return validezMeses;
	}
	public void setValidezMeses(Integer validezMeses) {
		this.validezMeses = validezMeses;
	}
	public Integer getValidezAnios() {
		return validezAnios;
	}
	public void setValidezAnios(Integer validezAnios) {
		this.validezAnios = validezAnios;
	}
	public ArrayList<DTNotaImpresionPresupuesto> getListaNotaImpresionPresupuesto() {
		return listaNotaImpresionPresupuesto;
	}
	public void setListaNotaImpresionPresupuesto(
			ArrayList<DTNotaImpresionPresupuesto> listaNotaImpresionPresupuesto) {
		this.listaNotaImpresionPresupuesto = listaNotaImpresionPresupuesto;
	}
	
}
