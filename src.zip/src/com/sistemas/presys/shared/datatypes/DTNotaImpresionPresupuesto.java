package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;

public class DTNotaImpresionPresupuesto implements Serializable{

	private Integer numeroNotaImpresionPresupuesto;
	
	private DTSolicitudPresupuesto Presupuesto;

	private DTNotaImpresion notaImpresionXDefecto;
	
	private String descripcion;

	public Integer getNumeroNotaImpresionPresupuesto() {
		return numeroNotaImpresionPresupuesto;
	}

	public void setNumeroNotaImpresionPresupuesto(
			Integer numeroNotaImpresionPresupuesto) {
		this.numeroNotaImpresionPresupuesto = numeroNotaImpresionPresupuesto;
	}

	public DTSolicitudPresupuesto getPresupuesto() {
		return Presupuesto;
	}

	public void setPresupuesto(DTSolicitudPresupuesto presupuesto) {
		Presupuesto = presupuesto;
	}

	public DTNotaImpresion getNotaImpresionXDefecto() {
		return notaImpresionXDefecto;
	}

	public void setNotaImpresionXDefecto(DTNotaImpresion notaImpresionXDefecto) {
		this.notaImpresionXDefecto = notaImpresionXDefecto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public String getNombre(){
		return notaImpresionXDefecto.getNombre();
	}
	
	public String getCodigoNotaImpresionXDefecto(){
		return notaImpresionXDefecto.getCodigo();
	}		
	
}
