package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DTRenglonPresupuesto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer numeroRenglon;
	private DTSolicitudPresupuesto presupuesto;
	private DTProducto producto;
	private Double  importe;
	private String  descripcion;
	private List<DTTareaRenglon> listaTareasRenglon;
	
	public Integer getNumeroRenglon() {
		return numeroRenglon;
	}
	public void setNumeroRenglon(Integer numeroRenglon) {
		this.numeroRenglon = numeroRenglon;
	}

   public DTProducto getProducto() {
		return producto;
	}
	public void setProducto(DTProducto producto) {
		this.producto = producto;
	}
	public Double getImporte() {
		return importe;
	}
	public void setImporte(Double importe) {
		this.importe = importe;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public DTSolicitudPresupuesto getPresupuesto() {
		return presupuesto;
	}
	public void setPresupuesto(DTSolicitudPresupuesto presupuesto) {
		this.presupuesto = presupuesto;
   }
	
	public String getNombreProducto() {
		return producto.getNombre();
	}
	public List<DTTareaRenglon> getListaTareasRenglon() {
		return listaTareasRenglon;
	}
	public void setListaTareasRenglon(List<DTTareaRenglon> listaTareasRenglon) {
		this.listaTareasRenglon = listaTareasRenglon;
	}
	public DTRenglonPresupuesto() {
		super();
		listaTareasRenglon = new ArrayList<DTTareaRenglon>();
	}
	
	
}
