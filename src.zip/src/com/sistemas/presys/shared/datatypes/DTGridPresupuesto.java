package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;
import java.util.Date;


public class DTGridPresupuesto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String id;
	private Date   fecha;
	private String nombreCliente;
	private String nombreEdificio;
	private Integer estado;
	private Date   seguimiento;
	private String nombreEstado;
	private String tipoDoc;
	private String nombreTipoDocumento;
	

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getNombreCliente() {
		return nombreCliente;
	}
	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}
	public String getNombreEdificio() {
		return nombreEdificio;
	}
	public void setNombreEdificio(String nombreEdificio) {
		this.nombreEdificio = nombreEdificio;
	}		
	
	public Integer getEstado() {
		return estado;
	}
	public void setEstado(Integer estado) {
		this.estado = estado;
	}
	public Date getSeguimiento() {
		return seguimiento;
	}
	public void setSeguimiento(Date seguimiento) {
		this.seguimiento = seguimiento;
	}
	
	public String getNombreEstado() {
		return nombreEstado;
	}
	public void setNombreEstado(String nombreEstado) {
		this.nombreEstado = nombreEstado;
	}		
	
	public String getNombreTipoDocumento() {
		return nombreTipoDocumento;
	}
	public void setNombreTipoDocumento(String nombreTipoDocumento) {
		this.nombreTipoDocumento = nombreTipoDocumento;
	}
	
	public DTGridPresupuesto(String id, Date fecha, String nombreCliente,
			String nombreEdificio, Integer estado, Date seguimiento, String nombreEstado, String tipoDoc, String nombreTipoDocumento) {
		super();
		this.id = id;
		this.fecha = fecha;
		this.nombreCliente = nombreCliente;
		this.nombreEdificio = nombreEdificio;
		this.estado = estado;
		this.seguimiento = seguimiento;
		this.nombreEstado = nombreEstado;
		this.tipoDoc = tipoDoc;
		this.nombreTipoDocumento = nombreTipoDocumento;
		
	}
	
	public DTGridPresupuesto(){
		super();
	}
	public String getTipoDoc() {
		return tipoDoc;
	}
	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}
}
