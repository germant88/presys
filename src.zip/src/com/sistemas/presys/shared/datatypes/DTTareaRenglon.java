package com.sistemas.presys.shared.datatypes;

import java.io.Serializable;

public class DTTareaRenglon implements Serializable{

	private Integer numeroTareaRenglon;
	
	private DTRenglonPresupuesto renglonSolicitudPresupuesto;
	
	private DTTarea tareaXDefecto;
	
	private String descripcion;

	public Integer getNumeroTareaRenglon() {
		return numeroTareaRenglon;
	}

	public void setNumeroTareaRenglon(Integer numeroTareaRenglon) {
		this.numeroTareaRenglon = numeroTareaRenglon;
	}

	public DTRenglonPresupuesto getRenglonSolicitudPresupuesto() {
		return renglonSolicitudPresupuesto;
	}

	public void setRenglonSolicitudPresupuesto(
			DTRenglonPresupuesto renglonSolicitudPresupuesto) {
		this.renglonSolicitudPresupuesto = renglonSolicitudPresupuesto;
	}

	public DTTarea getTareaXDefecto() {
		return tareaXDefecto;
	}

	public void setTareaXDefecto(DTTarea tareaXDefecto) {
		this.tareaXDefecto = tareaXDefecto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public String getNombre(){
		return tareaXDefecto.getNombre();
	}
	
	public String getCodigoTareaXDefecto(){
		return tareaXDefecto.getCodigo();
	}		
	
	
	
}
