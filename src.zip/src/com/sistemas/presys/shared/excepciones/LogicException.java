package com.sistemas.presys.shared.excepciones;

import com.google.gwt.user.client.rpc.IsSerializable;


public class LogicException extends Exception implements IsSerializable{

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LogicException(String message) {
	        super(message);
	    }
	 
	 public LogicException(){
		 super();
	 }
	
}
