package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.gwtext.client.widgets.form.Label;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.SegmentoProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorSegmentos;
import com.sistemas.presys.client.rpc.IRPCManejadorSegmentosAsync;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMSegmentos extends FormABMGenerico {

    private static final SegmentoProperties props = GWT.create(SegmentoProperties.class);
	
	protected IRPCManejadorSegmentosAsync manejadorSegmentos;
	
	public FormABMSegmentos(){
		super();		
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Segmentos");
	}
	
	@Override
	protected void crearManejadorRPC() {
		manejadorSegmentos = GWT.create(IRPCManejadorSegmentos.class);
	}
	
	
	@Override
	protected void crearGrilla(){	      
		  ColumnConfig<DTSegmento, String> codigoCol 	    = new ColumnConfig<DTSegmento, String>(props.codigo(), 100, "Codigo");
		  ColumnConfig<DTSegmento, String> nombreCol 	    = new ColumnConfig<DTSegmento, String>(props.nombre(), 100, "Nombre");
		  ColumnConfig<DTSegmento, String> descripcionCol   = new ColumnConfig<DTSegmento, String>(props.descripcion(), 100, "Descripcion");
		  ColumnConfig<DTSegmento, String> habilitadoCol   = new ColumnConfig<DTSegmento, String>(props.estaHabilitado(), 100, "Habilitado");	      
	 
	      List<ColumnConfig<DTSegmento, ?>> l = new ArrayList<ColumnConfig<DTSegmento, ?>>();
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(descripcionCol);
	      l.add(habilitadoCol);
	      
	      
	      cm = new ColumnModel<DTSegmento>(l);
	 
	      store = new ListStore<DTSegmento>(props.key());	      	     	      
	      
	      grilla = new Grid<DTSegmento>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	     
	}
	
	
	@Override
	protected void ejecutarAgregar(){
		FormSegmento form = new FormSegmento(observableManager, Ctes.K_MODO_ALTA, null);			  
		form.show();
	}
	
	
	@Override
	protected void cargarGrilla(){
		grilla.getStore().clear();
		this.grilla.mask("Cargarndo segmentos...");
		manejadorSegmentos.obtenerSegmentos(new  AsyncCallback<ArrayList<DTSegmento>>() {			               
			@SuppressWarnings("unchecked")
			@Override
			public void onSuccess(ArrayList<DTSegmento> result) {
				 store.addAll(result);
                 grilla.reconfigure(store, cm);	
                 grilla.unmask();
			}
			
			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}
		});			
	}

	@Override
	protected void eliminarSeleccionado(){
		ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "Realmente desea eliminar el segmento?");
	    box.addHideHandler(hadlerEliminarSegmento);	
	    ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
	    box.show();
	}
	
	
	 final HideHandler hadlerEliminarSegmento = new HideHandler() {
	     @Override
	     public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarSegmentoSeleccionado();
	        }	        
	     }
	 };
	 
	 private void eliminarSegmentoSeleccionado(){
	    DTSegmento segmentoSeleccionado;
		   
	    segmentoSeleccionado = (DTSegmento) grilla.getSelectionModel().getSelectedItem();
	   	    
	    eliminarSegmento(segmentoSeleccionado);            	    
	 }
	 
	 private void eliminarSegmento(DTSegmento segmentoSeleccionado) {
			manejadorSegmentos.eliminarSegmento(segmentoSeleccionado.getCodigo(), new AsyncCallback() {

				@Override
				public void onSuccess(Object result) {
			       cargarGrilla();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}			
			}); 
     }

	 public void errorDebeSeleccionarUnElemento() {
			/*final Dialog simple = new Dialog();
		    simple.setHeadingText("Atencion");
		    simple.setPredefinedButtons(PredefinedButton.OK);
		    simple.setBodyStyleName("pad-text");
		    simple.add(new Label("Debe seleccionar un segmento en la grilla"));
		    simple.getBody().addClassName("pad-text");
		    simple.setHideOnButtonClick(true);
		    simple.setWidth(300);
		   
		   simple.show();
		   */
		   
			MessageBox box = new MessageBox("Atencion", "Debe seleccionar un segmento en la grilla");
		    box.show();
		}
	 
	 @Override
	 protected void modificarSeleccionado(){
		 DTSegmento segmentoSeleccionado;
		   
		 segmentoSeleccionado = (DTSegmento) grilla.getSelectionModel().getSelectedItem();
		   
		   if (segmentoSeleccionado != null) {
		      modificarSegmento(segmentoSeleccionado);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	 }

	private void modificarSegmento(DTSegmento segmentoSeleccionado) {
		FormSegmento form = new FormSegmento(observableManager, Ctes.K_MODO_MODIFICACION, segmentoSeleccionado.getCodigo());			  
	    form.show();
	}
	
	@Override
	protected void buscar() {
		 Integer buscarPor;
		   if (this.rbtnFiltrarCodigo.getValue() == true) {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargarndo segmentos...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorSegmentos.buscarSegmento(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTSegmento>>() {
			
			@Override
			public void onSuccess(ArrayList<DTSegmento> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();
	               ponerFocoEnFiltro();
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}
}
