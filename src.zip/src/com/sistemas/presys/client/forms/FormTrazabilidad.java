package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.GridPresupuestosProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorConsultasPresupuestos;
import com.sistemas.presys.client.rpc.IRPCManejadorConsultasPresupuestosAsync;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;

public class FormTrazabilidad extends Window{	

	private static final GridPresupuestosProperties props = GWT.create(GridPresupuestosProperties.class);
	
	private final IRPCManejadorConsultasPresupuestosAsync manejadorConsultasPresupuestos = GWT
			.create(IRPCManejadorConsultasPresupuestos.class);
	
	private ListStore<DTGridPresupuesto> storeOrigen;
	private ListStore<DTGridPresupuesto> storeDestino;
	private ColumnModel<DTGridPresupuesto> cmOrigen;
	private ColumnModel<DTGridPresupuesto> cmDestino;
	private Grid<DTGridPresupuesto> grillaOrigen;
	private Grid<DTGridPresupuesto> grillaDestino;
	
	private BorderLayoutContainer layout;
	
	private ContentPanel panelIzq;
	private ContentPanel panelDer;
	private ContentPanel panelSuperior;
	
	private String codigoDocumento;
	private String tipoDocumento;
	
	public FormTrazabilidad(String codigoDocumento, String tipoDocumento){
		super();
		this.codigoDocumento = codigoDocumento;
		this.tipoDocumento   = tipoDocumento;
		createComponents();
		initEvents();
		cargarGrillaOrigen();
		cargarGrillaDestino();
	}

	private void cargarGrillaDestino() {
		manejadorConsultasPresupuestos.obtenerDocumentosDestinoDeDocumento(codigoDocumento, tipoDocumento, new AsyncCallback<ArrayList<DTGridPresupuesto>>() {			
			@Override
			public void onSuccess(ArrayList<DTGridPresupuesto> result) {
				storeDestino.addAll(result);
                grillaDestino.reconfigure(storeDestino, cmDestino);	
                grillaDestino.unmask();							
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});		
	}

	private void cargarGrillaOrigen() {    
		manejadorConsultasPresupuestos.obtenerDocumentosOrigenDeDocumento(codigoDocumento, tipoDocumento,  new AsyncCallback<ArrayList<DTGridPresupuesto>>() {
			
			@Override
			public void onSuccess(ArrayList<DTGridPresupuesto> result) {
				storeOrigen.addAll(result);
                grillaOrigen.reconfigure(storeOrigen, cmOrigen);	
                grillaOrigen.unmask();								
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}
		});		
	}

	private void initEvents() {
		
	}

	private void createComponents() {	   
	   this.setMaximizable(true);
	   this.setModal(true);		
	   this.setHeadingText("Trazabilidad (" + codigoDocumento + ")");		 
	   this.setSize("650px", "430px");
		 
	   layout = new BorderLayoutContainer();		   
	   this.add(layout);
	   
	   panelIzq = new ContentPanel();	  
	   panelIzq.setSize("100%", "100%");    	
	   panelIzq.setHeaderVisible(true);
	   panelIzq.setHeadingText("Origen");
	   
	   panelDer = new ContentPanel();	 	   
	   panelDer.setSize("100%", "100%");    	
	   panelDer.setHeaderVisible(true);
	   panelDer.setHeadingText("Destino");
	   
	   panelSuperior = new ContentPanel();
	   panelSuperior.setSize("100%", "100%");
	   	   	   
	   layout.setEastWidget(panelDer, new BorderLayoutData(303));
	   layout.setWestWidget(panelIzq, new BorderLayoutData(303));
	   layout.setNorthWidget(panelSuperior, new BorderLayoutData(24));
	   
	   createGrillaOrigen();
	   createGrillaDestino();
	   panelIzq.add(grillaOrigen);
	   panelDer.add(grillaDestino);
	   
	   
	   
	}
	
	
	private void createGrillaOrigen() {
		ColumnConfig<DTGridPresupuesto, String> idCol                   = new ColumnConfig<DTGridPresupuesto, String>(props.id(), 100, "Codigo");
		ColumnConfig<DTGridPresupuesto, Date>   fechaCol                = new ColumnConfig<DTGridPresupuesto, Date>  (props.fecha(), 100, "Fecha");
	    ColumnConfig<DTGridPresupuesto, String> nombreTipoDocumentoCol  = new ColumnConfig<DTGridPresupuesto, String>  (props.nombreTipoDocumento(), 100, "Tipo");
	 
      List<ColumnConfig<DTGridPresupuesto, ?>> l = new ArrayList<ColumnConfig<DTGridPresupuesto, ?>>();
      l.add(idCol);
      fechaCol.setCell(new com.google.gwt.cell.client.DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));
      l.add(fechaCol);      
      l.add(nombreTipoDocumentoCol);       
           	      	      
      cmOrigen = new ColumnModel<DTGridPresupuesto>(l);
 
      storeOrigen = new ListStore<DTGridPresupuesto>(props.key());	      	     	      
      
      grillaOrigen = new Grid<DTGridPresupuesto>(storeOrigen, cmOrigen);
      
      grillaOrigen.getView().setStripeRows(true);
      grillaOrigen.getView().setColumnLines(true);            
      grillaOrigen.setBorders(false);
	      
      grillaOrigen.setColumnReordering(true);
      grillaOrigen.setStateful(true);
      grillaOrigen.setStateId("GrillaOrigen");
      grillaOrigen.setSize("100%", "100%");	      		      
	}
	
	private void createGrillaDestino(){
    	ColumnConfig<DTGridPresupuesto, String> idCol                   = new ColumnConfig<DTGridPresupuesto, String>(props.id(), 100, "Codigo");
	    ColumnConfig<DTGridPresupuesto, Date>   fechaCol                = new ColumnConfig<DTGridPresupuesto, Date>  (props.fecha(), 100, "Fecha");
        ColumnConfig<DTGridPresupuesto, String> nombreTipoDocumentoCol  = new ColumnConfig<DTGridPresupuesto, String>  (props.nombreTipoDocumento(), 100, "Tipo");
	 
      List<ColumnConfig<DTGridPresupuesto, ?>> l = new ArrayList<ColumnConfig<DTGridPresupuesto, ?>>();
      l.add(idCol);
      fechaCol.setCell(new com.google.gwt.cell.client.DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));
      l.add(fechaCol);      
      l.add(nombreTipoDocumentoCol);       
           	      	      
      cmDestino = new ColumnModel<DTGridPresupuesto>(l);
 
      storeDestino = new ListStore<DTGridPresupuesto>(props.key());	      	     	      
      
      grillaDestino = new Grid<DTGridPresupuesto>(storeDestino, cmDestino);
      
      grillaDestino.getView().setStripeRows(true);
      grillaDestino.getView().setColumnLines(true);            
      grillaDestino.setBorders(false);
	      
      grillaDestino.setColumnReordering(true);
      grillaDestino.setStateful(true);
      grillaDestino.setStateId("GrillaDestino");
      grillaDestino.setSize("100%", "100%");	      		      		
	}
}
