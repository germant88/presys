package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.PasswordField;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuarios;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuariosAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorUtiles;
import com.sistemas.presys.client.rpc.IRPCManejadorUtilesAsync;

public class FormCambiarContrasena extends Window{
	
	  private final IRPCManejadorUtilesAsync manejadorUtiles = GWT
				.create(IRPCManejadorUtiles.class);

	protected IRPCManejadorUsuariosAsync manejadorUsuarios;
	
	protected VerticalLayoutContainer vlc;

	protected Button btnAceptar;
	protected Button btnCancelar;
	
	private PasswordField     txtContrasenaActual;
	private PasswordField     txtContrasenaNueva;
	private PasswordField     txtRepetirContrasenaNueva;
	
	public FormCambiarContrasena (){
		super();
		manejadorUsuarios = GWT.create(IRPCManejadorUsuarios.class);
		createComponents();	
		initEvents();
	}

	private void initEvents() {
		btnAceptar.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				cambiarContrasena();		
			}
		});		
		
		btnCancelar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
               cerrarme();				
			}
		});
	}

	protected void cambiarContrasena() {
	   
       if (txtContrasenaNueva.getValue().equals(txtRepetirContrasenaNueva.getValue())) {   	   

    	   manejadorUtiles.obtenerUsuarioLogueado(new AsyncCallback<String>() {
    		   String usuarioLogueado = "";
			@Override
			public void onSuccess(String result) {
				usuarioLogueado = result;
				manejadorUsuarios.validarContrasena(txtContrasenaActual.getValue(), result, new AsyncCallback<Boolean>() {

					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onSuccess(Boolean result) {
                       // Si se valido la contrasena a continuacion se intenta cambiarla.
					   if (result) {						   
						   manejadorUsuarios.cambiarContrasena(usuarioLogueado, txtContrasenaNueva.getValue(), new AsyncCallback<Void>() {

							@Override
							public void onFailure(Throwable caught) {
								// TODO Auto-generated method stub
								
							}

							@Override
							public void onSuccess(Void result) {
								MessageBox box = new MessageBox("Atencion");												    												    												    
								box.setMessage("La contrase\u00f1a se modifico correctamente");
								box.show();
								
								cerrarme();
							}
							
						});
                       }
					   else{
						   MessageBox box = new MessageBox("Error");												    												    												    
							box.setMessage("La contrase\u00f1a actual ingresada no es correcta");
							box.show();
					   }
					}
				});   				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});    	     	   
       }
       else {
    	   MessageBox box = new MessageBox("Error");												    												    												    
		   box.setMessage("Las contrase\u00f1as ingresadas no coinciden");
		   box.show();
       }
	}

	private void cerrarme() {
		this.hide();
	}
	
	private void createComponents() {
		this.setMaximizable(true);
	    this.setModal(true);
  	    this.setHeadingText("Cambiar contrase\u00f1a");
		  
		this.setSize("400px", "300px");
		
        ContentPanel panelPrincipal = new ContentPanel();
        panelPrincipal.setSize("100%", "100%");
        panelPrincipal.setHeaderVisible(false);
        this.add(panelPrincipal);
        
        vlc = new VerticalLayoutContainer();
	    vlc.setHeight("100%");

	    panelPrincipal.add(vlc);
	    
	    txtContrasenaActual       = new PasswordField();
	    vlc.add(new FieldLabel(txtContrasenaActual, "Contrase\u00f1a actual"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
        
	    txtContrasenaNueva        = new PasswordField();
	    vlc.add(new FieldLabel(txtContrasenaNueva, "Nueva contrase\u00f1a"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
						
		txtRepetirContrasenaNueva = new PasswordField();
	    vlc.add(new FieldLabel(txtRepetirContrasenaNueva, "Repetir contrase\u00f1a"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));		
		
	    btnAceptar = new Button();	   
	    btnAceptar.setText("Aceptar");
	    btnAceptar.setSize("70px", "30px");
	  
	    btnCancelar = new Button();	   
	    btnCancelar.setText("Cancelar");
	    btnCancelar.setSize("70px", "30px");
	  		  		 
	    this.addButton(btnAceptar);
	    this.addButton(btnCancelar);
	}	   
}
