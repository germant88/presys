package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.gwtext.client.widgets.form.Label;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.TareaProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorTareas;
import com.sistemas.presys.client.rpc.IRPCManejadorTareasAsync;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMTareas extends FormABMGenerico{
	private static final TareaProperties props = GWT.create(TareaProperties.class);
	
	protected IRPCManejadorTareasAsync manejadorTareas;
	
	public FormABMTareas(){
		super();		
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Tareas");
	}
	
	@Override
	protected void crearGrilla(){	      
		  ColumnConfig<DTTarea, String> codigoCol 	    = new ColumnConfig<DTTarea, String>(props.codigo(), 100, "Codigo");
		  ColumnConfig<DTTarea, String> nombreCol 	    = new ColumnConfig<DTTarea, String>(props.nombre(), 100, "Nombre");
		  ColumnConfig<DTTarea, String> descripcionCol  = new ColumnConfig<DTTarea, String>(props.descripcion(), 100, "Descripcion");	      
	 
	      List<ColumnConfig<DTTarea, ?>> l = new ArrayList<ColumnConfig<DTTarea, ?>>();
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(descripcionCol);
	      	      
	      cm = new ColumnModel<DTTarea>(l);
	 
	      store = new ListStore<DTTarea>(props.key());	      	     	      
	      
	      grilla = new Grid<DTTarea>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	     
	}
	
	
	@Override
	protected void ejecutarAgregar(){
		FormTarea form = new FormTarea(observableManager, Ctes.K_MODO_ALTA, null);			  
		form.show();
	}
	
	@Override
	protected void crearManejadorRPC() {
		 manejadorTareas = GWT.create(IRPCManejadorTareas.class);
	}

	@Override
	protected void cargarGrilla(){
		grilla.getStore().clear();
		this.grilla.mask("Cargarndo productos...");
		manejadorTareas.obtenerTareas(new  AsyncCallback<ArrayList<DTTarea>>() {			               
			@SuppressWarnings("unchecked")
			@Override
			public void onSuccess(ArrayList<DTTarea> result) {
				 store.addAll(result);
                 grilla.reconfigure(store, cm);	
                 grilla.unmask();
			}
			
			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}
		});			
	}

	@Override
	protected void eliminarSeleccionado(){
		ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "Realmente desea eliminar la tarea seleccioanda?");
	    box.addHideHandler(hadlerEliminarTarea);	
	    ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
	    box.show();
	}
	
	
	 final HideHandler hadlerEliminarTarea = new HideHandler() {
	     @Override
	     public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarTareaSeleccionada();
	        }	        
	     }
	 };
	 
	 private void eliminarTareaSeleccionada(){
	    DTTarea tareaSeleccionada;
		   
	    tareaSeleccionada = (DTTarea) grilla.getSelectionModel().getSelectedItem();
	   
	    if (tareaSeleccionada != null) {
	       eliminarTarea(tareaSeleccionada);            
	    }
	    else {		   
		   errorDebeSeleccionarUnElemento();		   
	    }
	 }
	 
	 private void eliminarTarea(DTTarea tareaSeleccionada) {
			manejadorTareas.eliminarTarea(tareaSeleccionada.getCodigo(), new AsyncCallback() {

				@Override
				public void onSuccess(Object result) {
			       cargarGrilla();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}			
			}); 
     }

	 public void errorDebeSeleccionarUnElemento() {
			final Dialog simple = new Dialog();
		    simple.setHeadingText("Atencion");
		    simple.setPredefinedButtons(PredefinedButton.OK);
		    simple.setBodyStyleName("pad-text");
		    simple.add(new Label("Debe seleccionar una tarea en la grilla"));
		    simple.getBody().addClassName("pad-text");
		    simple.setHideOnButtonClick(true);
		    simple.setWidth(300);
		   
		   simple.show();
		}
	 
	 @Override
	 protected void modificarSeleccionado(){
		 DTTarea tareaSeleccionada;
		   
		 tareaSeleccionada = (DTTarea) grilla.getSelectionModel().getSelectedItem();
		   
		   if (tareaSeleccionada != null) {
		      modificarTarea(tareaSeleccionada);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	 }

	private void modificarTarea(DTTarea tareaSeleccionada) {
		FormTarea form = new FormTarea(observableManager, Ctes.K_MODO_MODIFICACION, tareaSeleccionada.getCodigo());			  
	    form.show();
	}
	
	@Override
	protected void buscar() {
		 Integer buscarPor;
		   if (this.rbtnFiltrarCodigo.getValue() == true) {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargarndo tareas...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorTareas.buscarTarea(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTTarea>>() {
			
			@Override
			public void onSuccess(ArrayList<DTTarea> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();
	               ponerFocoEnFiltro();
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}
	
}
