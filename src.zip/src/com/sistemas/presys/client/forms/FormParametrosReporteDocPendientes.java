package com.sistemas.presys.client.forms;

import java.util.HashMap;
import java.util.Map;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormParametrosReporteDocPendientes extends Window implements IObserver{
	protected FieldSet        fsUsuario;
	protected TextField       txtNombreUsuario;
	protected TextField       txtUsuario;
	private   SeleccionObjeto seleccionUsuario;
	protected BorderLayoutContainer layout;
	ObservableManager observableManagerSeleccion;
	protected Button btnSalir;
	protected Button btnAceptar;
	private String tipoDocumento;
			
	public FormParametrosReporteDocPendientes(String xtipoDocumento){
		super();
		tipoDocumento = xtipoDocumento;
		observableManagerSeleccion = new ObservableManager();
		observableManagerSeleccion.addObserver(this);
		createComponents();
		initEvents();
	}
	
	private void initEvents() {
        btnAceptar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				Map<String, String> parametros = new HashMap();
	            parametros.put("TipoDocumento", tipoDocumento);
	            
	            if ((seleccionUsuario.txtCodigo.getValue() != null) && (seleccionUsuario.txtCodigo.getValue().trim() != "")) {
	               parametros.put("Usuario", seleccionUsuario.txtCodigo.getValue());	
	            } else {
	               parametros.put("Usuario", "");
	            }
	            	            	            				
				FormReportePendientes form = new FormReportePendientes(Ctes.K_REPORTE_PENDIENTES, parametros, null);
			   	form.show();				
			}
		});
        
        btnSalir.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
               hide();				
			}
		});
	}

	public void createComponents(){
		this.setMaximizable(false);
        this.setModal(true);
        this.setResizable(false);
		
        this.setHeadingText("Reporte de pendientes");
    
        this.setSize("350px", "300px"); 
		   
		layout = new BorderLayoutContainer();
		
		this.add(layout);
	
		
		
		VerticalLayoutContainer vlcUsuario = new VerticalLayoutContainer();
        
		fsUsuario = new FieldSet();
		fsUsuario.setHeadingText("Usuario:");
		fsUsuario.setCollapsible(true);
		fsUsuario.setSize("310px", "90px");
                                
        txtNombreUsuario = new TextField();
        txtNombreUsuario.setReadOnly(true);
                
        seleccionUsuario = new SeleccionObjeto(observableManagerSeleccion, 4);        
        vlcUsuario.add(new FieldLabel(seleccionUsuario, "Codigo"));
        vlcUsuario.add(new FieldLabel(txtNombreUsuario, "Nombre"));
        
        fsUsuario.add(vlcUsuario);
        
        VerticalPanel vpPanelCentral = new VerticalPanel();
        
        vpPanelCentral.add(fsUsuario);
        
        layout.setCenterWidget(vpPanelCentral);
		
		btnSalir = new Button();	   
		btnSalir.setText("Salir");
		btnSalir.setSize("70px", "30px");
		
		btnAceptar = new Button();	   
		btnAceptar.setText("Aceptar");
		btnAceptar.setSize("70px", "30px");
		
		this.addButton(btnAceptar);
		this.addButton(btnSalir);
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
		 if (changeInfo instanceof DTUsuario) {
	    	   seleccionUsuario.txtCodigo.setValue(((DTUsuario) changeInfo).getId());	    	   
	    	   String nombre   = ((DTUsuario) changeInfo).getNombre();
	    	   String apellido = ((DTUsuario) changeInfo).getApellido();	    	       	       	  
	    	   txtNombreUsuario.setValue((nombre == null? "" : nombre) + " " + (apellido == null? "" : apellido));    	   
	       }				 
	}
	
	
	
	
}
