package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorEdificios;
import com.sistemas.presys.client.rpc.IRPCManejadorEdificiosAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormEdificio extends FormEntidadGenerico implements IObserver{
protected IRPCManejadorEdificiosAsync manejadorEdificios;
	
	private   TextField txtNombre;
	private   TextArea  txtDireccion;	
	protected FieldSet fsCliente;
	protected TextField txtNombreCliente;
	private   SeleccionObjeto seleccionCliente;
	
	ObservableManager observableManagerSeleccion;
	
	public FormEdificio(ObservableManager xobsManager, Integer xmodo, String xcodigo) {				
		super(xobsManager, xmodo, xcodigo);
		observableManagerSeleccion = new ObservableManager();
		observableManagerSeleccion.addObserver(this);
		createComponentSeleccionCliente();
	}	
	
	@Override
	protected void crearManejadorRPC() {
		 manejadorEdificios = GWT.create(IRPCManejadorEdificios.class);
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Edificio");		
	}	
	
	@Override
	protected String  obtenerCodigoCorrelativo(){
		return Ctes.K_CORR_EDI;
	}
	
	@Override
	protected void createComponents(){
		super.createComponents();
						
		txtNombre = new TextField();
	    vlc.add(new FieldLabel(txtNombre, "Nombre"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
	    
	    txtDireccion = new TextArea();
	    vlc.add(new FieldLabel(txtDireccion, "Direccion"),new VerticalLayoutData(450, 150, new Margins(30,1,1,15)));
	    
		txtNombre.focus();
		this.setFocusWidget(txtNombre);
	}
	
	protected void createComponentSeleccionCliente(){
        VerticalLayoutContainer vlcCliente = new VerticalLayoutContainer();
		
		fsCliente = new FieldSet();
        fsCliente.setHeadingText("Cliente");
        fsCliente.setCollapsible(true);
        fsCliente.setSize("310px", "100px");
                                
        txtNombreCliente = new TextField();
        txtNombreCliente.setReadOnly(true);
                
        seleccionCliente = new SeleccionObjeto(observableManagerSeleccion, 1);        
        vlcCliente.add(new FieldLabel(seleccionCliente, "Codigo"));
        vlcCliente.add(new FieldLabel(txtNombreCliente, "Nombre"));
        
        fsCliente.add(vlcCliente);
        
        vlc.add(new FieldLabel(fsCliente, "Cliente"),new VerticalLayoutData(450, 150, new Margins(30,1,1,15)));		
	}
	
	@Override
	protected void agregarEntidad(){
		try {
			manejadorEdificios.agregarEdificio(txtCodigo.getValue(), txtNombre.getValue(), txtDireccion.getValue(), this.seleccionCliente.txtCodigo.getValue(),  new AsyncCallback<Void>() {
	
						@Override
						public void onFailure(Throwable caught) {
							MessageBox box = new MessageBox("Error");												    												    												    
						     box.setMessage("Se produjo un error al intentar agregar el segmento: " + caught.getMessage());
							 box.show();								
						}
	
						@Override
						public void onSuccess(Void result) {
							cerrarme();									
						}
					});
		} catch (LogicException e) {		
			  e.printStackTrace();
		}			
	
	}
	
	@Override
	protected void modificarEntidad() {
		manejadorEdificios.modificarEdificio(txtCodigo.getValue() , txtNombre.getValue(), txtDireccion.getValue(), this.seleccionCliente.txtCodigo.getValue()
          , new AsyncCallback<Void>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(Void result) {
				cerrarme();			
			}
		});
				
    }
	
	@Override
	protected void cargarPantalla(String xcodigo) {
		manejadorEdificios.obtenerEdificioPorCodigo(xcodigo, new AsyncCallback<DTEdificio>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(DTEdificio result) {
				cargarPantallaConObjeto(result);				
			}
		});     			
    }

	@Override
    protected void cargarPantallaConObjeto(Object entidad) {
       DTEdificio edificio = (DTEdificio) entidad;
		
	   this.txtCodigo.setValue(String.valueOf(edificio.getCodigo()));
 	   this.txtNombre.setValue(edificio.getNombre() != null ? edificio.getNombre() : "");
 	   this.txtDireccion.setValue(edificio.getDireccion() != null ? edificio.getDireccion() : "");
 	   this.seleccionCliente.txtCodigo.setValue(edificio.getCliente().getCodigo() != null ? edificio.getCliente().getCodigo() : "");
 	   this.txtNombreCliente.setValue(edificio.getCliente().getNombre());
    }

	@Override
	public void update(Object theObserved, Object changeInfo) {
	   if (changeInfo instanceof DTCliente){
	          seleccionCliente.txtCodigo.setValue(((DTCliente)changeInfo).getCodigo());
	          txtNombreCliente.setValue(((DTCliente)changeInfo).getNombre());
	   }		
	}	
}
