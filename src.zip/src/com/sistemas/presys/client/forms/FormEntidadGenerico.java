package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativos;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativosAsync;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormEntidadGenerico extends Window{
	
    protected ObservableManager observableManager;
    protected Integer modo;
    
    protected final IRPCManejadorCorrelativosAsync manejadorCorrelativos = GWT
			.create(IRPCManejadorCorrelativos.class);
    

    protected TextField txtCodigo;
	// TODO: tipo de cliente

	protected Button btnAceptar;
	protected Button btnCancelar;
	protected BorderLayoutContainer layout;
	
	protected VerticalLayoutContainer vlc;
	
	public FormEntidadGenerico(ObservableManager xobsManager, Integer xmodo, String xcodigo) {
	   super();
	   observableManager = xobsManager;
	   modo              = xmodo;     	  
	   crearManejadorRPC();
	   createComponents();	
	   initEvents();
	   
	   if (modo == Ctes.K_MODO_MODIFICACION) {
	      cargarPantalla(xcodigo);         	   
	   }	  	   
	}		
	


   protected void cargarPantalla(String xcodigo) {
		
	
   }

   protected void cargarPantallaConObjeto(Object entidad) {

   }
	

	protected void createComponents() {
	   this.setMaximizable(true);
	   this.setModal(true);
	   
	   setTitulo();
	  
	   this.setSize("500px", "600px");
	   
	   layout = new BorderLayoutContainer();
	   
	   this.add(layout);
	      
	   ContentPanel panelCentral = new ContentPanel();	  
	   panelCentral.setSize("100%", "100%");
	   panelCentral.setHeaderVisible(false);
	   
	   vlc = new VerticalLayoutContainer();
	   vlc.setHeight("100%");

	   panelCentral.add(vlc);
	   
	   txtCodigo = new TextField();	   
	   //txtCodigo.setValue("0");
	   
	   if ( this.modo == Ctes.K_MODO_MODIFICACION ) {
	      txtCodigo.setReadOnly(true);
	      txtCodigo.setEnabled(false);
	   }	  
	   else {
		   txtCodigo.setReadOnly(false);
		   txtCodigo.setEnabled(true);  
		   cargarProximoCorrelativo();   
	   }
	   	  
	  vlc.add(new FieldLabel(txtCodigo, "Codigo"), new VerticalLayoutData(100, 30, new Margins(10,1,1,15)));
	   
	  layout.setCenterWidget(panelCentral);
	  
	  btnAceptar = new Button();	   
	  btnAceptar.setText("Aceptar");
	  btnAceptar.setSize("70px", "30px");
	  
	  btnCancelar = new Button();	   
	  btnCancelar.setText("Cancelar");
	  btnCancelar.setSize("70px", "30px");	  	
	  
	  this.addButton(btnAceptar);
	  this.addButton(btnCancelar);
	}
	
	protected void setTitulo() {
		//		
	}



	private void cargarProximoCorrelativo() {
		if (obtenerCodigoCorrelativo().trim().equals("") == false) {
			manejadorCorrelativos.obtenerProximoCorrelativo(obtenerCodigoCorrelativo(), new AsyncCallback<String>() {
	
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub				
				}
	
				@Override
				public void onSuccess(String result) {
				   txtCodigo.setValue(result);
				}
			});
		}
	}

	protected String obtenerCodigoCorrelativo() {
		return null;
	}



	private void initEvents() {
		btnAceptar.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
			  if (modo == Ctes.K_MODO_ALTA) {		       
			     agregarEntidad();				
			  }
			  else if (modo == Ctes.K_MODO_MODIFICACION) {
				 modificarEntidad();
			  }										
			}
		});		
		
		btnCancelar.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				cerrarme();				
			}
		});				
	}

	protected void modificarEntidad() {
    //		
	}

	protected void agregarEntidad()  {		
	//	
	}

	protected void cerrarme(){
		this.hide();
		observableManager.notify(observableManager, null);
	}



	protected void crearManejadorRPC() {
		// TODO Auto-generated method stub
		
	}
}
