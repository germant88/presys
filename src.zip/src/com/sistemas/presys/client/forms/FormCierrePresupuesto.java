package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorSolicitudesPresupuestos;
import com.sistemas.presys.client.rpc.IRPCManejadorSolicitudesPresupuestosAsync;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormCierrePresupuesto extends Window implements IObserver{
	
	protected IRPCManejadorSolicitudesPresupuestosAsync manejadorSolicitudesPresupuestos;
	
    protected Button btnSolicitudPresupuesto;    
    protected TextField codigoSolicitudPresupuesto;
    
    protected Button btnPrespuestoGanado;
    protected Button btnPresupuestoPerdido;
    protected Button btnPresupuestoCancelado;    
	
    ObservableManager observableSeleccionSolPres;
    
    protected Button btnSalir;
    
    
    protected BorderLayoutContainer layout;
	
    public FormCierrePresupuesto(){
       super();
       manejadorSolicitudesPresupuestos = GWT.create(IRPCManejadorSolicitudesPresupuestos.class);
       
       observableSeleccionSolPres = new ObservableManager();
       observableSeleccionSolPres.addObserver(this);
                     
       createComponents();
       
       initEvents();
    }
    
	private void initEvents() {
		btnSolicitudPresupuesto.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
			   FormConsultaPresupuestos form = new FormConsultaPresupuestos(observableSeleccionSolPres, Ctes.K_MODO_CONSULTA_PRESUPUESTOS_PENDIENTES);
			   form.show();		
			}
		});		
		
		btnPrespuestoGanado.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				if (seSeleccionoUnPresupuesto()) { 
					ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "Realmente desea cambiar el estado a GANADO?\n No podra deshacer este cambio luego");
				     box.addHideHandler(ganadoHandler);	
				     ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
				     ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
				     ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
				     box.show();
				}
			}
		});
		
		btnPresupuestoPerdido.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				if (seSeleccionoUnPresupuesto()) {
					ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "Realmente desea cambiar el estado a PERDIDO?\n No podra deshacer este cambio luego");
				     box.addHideHandler(perdidoHandler);	
				     ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
				     ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
				     ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
				     box.show();						
				}										
			}
		});
		
		btnPresupuestoCancelado.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				if (seSeleccionoUnPresupuesto()) { 
					ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "Realmente desea cambiar el estado a CANCELADO?\n No podra deshacer este cambio luego");
				     box.addHideHandler(canceladoHandler);	
				     ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
				     ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
				     ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
				     box.show();
				}
			}
		});
		
		btnSalir.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
			   cerrarme();
			}
		});
	}

	protected boolean seSeleccionoUnPresupuesto() {
		Boolean resultado = false;
		if (codigoSolicitudPresupuesto.getValue() != null) {				
			if (codigoSolicitudPresupuesto.getValue().trim().equals("") == false) {			
				resultado = true;
			}		
		}
		if (resultado == false) {
			MessageBox box = new MessageBox("Informacion");												    												    												    
		    box.setMessage("Debe seleccionar un presupuesto");
			box.show();
		}
		
		return resultado;
	}

	protected void cambiarEstadoSolicitud(Integer xEstado) {
       		/*manejadorSolicitudesPresupuestos.cambiarEstado(codigoSolicitudPresupuesto.getValue(), xEstado, new AsyncCallback<Void>() {
				
				@Override
				public void onSuccess(Void result) {
					MessageBox box = new MessageBox("Informacion");												    												    												    
				    box.setMessage("Se cambio correctamete el estado");
					box.show();
					codigoSolicitudPresupuesto.setValue("");
				}
				
				@Override
				public void onFailure(Throwable caught) {
					MessageBox box = new MessageBox("Error");												    												    												    
				    box.setMessage("Se produjo un error al cambiar el estado: " + caught.getMessage());
					box.show();
				}
			});*/
	}

	private void createComponents() {				
		this.setMaximizable(false);
        this.setModal(true);
        this.setResizable(false);
		
        this.setHeadingText("Cierre de presupuesto");
    
        this.setSize("350px", "300px"); 
		   
		layout = new BorderLayoutContainer();
		
		this.add(layout);
		
		btnSolicitudPresupuesto = new Button();
		btnSolicitudPresupuesto.setText("Buscar");
                		               
		codigoSolicitudPresupuesto = new TextField();
		codigoSolicitudPresupuesto.setReadOnly(true);
                	
		HorizontalPanel hpSolPresupuesto = new HorizontalPanel();
		hpSolPresupuesto.add(new FieldLabel(codigoSolicitudPresupuesto, "Presupuesto"));
				
		hpSolPresupuesto.add(btnSolicitudPresupuesto);
		
		VerticalPanel vpPanelCentral = new VerticalPanel();
	
		vpPanelCentral.add(hpSolPresupuesto);
		
		btnPrespuestoGanado = new Button();
		btnPrespuestoGanado.setText("Ganado");
		
	    btnPresupuestoPerdido = new Button();
	    btnPresupuestoPerdido.setText("Perdido");
	    	    
	    btnPresupuestoCancelado = new Button();
	    btnPresupuestoCancelado.setText("Cancelado");
	    
	    HorizontalPanel hpBotones = new HorizontalPanel();
	    hpBotones.setSpacing(5);
	    hpBotones.add(btnPrespuestoGanado);
	    btnPrespuestoGanado.setSize("100px", "30px");
	    hpBotones.add(btnPresupuestoPerdido);
	    btnPresupuestoPerdido.setSize("100px", "30px");
	    hpBotones.add(btnPresupuestoCancelado);
	    btnPresupuestoCancelado.setSize("100px", "30px");
	    
	    vpPanelCentral.add(hpBotones);
				
		layout.setCenterWidget(vpPanelCentral);
		
		btnSalir = new Button();	   
		btnSalir.setText("Salir");
		btnSalir.setSize("70px", "30px");
		
		this.addButton(btnSalir);
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
	   this.codigoSolicitudPresupuesto.setValue( ((DTGridPresupuesto)changeInfo).getId());
   	   cargarPantallaConSolicitudOrigen(((DTGridPresupuesto)changeInfo).getId());
	}

	private void cargarPantallaConSolicitudOrigen(String id) {
		// TODO Auto-generated method stub		
	}
	
	private void cerrarme() {
		this.hide();
	}
	
	 final HideHandler ganadoHandler = new HideHandler() {
	      @Override
	      public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	        	cambiarEstadoSolicitud(Ctes.K_ESTADO_PRESUPUESTO_GANADO);
	        }	        
	      }
	 };
	 
	 final HideHandler perdidoHandler = new HideHandler() {
	      @Override
	      public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	        	cambiarEstadoSolicitud(Ctes.K_ESTADO_PRESUPUESTO_PERDIDO);
	        }	        
	      }
	 };
	 
	 final HideHandler canceladoHandler = new HideHandler() {
	      @Override
	      public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	        	cambiarEstadoSolicitud(Ctes.K_ESTADO_PRESUPUESTO_CANCELADO);
	        }	        
	      }
	 };
}
