package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.NotaImpresionProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorNotasImpresion;
import com.sistemas.presys.client.rpc.IRPCManejadorNotasImpresionAsync;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMNotasImpresion extends FormABMGenerico{
	
private static final NotaImpresionProperties props = GWT.create(NotaImpresionProperties.class);
	
	protected IRPCManejadorNotasImpresionAsync manejadorNotasImpresion;
	
	public FormABMNotasImpresion(){
		super();		
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Notas Impresion");
	}
	
	@Override
	protected void crearManejadorRPC() {
		manejadorNotasImpresion = GWT.create(IRPCManejadorNotasImpresion.class);
	}
	
	
	@Override
	protected void crearGrilla(){	      
		  ColumnConfig<DTNotaImpresion, String> codigoCol 	    = new ColumnConfig<DTNotaImpresion, String>(props.codigo(),       100, "Codigo");
		  ColumnConfig<DTNotaImpresion, String> nombreCol 	    = new ColumnConfig<DTNotaImpresion, String>(props.nombre(),       100, "Nombre");
		  ColumnConfig<DTNotaImpresion, String> descripcionCol  = new ColumnConfig<DTNotaImpresion, String>(props.descripcion(),  100, "Descripcion");		  
	 
	      List<ColumnConfig<DTNotaImpresion, ?>> l = new ArrayList<ColumnConfig<DTNotaImpresion, ?>>();
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(descripcionCol);
	      	      	      
	      cm = new ColumnModel<DTNotaImpresion>(l);
	 
	      store = new ListStore<DTNotaImpresion>(props.key());	      	     	      
	      
	      grilla = new Grid<DTNotaImpresion>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	     
	}
	
	
	@Override
	protected void ejecutarAgregar(){
		FormNotaImpresion form = new FormNotaImpresion(observableManager, Ctes.K_MODO_ALTA, null);			  
		form.show();
	}
	
	
	@Override
	protected void cargarGrilla(){
		grilla.getStore().clear();
		this.grilla.mask("Cargando Notas de impresion...");
		manejadorNotasImpresion.obtenerNotasImpresion(new  AsyncCallback<ArrayList<DTNotaImpresion>>() {			               
			@SuppressWarnings("unchecked")
			@Override
			public void onSuccess(ArrayList<DTNotaImpresion> result) {
				 store.addAll(result);
                 grilla.reconfigure(store, cm);	
                 grilla.unmask();
			}
			
			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}
		});			
	}

	@Override
	protected void eliminarSeleccionado(){
		ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "�Realmente desea eliminar la nota impresion?");
	    box.addHideHandler(hadlerEliminarNotaImpreison);	
	    ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
	    box.show();
	}
	
	
	 final HideHandler hadlerEliminarNotaImpreison = new HideHandler() {
	     @Override
	     public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarNotaImpresionSeleccionada();
	        }	        
	     }
	 };
	 
	 private void eliminarNotaImpresionSeleccionada(){
	    DTNotaImpresion notaImpresionSeleccionada;
		   
	    notaImpresionSeleccionada = (DTNotaImpresion) grilla.getSelectionModel().getSelectedItem();
	   	 
	    if (notaImpresionSeleccionada != null) {
	        eliminarNotaImpresion(notaImpresionSeleccionada);
	    }else {
	    	errorDebeSeleccionarUnElemento();
	    }
	 }
	 
	 private void eliminarNotaImpresion(DTNotaImpresion notaImpreisonSeleccionada) {
			manejadorNotasImpresion.eliminarNotaImpresion(notaImpreisonSeleccionada.getCodigo(), new AsyncCallback() {

				@Override
				public void onSuccess(Object result) {
			       cargarGrilla();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}			
			}); 
     }

	 public void errorDebeSeleccionarUnElemento() {   
			MessageBox box = new MessageBox("Atencion", "Debe seleccionar una nota de impresion en la grilla");
		    box.show();
		}
	 
	 @Override
	 protected void modificarSeleccionado(){
		 DTNotaImpresion notaImpresionSeleccionada;
		   
		 notaImpresionSeleccionada = (DTNotaImpresion) grilla.getSelectionModel().getSelectedItem();
		   
		   if (notaImpresionSeleccionada != null) {
		      modificarNotaImpresion(notaImpresionSeleccionada);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	 }

	private void modificarNotaImpresion(DTNotaImpresion notaImpresionSeleccionada) {
		FormNotaImpresion form = new FormNotaImpresion(observableManager, Ctes.K_MODO_MODIFICACION, notaImpresionSeleccionada.getCodigo());			  
	    form.show();
	}
	
	@Override
	protected void buscar() {
		 Integer buscarPor;
		   if (this.rbtnFiltrarCodigo.getValue() == true) {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargando nota impresion...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorNotasImpresion.buscarNotaImpresion(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTNotaImpresion>>() {
			
			@Override
			public void onSuccess(ArrayList<DTNotaImpresion> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();
	               ponerFocoEnFiltro();
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}
}
