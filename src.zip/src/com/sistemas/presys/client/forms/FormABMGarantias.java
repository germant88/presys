package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.GarantiaProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorGarantias;
import com.sistemas.presys.client.rpc.IRPCManejadorGarantiasAsync;
import com.sistemas.presys.shared.model.Garantia;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMGarantias extends FormABMGenerico{

	private static final GarantiaProperties props = GWT.create(GarantiaProperties.class);
	
	protected IRPCManejadorGarantiasAsync manejadorGarantias;
	
	public FormABMGarantias(){
		super();		
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Garantias");
	}
	
	@Override
	protected void crearManejadorRPC() {
		manejadorGarantias = GWT.create(IRPCManejadorGarantias.class);
	}
	
	
	@Override
	protected void crearGrilla(){	      
		  ColumnConfig<Garantia, String> codigoCol 	    = new ColumnConfig<Garantia, String>(props.codigo(),    100, "Codigo");
		  ColumnConfig<Garantia, String> nombreCol 	    = new ColumnConfig<Garantia, String>(props.nombre(),    100, "Nombre");
		  ColumnConfig<Garantia, String> duracionCol    = new ColumnConfig<Garantia, String>(props.duracion(),  100, "Duracion");		  
	 
	      List<ColumnConfig<Garantia, ?>> l = new ArrayList<ColumnConfig<Garantia, ?>>();
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(duracionCol);
	      	      	      
	      cm = new ColumnModel<Garantia>(l);
	 
	      store = new ListStore<Garantia>(props.key());	      	     	      
	      
	      grilla = new Grid<Garantia>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	     
	}
	
	
	@Override
	protected void ejecutarAgregar(){
		FormGarantia form = new FormGarantia(observableManager, Ctes.K_MODO_ALTA, null);			  
		form.show();
	}
	
	
	@Override
	protected void cargarGrilla(){
		grilla.getStore().clear();
		this.grilla.mask("Cargando garantias...");
		manejadorGarantias.obtenerGarantias(new  AsyncCallback<ArrayList<Garantia>>() {			               
			@SuppressWarnings("unchecked")
			@Override
			public void onSuccess(ArrayList<Garantia> result) {
				 store.addAll(result);
                 grilla.reconfigure(store, cm);	
                 grilla.unmask();
			}
			
			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}
		});			
	}

	@Override
	protected void eliminarSeleccionado(){
		ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "�Realmente desea eliminar la garantia?");
	    box.addHideHandler(hadlerEliminarGarantia);	
	    ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
	    box.show();
	}
	
	
	 final HideHandler hadlerEliminarGarantia = new HideHandler() {
	     @Override
	     public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarGarantiaSeleccionado();
	        }	        
	     }
	 };
	 
	 private void eliminarGarantiaSeleccionado(){
	    Garantia garantiaSeleccionada;
		   
	    garantiaSeleccionada = (Garantia) grilla.getSelectionModel().getSelectedItem();
	   	    
	    eliminarGarantia(garantiaSeleccionada);            	    
	 }
	 
	 private void eliminarGarantia(Garantia garantiaSeleccionada) {
			manejadorGarantias.eliminar(garantiaSeleccionada.getCodigo(), new AsyncCallback() {

				@Override
				public void onSuccess(Object result) {
			       cargarGrilla();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}			
			}); 
     }

	 public void errorDebeSeleccionarUnElemento() {
			/*final Dialog simple = new Dialog();
		    simple.setHeadingText("Atencion");
		    simple.setPredefinedButtons(PredefinedButton.OK);
		    simple.setBodyStyleName("pad-text");
		    simple.add(new Label("Debe seleccionar un segmento en la grilla"));
		    simple.getBody().addClassName("pad-text");
		    simple.setHideOnButtonClick(true);
		    simple.setWidth(300);
		   
		   simple.show();
		   */
		   
			MessageBox box = new MessageBox("Atencion", "Debe seleccionar una garantia en la grilla");
		    box.show();
		}
	 
	 @Override
	 protected void modificarSeleccionado(){
		 Garantia garantiaSeleccionada;
		   
		 garantiaSeleccionada = (Garantia) grilla.getSelectionModel().getSelectedItem();
		   
		   if (garantiaSeleccionada != null) {
		      modificarGarantia(garantiaSeleccionada);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	 }

	private void modificarGarantia(Garantia garantiaSeleccionada) {
		FormGarantia form = new FormGarantia(observableManager, Ctes.K_MODO_MODIFICACION, garantiaSeleccionada.getCodigo());			  
	    form.show();
	}
	
	@Override
	protected void buscar() {
		 Integer buscarPor;
		   if (this.rbtnFiltrarCodigo.getValue() == true) {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargando garantia...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorGarantias.buscar(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<Garantia>>() {
			
			@Override
			public void onSuccess(ArrayList<Garantia> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();
	               ponerFocoEnFiltro();
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}
	
}
