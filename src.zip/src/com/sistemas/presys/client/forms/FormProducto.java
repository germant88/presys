package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorProductos;
import com.sistemas.presys.client.rpc.IRPCManejadorProductosAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormProducto extends FormEntidadGenerico{
	
	protected IRPCManejadorProductosAsync manejadorProductos;
	
	private TextField txtNombre;
	private TextArea  txtDescripcion;
	private CheckBox  chkHabilitado;
	
	
	
	
	public FormProducto(ObservableManager xobsManager, Integer xmodo, String xcodigo) {		
		super(xobsManager, xmodo, xcodigo);				
	}	
	

	@Override
	protected void crearManejadorRPC() {
		 manejadorProductos = GWT.create(IRPCManejadorProductos.class);
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Producto");		
	}	
	
	@Override
	protected String  obtenerCodigoCorrelativo(){
		return Ctes.K_CORR_PROD;
	}
	
	@Override
	protected void createComponents(){
		super.createComponents();
						
		txtNombre = new TextField();
	    vlc.add(new FieldLabel(txtNombre, "Nombre"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
	    
	    txtDescripcion = new TextArea();
	    vlc.add(new FieldLabel(txtDescripcion, "Descripcion"),new VerticalLayoutData(450, 150, new Margins(30,1,1,15)));
	    
		chkHabilitado = new CheckBox();
		
		if (modo == Ctes.K_MODO_ALTA) {
		   chkHabilitado.setValue(true);		
		   chkHabilitado.setReadOnly(true);
		}
		
		vlc.add(new FieldLabel(chkHabilitado, "Habilitado"),new VerticalLayoutData(40, 50, new Margins(30,1,1,15)));
		
		txtNombre.focus();
		this.setFocusWidget(txtNombre);
	}
	
	
	@Override
	protected void agregarEntidad(){
		try {
		    manejadorProductos.agregarProducto(txtCodigo.getValue(), txtNombre.getValue(), txtDescripcion.getValue(), new AsyncCallback() {

				@Override
				public void onFailure(Throwable caught) {
					 MessageBox box = new MessageBox("Error");												    												    												    
				     box.setMessage("Se produjo un error al intentar agregar el producto: " + caught.getMessage());
					 box.show();					
				}

				@Override
				public void onSuccess(Object result) {
		            cerrarme();					
				}
			});
			
		} catch (LogicException e) {		
			  e.printStackTrace();
		}	
	}
	
	@Override
	protected void modificarEntidad() {
		manejadorProductos.modificarProducto(txtCodigo.getValue() , txtNombre.getValue(), txtDescripcion.getValue(),
                chkHabilitado.getValue(), new AsyncCallback<DTProducto>() {

					@Override
					public void onFailure(
							Throwable caught) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onSuccess(DTProducto result) {
						cerrarme();  						
					}
				});
    }
	
	@Override
	protected void cargarPantalla(String xcodigo) {
		manejadorProductos.obtenerPorCodigo(xcodigo, new AsyncCallback<DTProducto>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(DTProducto result) {
				cargarPantallaConObjeto(result);
				
			}
		});     			
    }

	@Override
    protected void cargarPantallaConObjeto(Object entidad) {
       DTProducto producto = (DTProducto) entidad;
		
	   this.txtCodigo.setValue(String.valueOf(producto.getCodigo()));
 	   this.txtNombre.setValue(producto.getNombre() != null ? producto.getNombre() : "");
 	   this.txtDescripcion.setValue(producto.getDescripcion() != null ? producto.getDescripcion() : "");       
 	   this.chkHabilitado.setValue(producto.getHabilitado()); 	   	   
    }

}
