package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.sencha.gxt.core.client.IdentityValueProvider;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.PasswordField;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.CheckBoxSelectionModel;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.RolesProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorRoles;
import com.sistemas.presys.client.rpc.IRPCManejadorRolesAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuarios;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuariosAsync;
import com.sistemas.presys.shared.datatypes.DTRol;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormUsuario extends Window{
	
	private static final RolesProperties props = GWT.create(RolesProperties.class);
	
	protected ObservableManager observableManager;
    protected Integer modo;
    protected IRPCManejadorUsuariosAsync manejadorUsuarios;
    protected IRPCManejadorRolesAsync manejadorRoles;    
    private String codigo;
	
    private TextField     txtCodigo;
	private TextField     txtNombre;
	private TextField     txtApellido;
	private CheckBox      cambiarContrasena;
	private PasswordField txtContrasena;
	private PasswordField txtRepetirContrasena;
	
	protected Button btnAceptar;
	protected Button btnCancelar;
	protected BorderLayoutContainer layout;
	protected BorderLayoutContainer layoutRoles;
	
	protected Grid grillaRoles;
	private ListStore<DTRol> store;
	private ColumnModel<DTRol> cm;
	private ArrayList<DTRol> listaRoles;
	
	protected VerticalLayoutContainer vlc;
	
	private TabPanel tabPanel;
	
	public FormUsuario(ObservableManager xobsManager, Integer xmodo, String xcodigo){		
	   super();
	   observableManager = xobsManager;
	   modo              = xmodo;     	  
	   manejadorUsuarios = GWT.create(IRPCManejadorUsuarios.class);
	   manejadorRoles    = GWT.create(IRPCManejadorRoles.class);
	   codigo            = xcodigo;
	   listaRoles = new ArrayList<DTRol>();
	   createComponents();	
	   initEvents();
	   
	   //if (modo == Ctes.K_MODO_ALTA) {
	      cargarListaRoles();
	   //}
	   //else if (modo == Ctes.K_MODO_MODIFICACION) {
	   //   cargarPantalla(xcodigo);	      
	   //}	  	   					   
	}	

	private void cargarListaRoles() {
       manejadorRoles.obtenerRoles(new AsyncCallback<ArrayList<DTRol>>() {

		@Override
		public void onFailure(Throwable caught) {
			//			
		}

		@Override
		public void onSuccess(ArrayList<DTRol> result) {
			listaRoles = result;
			cargarGrilla();
			if (modo == Ctes.K_MODO_MODIFICACION) {
				cargarPantalla(codigo);
			}
		}
	});		
	}

	private void initEvents() {
       btnAceptar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {

			if (modo == Ctes.K_MODO_ALTA) {		       
			     agregarUsuario();				
			  }
			  else if (modo == Ctes.K_MODO_MODIFICACION) {
				 modificarUsuario();
			  }				
		}
	});			
       
       if (modo == Ctes.K_MODO_MODIFICACION) {
    	   cambiarContrasena.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
			   if (cambiarContrasena.getValue()) {
				   txtContrasena.setEnabled(false);
				   txtRepetirContrasena.setEnabled(false);				   
			   }
			   else {
				   txtContrasena.setEnabled(true);
				   txtRepetirContrasena.setEnabled(true);
			   }
				
			}
		});
       }
       
       btnCancelar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {		
			cerrarme();
		}
	});
       
	}
	
	protected void modificarUsuario() {
		if (validarDatos()) {
			List<DTRol> listaRolesSeleccionados = (List<DTRol>) grillaRoles.getSelectionModel().getSelectedItems();
			
			manejadorUsuarios.modificar(txtCodigo.getValue(), txtNombre.getValue(), txtApellido.getValue(), txtContrasena.getValue(), cambiarContrasena.getValue(), listaRolesSeleccionados, new AsyncCallback<Void>() {
	
				@Override
				public void onFailure(Throwable caught) {
					MessageBox box = new MessageBox("Error");												    												    												    
				     box.setMessage("Se produjo un error al intentar modificar el usuario: " + caught.getMessage());
					 box.show();									
				}
	
				@Override
				public void onSuccess(Void result) {
					MessageBox box = new MessageBox("Informacion");												    												    												    
				    box.setMessage("Se modifico correctamente el usuario " + txtCodigo.getValue());
					box.show();
					cerrarme();						
				}
			});
		}
	}


	private void agregarUsuario() {
		if (validarDatos()) {
			    List<DTRol> listaRolesSeleccionados = (List<DTRol>) grillaRoles.getSelectionModel().getSelectedItems();	    			
			
				manejadorUsuarios.agregarUsuario(txtCodigo.getValue(), txtNombre.getValue(), txtApellido.getValue(), txtContrasena.getValue(), listaRolesSeleccionados, new AsyncCallback<Void>() {
		
				@Override
				public void onFailure(Throwable caught) {
					 MessageBox box = new MessageBox("Error");												    												    												    
				     box.setMessage("Se produjo un error al intentar agregar el usuario: " + caught.getMessage());
					 box.show();				
				}
		
				@Override
				public void onSuccess(Void result) {
					cerrarme();				
				}
			});
		}		
	}
	
	
	
	private boolean validarDatos() {
		boolean ok = true;
		
		// Validar contrasenas
		if (modo == Ctes.K_MODO_MODIFICACION) {
			if (cambiarContrasena.getValue()) {
				if (txtContrasena.getValue().equals(txtRepetirContrasena.getValue()) == false) {
					ok = false;
				}
			}
		}
		if (modo == Ctes.K_MODO_ALTA) {
			if (txtContrasena.getValue().equals(txtRepetirContrasena.getValue()) == false) {
				ok = false;
			}
		}
		
		if (ok == false) {
			MessageBox box = new MessageBox("Error");												    												    												    
		    box.setMessage("Las contrase\u00f1as ingresadas no coinciden");
			box.show();				
		}
		
		if (ok) {
			if (modo == Ctes.K_MODO_ALTA) {
				if (txtContrasena.getValue().trim().equals("")) {
					ok = false;
					MessageBox box = new MessageBox("Error");												    												    												    
				    box.setMessage("Debe ingresar la contrase\u00f1a");
					box.show();		
				}
			}
			else if (modo == Ctes.K_MODO_MODIFICACION) {
				if (cambiarContrasena.getValue()) {
					if (txtContrasena.getValue().trim().equals("")) {
						ok = false;
						MessageBox box = new MessageBox("Error");												    												    												    
					    box.setMessage("Debe ingresar la contrase\u00f1a");
						box.show();		
					}
				}
			}
		}
		
		if (ok) {
			if (! (grillaRoles.getSelectionModel().getSelectedItems().size() > 0)) {
				ok = false;
				MessageBox box = new MessageBox("Error");												    												    												    
			    box.setMessage("Debe seleccionar al menos un rol");
				box.show();		
			}
		}
				
		return ok;
	}


	protected void cargarPantalla(String xcodigo) {
		try {
			manejadorUsuarios.obtenerPorCodigo(xcodigo, new AsyncCallback<DTUsuario>() {
				
				@Override
				public void onSuccess(DTUsuario result) {
			       cargarPantallaConObjeto(result);				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					MessageBox box = new MessageBox("Error");												    												    												    
				    box.setMessage("Se produjo un error al intentar obtener el usuario: " + caught.getMessage());
					box.show();				
				}
			});
		} catch (LogicException e) {
			MessageBox box = new MessageBox("Error");												    												    												    
		    box.setMessage("Se produjo un error al intentar obtener el usuario: " + e.getMessage());
			box.show();
		}
}


    protected void cargarPantallaConObjeto(DTUsuario xusuario) {	       	
       this.txtCodigo.setValue(xusuario.getId());
 	   this.txtNombre.setValue(xusuario.getNombre());
 	   this.txtApellido.setValue(xusuario.getApellido());
       
 	   for (int i = 0; i < store.getAll().size(); i++) { 	       		   
 		   if (xusuario.getListaRoles().contains(store.get(i))) {
 			   grillaRoles.getSelectionModel().select(i, true);
 		   } 			    		   
 	   }
 	     	    	   
    }

	private void marcarRolEnGrilla(DTRol dtRol) {       		
		grillaRoles.getSelectionModel().select(store.indexOf(dtRol), false);		
	}

	private void createComponents() {
		   this.setMaximizable(true);
		   this.setModal(true);
		   this.setHeadingText("Usuario");
		  
		   this.setSize("500px", "600px");
		   
		   tabPanel = new TabPanel();
	       tabPanel.setSize("100%", "100%");
			   
		   layout = new BorderLayoutContainer();
			   
		   this.add(tabPanel);
			
		   tabPanel.add(layout, "General");		  
		      
		   ContentPanel panelCentral = new ContentPanel();	  
		   panelCentral.setSize("100%", "100%");
		   panelCentral.setHeaderVisible(false);
		   
		   vlc = new VerticalLayoutContainer();
		   vlc.setHeight("100%");

		   panelCentral.add(vlc);		
		   
		    txtCodigo = new TextField();
		    vlc.add(new FieldLabel(txtCodigo, "Codigo"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
		    if (modo == Ctes.K_MODO_MODIFICACION) {
		    	txtCodigo.setEnabled(false);
		    	txtCodigo.setReadOnly(false);
		    }
		    
		    txtNombre = new TextField();
		    vlc.add(new FieldLabel(txtNombre, "Nombre"),new VerticalLayoutData(450, 50, new Margins(30,1,1,15)));
		    
		    txtApellido = new TextField();
		    vlc.add(new FieldLabel(txtApellido, "Apellido"),new VerticalLayoutData(450, 50, new Margins(30,1,1,15)));
		    
		    if (modo == Ctes.K_MODO_MODIFICACION) {
		       cambiarContrasena = new CheckBox();
			   vlc.add(new FieldLabel(cambiarContrasena, "Cambiar contrase\u00f1a"), new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));	
		    }   		    		  		    
		    
		    txtContrasena = new PasswordField();
		    vlc.add(new FieldLabel(txtContrasena, "Contrase\u00f1a"),new VerticalLayoutData(450, 50, new Margins(30,1,1,15)));
		    
		    txtRepetirContrasena = new PasswordField();
		    vlc.add(new FieldLabel(txtRepetirContrasena, "Repetir contrase\u00f1a"),new VerticalLayoutData(450, 50, new Margins(30,1,1,15)));
		    
		    if (modo == Ctes.K_MODO_MODIFICACION) {
		    	txtContrasena.setEnabled(false);
		    	txtRepetirContrasena.setEnabled(false);
		    	cambiarContrasena.setValue(false);
		    }
			
			txtCodigo.focus();
			this.setFocusWidget(txtCodigo);
		   	   
		  layout.setCenterWidget(panelCentral);
		  
		  layoutRoles = new BorderLayoutContainer();
		  
		  crearGrillaRoles();
		  
		  layoutRoles.setCenterWidget(grillaRoles);
		  		  		  		  
		  tabPanel.add(layoutRoles, "Roles");
		  		  		  				  
		  btnAceptar = new Button();	   
		  btnAceptar.setText("Aceptar");
		  btnAceptar.setSize("70px", "30px");
		  
		  btnCancelar = new Button();	   
		  btnCancelar.setText("Cancelar");
		  btnCancelar.setSize("70px", "30px");
		  		  		 
		  this.addButton(btnAceptar);
		  this.addButton(btnCancelar);
	}	
	
	protected void cerrarme(){
		this.hide();
		observableManager.notify(observableManager, null);
	}
	
	private void crearGrillaRoles(){
	      IdentityValueProvider<DTRol> identity = new IdentityValueProvider<DTRol>(); 
		
		  final CheckBoxSelectionModel<DTRol> sm = new CheckBoxSelectionModel<DTRol>(identity);
		 
	      ColumnConfig<DTRol, String> codigoCol = new ColumnConfig<DTRol, String>(props.id(), 200, "Codigo");
	      ColumnConfig<DTRol, String> nombreCol = new ColumnConfig<DTRol, String>(props.nombre(), 100, "Nombre");
	      
	      List<ColumnConfig<DTRol, ?>> l = new ArrayList<ColumnConfig<DTRol, ?>>();
	      l.add(sm.getColumn());
	      l.add(codigoCol);
	      l.add(nombreCol);
	      
	      cm = new ColumnModel<DTRol>(l);
	      
	      store = new ListStore<DTRol>(props.key());	      	     	      
	 
	      grillaRoles = new Grid<DTRol>(store, cm);
	      grillaRoles.setSelectionModel(sm);
	      grillaRoles.getView().setAutoExpandColumn(nombreCol);
	      grillaRoles.setBorders(false);
	      grillaRoles.getView().setStripeRows(true);
	      grillaRoles.getView().setColumnLines(true);
	      grillaRoles.setStateId("Grilla");
	      grillaRoles.setSize("100%", "100%");	
	}
	
	private void cargarGrilla(){
		grillaRoles.getStore().clear();
		this.grillaRoles.mask("Cargando roles...");
		store.addAll(listaRoles);
		grillaRoles.reconfigure(store, cm);	
		grillaRoles.unmask();				
	}
}
