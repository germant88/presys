package com.sistemas.presys.client.forms;


import java.util.ArrayList;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.SegmentoProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorClientes;
import com.sistemas.presys.client.rpc.IRPCManejadorClientesAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativos;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativosAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorSegmentos;
import com.sistemas.presys.client.rpc.IRPCManejadorSegmentosAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormCliente extends Window{
	
	private TextField txtCodigo;
	private TextField txtNombre;
	private TextField txtEmail;
	private TextField txtDireccion;
    private TextField txtRut;
    private TextField txtTelefono;
    private FieldSet  fsContacto;
    private TextField txtContactoNombre;
    private TextField txtContactoEmail;
    private TextField txtcontactoTelefono;
    private ComboBox<DTSegmento> cboxSegmentos;
    private ObservableManager observableManager;
    Integer modo;     
    private String codigoCliente;
    
    private final IRPCManejadorClientesAsync manejadorClientes = GWT
			.create(IRPCManejadorClientes.class);
    
    private final IRPCManejadorCorrelativosAsync manejadorCorrelativos = GWT
			.create(IRPCManejadorCorrelativos.class);
    
    private final IRPCManejadorSegmentosAsync manejadorSegmentos = GWT
    		.create(IRPCManejadorSegmentos.class);
    
    private static final SegmentoProperties props = GWT.create(SegmentoProperties.class);
    
    
    

	// TODO: tipo de cliente

	private Button btnAceptar;
	private Button btnCancelar;
	private BorderLayoutContainer layout;
	
	
	public FormCliente(ObservableManager xobsManager, Integer xmodo, String xcodigoCliente) {
	   super();
	   observableManager = xobsManager;
	   modo              = xmodo;
	   codigoCliente     = xcodigoCliente;
	   createComponents();	
	   initEvents();	   
	   cargarSegmentos();
	   
	      
	   txtRut.focus();
	   this.setFocusWidget(txtRut);	   
	}		
	


	private void cargarSegmentos() {
		final ListStore<DTSegmento> store;
		store = new ListStore<DTSegmento>(props.key());
		
		manejadorSegmentos.obtenerSegmentos(new  AsyncCallback<ArrayList<DTSegmento>>() {			               
			@SuppressWarnings("unchecked")
			@Override
			public void onSuccess(ArrayList<DTSegmento> result) {
				 store.addAll(result);
                 cboxSegmentos.clear(); 
				 cboxSegmentos.setStore(store);
				 if (modo == Ctes.K_MODO_MODIFICACION) {
				      cargarPantalla(codigoCliente);         	   
				   }	                
			}
			
			@Override
			public void onFailure(Throwable caught) {
               //
			}
		});					
	}



	private void cargarPantalla(String xcodigoCliente) {
		manejadorClientes.obtenerClientePorCodigo(xcodigoCliente, new AsyncCallback<DTCliente>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(DTCliente result) {
				cargarPantallaConObjeto(result);
				
			}
		});     			
	}

   private void cargarPantallaConObjeto(DTCliente cliente) {
	   this.txtCodigo.setValue(String.valueOf(cliente.getCodigo()));
	   this.txtNombre.setValue(cliente.getNombre() != null ? cliente.getNombre() : "");
	   this.txtEmail.setValue(cliente.getEmail() != null ? cliente.getEmail() : "");
	   this.txtRut.setValue(cliente.getRut() != null ? cliente.getRut() : "");
	   this.txtDireccion.setValue(cliente.getDireccion() != null ? cliente.getDireccion() : "");
	   this.txtTelefono.setValue(cliente.getTelefono() != null ? cliente.getTelefono() : "");
	   this.txtContactoNombre.setValue(cliente.getContactoNombre() != null ? cliente.getContactoNombre() : "");
	   this.txtContactoEmail.setValue(cliente.getContactoEmail() != null ? cliente.getContactoEmail() : "");
	   this.txtcontactoTelefono.setValue(cliente.getContactoTelefono() != null ? cliente.getContactoTelefono() : "");
	   this.cboxSegmentos.setValue(cliente.getSegmento());
   }
	

	private void createComponents() {
	   this.setMaximizable(true);
	   this.setModal(true);
	   this.setHeadingText("Cliente");	   
	   this.setSize("500px", "650px");
	   
	   layout = new BorderLayoutContainer();
	   
	   this.add(layout);
	      
	   ContentPanel panelCentral = new ContentPanel();	  
	   panelCentral.setSize("100%", "100%");
	   panelCentral.setHeaderVisible(false);
	   
	   VerticalLayoutContainer vlc = new VerticalLayoutContainer();
	   vlc.setHeight("100%");

	   panelCentral.add(vlc);
	   
	   txtCodigo = new TextField();	   
	   txtCodigo.setValue("0");
	   
	   if ( this.modo == Ctes.K_MODO_MODIFICACION ) {
	      txtCodigo.setReadOnly(true);
	      txtCodigo.setEnabled(false);
	   }	  
	   else {
		   txtCodigo.setReadOnly(false);
		   txtCodigo.setEnabled(true);  
		   cargarProximoCorrelativo();
	   }
	   	  
	   vlc.add(new FieldLabel(txtCodigo, "Codigo"), new VerticalLayoutData(100, 30, new Margins(10,1,1,15)));
	   
	   txtRut = new TextField();
       vlc.add(new FieldLabel(txtRut, "RUT"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));	   
	   	   
	  txtNombre = new  TextField();
	  vlc.add(new FieldLabel(txtNombre, "Nombre"), new VerticalLayoutData(400, 50, new Margins(30,1,1,15)));
	  
	  txtEmail = new TextField();
	  vlc.add(new FieldLabel(txtEmail, "E-mail"), new VerticalLayoutData(400, 50, new Margins(30,1,1,15)));
	  
	  txtTelefono = new TextField();
	  vlc.add(new FieldLabel(txtTelefono, "Telefono"), new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
	  
	  txtDireccion = new TextField();
	  vlc.add(new FieldLabel (txtDireccion, "Direccion"), new VerticalLayoutData(400, 50, new Margins(30,1,1,15)));
	  
      ListStore<DTSegmento> segmentos = new ListStore<DTSegmento>(props.key());
      
      cboxSegmentos = new ComboBox<DTSegmento>(segmentos, props.nombreLabel());     
      cboxSegmentos.setEmptyText("Seleccione un segmento...");
      cboxSegmentos.setWidth(150);
      cboxSegmentos.setTypeAhead(true);
      
      vlc.add(new FieldLabel (cboxSegmentos, "Segmento"), new VerticalLayoutData(400, 50, new Margins(30,1,1,15)));
	  fsContacto = new FieldSet();
	  fsContacto.setHeadingText("Contacto");
	  fsContacto.setCollapsible(true);
	  fsContacto.setSize("400px", "180px");
	  vlc.add(fsContacto, new VerticalLayoutData(450, 195, new Margins(30,1,1,5)));
	  
	  VerticalLayoutContainer vlcContacto = new VerticalLayoutContainer();
	  
	  txtContactoNombre   = new TextField();
	  vlcContacto.add(new FieldLabel (txtContactoNombre, "Nombre"), new VerticalLayoutData(400, 50, new Margins(5,1,1,0)));
	  txtContactoEmail    = new TextField();
	  vlcContacto.add(new FieldLabel (txtContactoEmail, "E-mail"), new VerticalLayoutData(400, 50, new Margins(5,1,1,0)));
	  txtcontactoTelefono = new TextField();
	  vlcContacto.add(new FieldLabel (txtcontactoTelefono, "Telefono"), new VerticalLayoutData(300, 50, new Margins(5,1,1,0)));
	  
	  fsContacto.add(vlcContacto);
	 
	  layout.setCenterWidget(panelCentral);
	  
	  btnAceptar = new Button();	   
	  btnAceptar.setText("Aceptar");
	  btnAceptar.setSize("70px", "30px");
	  
	  btnCancelar = new Button();	   
	  btnCancelar.setText("Cancelar");
	  btnCancelar.setSize("70px", "30px");	  	
	  
	  this.addButton(btnAceptar);
	  this.addButton(btnCancelar);
	}
	
	private void cargarProximoCorrelativo() {

		manejadorCorrelativos.obtenerProximoCorrelativo(Ctes.K_CORR_CLI, new AsyncCallback<String>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(String result) {
			   txtCodigo.setValue(result);
			}
		});
		
	}



	private void initEvents() {
		btnAceptar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
			  if (modo == Ctes.K_MODO_ALTA) {
		       
					agregarCliente();
				
			  }
			  else if (modo == Ctes.K_MODO_MODIFICACION) {
				 modificarCliente();
			  }
										
			}
		});		
		
		btnCancelar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				cerrarme();				
			}
		});				
	}



	protected void modificarCliente() {
		manejadorClientes.modificarCliente(txtCodigo.getValue() , txtNombre.getValue(), txtEmail.getValue(),
				                         txtDireccion.getValue(), txtRut.getValue(), txtTelefono.getValue(),
				                         txtContactoNombre.getValue(), txtContactoEmail.getValue(), 
				                         txtcontactoTelefono.getValue(), cboxSegmentos.getValue().getCodigo(), new AsyncCallback<DTCliente>() {

											@Override
											public void onFailure(
													Throwable caught) {
												// TODO Auto-generated method stub
												
											}

											@Override
											public void onSuccess(
													DTCliente result) {
												cerrarme();  
												
											}
										});
		
	}



	protected void agregarCliente()  {		
		try {
			manejadorClientes.agregarCliente(txtCodigo.getValue() , txtNombre.getValue(), txtEmail.getValue(),
					                         txtDireccion.getValue(), txtRut.getValue(), txtTelefono.getValue(),
					                         txtContactoNombre.getValue(), txtContactoEmail.getValue(), 
					                         txtcontactoTelefono.getValue(), cboxSegmentos.getValue().getCodigo(), 
					                         new AsyncCallback<DTCliente>() {
												
												@Override
									            public void onSuccess(DTCliente result) {
			                                       cerrarme();   											   	
												}
												
												@Override
												public void onFailure(Throwable caught) {
													
													 MessageBox box = new MessageBox("Error");												    												    												    
												     box.setMessage("Se produjo un error al intentar agregar el cliente: " + caught.getMessage());
													 box.show();
												}
											});
		} catch (LogicException e) {		
			e.printStackTrace();
		}	
	}


	
	private void cerrarme(){
		this.hide();
		observableManager.notify(observableManager, null);
	}



}
