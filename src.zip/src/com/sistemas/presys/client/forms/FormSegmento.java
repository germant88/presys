package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorSegmentos;
import com.sistemas.presys.client.rpc.IRPCManejadorSegmentosAsync;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormSegmento extends FormEntidadGenerico {

	protected IRPCManejadorSegmentosAsync manejadorSegmentos;
	
	private TextField txtNombre;
	private TextArea  txtDescripcion;
	private CheckBox  chkHabilitado;
	
	
	public FormSegmento(ObservableManager xobsManager, Integer xmodo, String xcodigo) {		
		super(xobsManager, xmodo, xcodigo);				
	}	
	

	@Override
	protected void crearManejadorRPC() {
		 manejadorSegmentos = GWT.create(IRPCManejadorSegmentos.class);
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Segmento");		
	}	
	
	@Override
	protected String  obtenerCodigoCorrelativo(){
		return Ctes.K_CORR_SEG;
	}
	
	@Override
	protected void createComponents(){
		super.createComponents();
						
		txtNombre = new TextField();
	    vlc.add(new FieldLabel(txtNombre, "Nombre"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
	    
	    txtDescripcion = new TextArea();
	    vlc.add(new FieldLabel(txtDescripcion, "Descripcion"),new VerticalLayoutData(450, 150, new Margins(30,1,1,15)));
	    
		chkHabilitado = new CheckBox();
		
		if (modo == Ctes.K_MODO_ALTA) {
		   chkHabilitado.setValue(true);		
		   chkHabilitado.setReadOnly(true);
		}
		
		vlc.add(new FieldLabel(chkHabilitado, "Habilitado"),new VerticalLayoutData(40, 50, new Margins(30,1,1,15)));
		
		txtNombre.focus();
		this.setFocusWidget(txtNombre);
	}
	
	
	@Override
	protected void agregarEntidad(){
		try {
		    manejadorSegmentos.agregarSegmento(txtCodigo.getValue(), txtNombre.getValue(), txtDescripcion.getValue(), new AsyncCallback() {

				@Override
				public void onFailure(Throwable caught) {
					 MessageBox box = new MessageBox("Error");												    												    												    
				     box.setMessage("Se produjo un error al intentar agregar el segmento: " + caught.getMessage());
					 box.show();					
				}

				@Override
				public void onSuccess(Object result) {
		            cerrarme();					
				}
			});
			
		} catch (LogicException e) {		
			  e.printStackTrace();
		}	
	}
	
	@Override
	protected void modificarEntidad() {
		manejadorSegmentos.modificarSegmento(txtCodigo.getValue() , txtNombre.getValue(), txtDescripcion.getValue(),
                chkHabilitado.getValue(), new AsyncCallback<DTSegmento>() {

					@Override
					public void onFailure(
							Throwable caught) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onSuccess(DTSegmento result) {
						cerrarme();  						
					}
				});
    }
	
	@Override
	protected void cargarPantalla(String xcodigo) {
		manejadorSegmentos.obtenerPorCodigo(xcodigo, new AsyncCallback<DTSegmento>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(DTSegmento result) {
				cargarPantallaConObjeto(result);
				
			}
		});     			
    }

	@Override
    protected void cargarPantallaConObjeto(Object entidad) {
       DTSegmento segmento = (DTSegmento) entidad;
		
	   this.txtCodigo.setValue(String.valueOf(segmento.getCodigo()));
 	   this.txtNombre.setValue(segmento.getNombre() != null ? segmento.getNombre() : "");
 	   this.txtDescripcion.setValue(segmento.getDescripcion() != null ? segmento.getDescripcion() : "");       
 	   this.chkHabilitado.setValue(segmento.getHabilitado()); 	   	   
    }


}
