package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.widgets.Component;
import com.gwtext.client.widgets.Toolbar;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.event.ButtonListener;
import com.gwtext.client.widgets.form.Label;
import com.gwtext.client.widgets.menu.Menu;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.form.ComboBox;
import com.sencha.gxt.widget.core.client.form.DateField;
import com.sencha.gxt.widget.core.client.form.DateTimePropertyEditor;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.NotaSeguimientoProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativos;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativosAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorSolicitudesPresupuestos;
import com.sistemas.presys.client.rpc.IRPCManejadorSolicitudesPresupuestosAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormSolicitud extends Window implements IObserver{

	protected final IRPCManejadorCorrelativosAsync manejadorCorrelativos = GWT
			.create(IRPCManejadorCorrelativos.class);
	
	private static final NotaSeguimientoProperties props = GWT.create(NotaSeguimientoProperties.class);
	
	protected Button btnConfirmar;
	protected Button btnCancelar;
	
	protected BorderLayoutContainer layout;
	
	protected BorderLayoutContainer layoutSeguimiento;
	
	protected FieldSet fsCliente;
	
	protected FieldSet fsEdificio;
	
	protected FieldSet fsUsuario;
	
    protected TextField txtCodigo;
    
    protected TextField txtNombreCliente;
    
    protected TextField txtNombreEdificio;
   
    protected TextField txtNombreUsuario;
    
    protected TextField txtDireccionEdificio;
    
    protected TextField txtUsuarioAsignado;
    
    protected DateField dtfFechaIngreso;
    
    private ComboBox<DTCliente> cboxClientes;
    
    private ComboBox<DTEdificio> cboxEdificios;
    	
	private TextArea txtDetalles;
	
	private SeleccionObjeto seleccionCliente;
	
	private SeleccionObjeto seleccionEdificio;
	
	private SeleccionObjeto seleccionUsuario;
	
	private DateField dtfFechaDeSeguimiento;
	
	private TextField txtEstado;
	
	private Label lblDetalles;
	
	private TabPanel tabPanel;
	
	private Integer modoNotaActual;
	
	ToolbarButton btnAgregar;
	
	ToolbarButton btnModificar;
	
	ToolbarButton btnEliminar;

	ObservableManager observableManager;
	
	ObservableManager observableManagerSeleccion;
	
	ObservableManager observableNotas;
	
	Integer modo;     
    
	private String codigo;
	
	private String tipoDocumento;
	
	private Grid<DTNotaSeguimiento> grillaSeguimiento;
	
	private ListStore<DTNotaSeguimiento> store;
	private ColumnModel<DTNotaSeguimiento> cm;
	
	private ArrayList<DTNotaSeguimiento> listaNotasSeguimiento;
	
	protected IRPCManejadorSolicitudesPresupuestosAsync manejadorSolicitudes;
    
	public FormSolicitud(ObservableManager xobsManager, Integer xmodo, String xcodigo, String xtipoDocumento){
		super();
		observableManagerSeleccion = new ObservableManager();
		observableManagerSeleccion.addObserver(this);
		observableNotas            = new ObservableManager();
		observableNotas.addObserver(this);
		observableManager          = xobsManager;
		modo                       = xmodo;
		codigo                     = xcodigo;
		tipoDocumento              = xtipoDocumento;
	    listaNotasSeguimiento = new ArrayList<DTNotaSeguimiento>();
		
		manejadorSolicitudes = GWT.create(IRPCManejadorSolicitudesPresupuestos.class);
		createComponents();
		initEvents();
		if ((modo == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {		    
			cargarPantalla(codigo, tipoDocumento);         	
			cargarListaNotas(codigo, tipoDocumento);
		}	                
	}		

	private void cargarListaNotas(String codigoSolicitud, String tipoDocumento) {
		manejadorSolicitudes.obtenerNotasDeSolicitud(codigoSolicitud, tipoDocumento, new AsyncCallback<List<DTNotaSeguimiento>>(
				
				) {
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onSuccess(List<DTNotaSeguimiento> result) {
						listaNotasSeguimiento = (ArrayList<DTNotaSeguimiento>) result;
						cargarGrilla();
					}
		});
	}

	private void cargarPantalla(String codigo, String tipoDocumento) {
       manejadorSolicitudes.obtenerPorCodigo(codigo,  tipoDocumento, new AsyncCallback<DTSolicitudPresupuesto>() {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onSuccess(DTSolicitudPresupuesto result) {
			cargarPantallaConObjeto(result);			
		}
	});
		
	}

	protected void cargarPantallaConObjeto(DTSolicitudPresupuesto result) {
		this.txtCodigo.setValue(result.getCodigo());
		this.dtfFechaIngreso.setValue(result.getFecha());		
		this.seleccionCliente.txtCodigo.setValue(result.getCliente().getCodigo());
		this.txtNombreCliente.setValue(result.getCliente().getNombre());
		this.seleccionEdificio.txtCodigo.setValue(result.getEdificio().getCodigo());
		this.txtNombreEdificio.setValue(result.getEdificio().getNombre());
		this.txtDireccionEdificio.setValue(result.getEdificio().getDireccion());
		this.seleccionUsuario.txtCodigo.setValue(result.getUsuarioAsignado().getId());
		this.txtNombreUsuario.setValue((result.getUsuarioAsignado().getNombre() == null ? "" : result.getUsuarioAsignado().getNombre()) + " " + (result.getUsuarioAsignado().getApellido() == null ? "" : result.getUsuarioAsignado().getApellido()));				
		this.txtDetalles.setValue(result.getDetalles());
		
		switch (result.getEstado()) {
		case 1 :
			this.txtEstado.setValue("Pendiente");
			break;
		case 2 :
			this.txtEstado.setValue("Presupuestada");
			break;
		case 3 :
			this.txtEstado.setValue("Modificado");
			break;
		}
		

		
		//this.txtUsuarioAsignado.setValue(result.getUsuarioAsignado().getId());		
	}

	private void initEvents() {
       btnConfirmar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		   if (modo == Ctes.K_MODO_MODIFICACION) {			   
			   modificarSolicitud();
		   }
		   else if ( modo == Ctes.K_MODO_ALTA) {
			   agregarSolicitud();
		   }			   
		   else if (modo == Ctes.K_MODO_CONSULTA) {
			   cerrarme();
		   }
	    }
	   });
       
       
       btnCancelar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		   cerrarme();			
		}
	});
       
       
       
       /*btnNuevaNota.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		   FormNotaSeguimiento form = new FormNotaSeguimiento(observableNotas,1, "0");
		   form.show();		   			
		}
	});*/
       
       btnAgregar.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
		   modoNotaActual = Ctes.K_MODO_ALTA;
		   FormNotaSeguimiento form = new FormNotaSeguimiento(observableNotas, Ctes.K_MODO_ALTA, null);
		   form.show();				   
		}
	});
       
        
      btnEliminar.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			if (!(grillaSeguimiento.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe seleccionar al menos una nota para eliminar");
				 box.show();
		   }
		   else {
			  eliminarNotas(grillaSeguimiento.getSelectionModel().getSelectedItems());   
		   }				
		}
	});
      
      btnModificar.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			if (!(grillaSeguimiento.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe seleccionar al menos una nota para poder modificarla");
				 box.show();
		   }
		   else {
			  modificarNota(grillaSeguimiento.getSelectionModel().getSelectedItem());   
		   }			
		}
	});
      
      
	}
	
	private void eliminarNotas(List<DTNotaSeguimiento> selectedItems) {
	 for (DTNotaSeguimiento nota : selectedItems) {
	   	   listaNotasSeguimiento.remove(nota);
	      }
	      renumerarNotas();	   
		  cargarGrilla();
	}
	
	private void modificarNota(DTNotaSeguimiento nota) {
		modoNotaActual = Ctes.K_MODO_MODIFICACION;
		FormNotaSeguimiento form = new FormNotaSeguimiento(observableNotas, Ctes.K_MODO_MODIFICACION, nota);
		form.show();
	}
	
	private void modificarSolicitud() {
       manejadorSolicitudes.modificar(txtCodigo.getValue(), Ctes.K_TDOC_SOLICITUD, dtfFechaIngreso.getValue(), seleccionUsuario.txtCodigo.getValue(), 
                seleccionCliente.txtCodigo.getValue(), seleccionEdificio.txtCodigo.getValue(), txtDetalles.getValue(),
                1 /*Pendiente*/, dtfFechaDeSeguimiento.getValue(),listaNotasSeguimiento,null, null,null, null, null, null, null, null, null, null, null,null, new AsyncCallback<Void>() {

					@Override
					public void onFailure(Throwable caught) {
						MessageBox box = new MessageBox("Error");												    												    												    
					     box.setMessage("Se produjo un error al intentar ingresar la solicitud: " + caught.getMessage());
						 box.show();									
					}

					@Override
					public void onSuccess(Void result) {
						MessageBox box = new MessageBox("Informacion");												    												    												    
					    box.setMessage("Se modifico correctamente la solicitud " + txtCodigo.getValue());
						box.show();
						cerrarme();						
					}
				});		
	}
	
	
	private void agregarSolicitud(){
		manejadorSolicitudes.agregar(txtCodigo.getValue(), Ctes.K_TDOC_SOLICITUD, dtfFechaIngreso.getValue(), seleccionUsuario.txtCodigo.getValue(), 
                seleccionCliente.txtCodigo.getValue(), seleccionEdificio.txtCodigo.getValue(), txtDetalles.getValue(),
                1 /*Pendiente*/, dtfFechaDeSeguimiento.getValue(),listaNotasSeguimiento,null,  "-1", null,null, null, null, null, null, null, null, null, null, null, null, null, null, new AsyncCallback<Void>() {

					@Override
					public void onFailure(
							Throwable caught) {
						 MessageBox box = new MessageBox("Error");												    												    												    
					     box.setMessage("Se produjo un error al intentar ingresar la solicitud: " + caught.getMessage());
						 box.show();													
					}

					@Override
					public void onSuccess(Void result) {
						MessageBox box = new MessageBox("Informacion");												    												    												    
					    box.setMessage("Se ingreso correctamente la solicitud " + txtCodigo.getValue());
						box.show();
						cerrarme();																
					}											
				});		
}
		
	
	
	private void createComponents() {
		this.setMaximizable(true);
        this.setModal(true);
		
        this.setHeadingText("Ingreso de solicitud de presupuesto");
    
        this.setSize("700px", "600px");
        
        tabPanel = new TabPanel();
        tabPanel.setSize("100%", "100%");
		   
		layout = new BorderLayoutContainer();
		   
		this.add(tabPanel);
		
		tabPanel.add(layout, "General");		  
		
		VerticalPanel panelInferior = new VerticalPanel();
		panelInferior.setSize("100%", "100%");
		
		HorizontalPanel contenedor = new HorizontalPanel();
		
		VerticalPanel contenedorIzquierdo = new VerticalPanel();
			
		txtCodigo = new TextField();	   
		txtCodigo.setValue("0");
		
		if ((this.modo == Ctes.K_MODO_MODIFICACION) || (this.modo == Ctes.K_MODO_CONSULTA)) {
		      txtCodigo.setReadOnly(true);
		      txtCodigo.setEnabled(false);
		   }	  
		   else {
			   txtCodigo.setReadOnly(false);
			   txtCodigo.setEnabled(true);  
			   cargarProximoCorrelativo();
	    }
		
		dtfFechaIngreso = new DateField();
		dtfFechaIngreso.setValue(new Date());
		dtfFechaIngreso.setPropertyEditor(new DateTimePropertyEditor("dd/MM/yyyy"));
		
		VerticalLayoutContainer vlcCliente = new VerticalLayoutContainer();
		
		fsCliente = new FieldSet();
        fsCliente.setHeadingText("Cliente");
        fsCliente.setCollapsible(true);
        fsCliente.setSize("310px", "100px");
                                
        txtNombreCliente = new TextField();
        txtNombreCliente.setReadOnly(true);
                
        seleccionCliente = new SeleccionObjeto(observableManagerSeleccion, 1);        
        vlcCliente.add(new FieldLabel(seleccionCliente, "Codigo"));
        vlcCliente.add(new FieldLabel(txtNombreCliente, "Nombre"));
        
        fsCliente.add(vlcCliente);
     
        contenedorIzquierdo.add(new FieldLabel(dtfFechaIngreso, "Fecha"));
		contenedorIzquierdo.add(new FieldLabel(txtCodigo, "Codigo"));
		contenedorIzquierdo.add(fsCliente);
		
		dtfFechaDeSeguimiento = new DateField();
        dtfFechaDeSeguimiento.setPropertyEditor(new DateTimePropertyEditor("dd/MM/yyyy"));
        dtfFechaDeSeguimiento.setReadOnly(true);
        
        HorizontalPanel hpSeguimiento = new HorizontalPanel();
        
        hpSeguimiento.add(new FieldLabel(dtfFechaDeSeguimiento, "Seguimiento"));
		
		contenedorIzquierdo.add(hpSeguimiento);
						
		VerticalPanel contenedorDerecho = new VerticalPanel();				
		
        VerticalLayoutContainer vlcUsuario = new VerticalLayoutContainer();
		        
		fsUsuario = new FieldSet();
		fsUsuario.setHeadingText("Asignado a:");
		fsUsuario.setCollapsible(true);
		fsUsuario.setSize("310px", "90px");
                                
        txtNombreUsuario = new TextField();
        txtNombreUsuario.setReadOnly(true);
                
        seleccionUsuario = new SeleccionObjeto(observableManagerSeleccion, 4);        
        vlcUsuario.add(new FieldLabel(seleccionUsuario, "Codigo"));
        vlcUsuario.add(new FieldLabel(txtNombreUsuario, "Nombre"));
        
        fsUsuario.add(vlcUsuario);
		
		VerticalLayoutContainer vlcEdificio = new VerticalLayoutContainer();
		
		fsEdificio = new FieldSet();
		fsEdificio.setHeadingText("Edificio");
		fsEdificio.setCollapsible(true);
		fsEdificio.setSize("310px", "110px");
        		
        seleccionEdificio = new SeleccionObjeto(observableManagerSeleccion, 2);
        txtNombreEdificio = new TextField();
        txtNombreEdificio.setReadOnly(true);
        txtDireccionEdificio = new TextField();
        txtDireccionEdificio.setReadOnly(true);
		        
        vlcEdificio.add(new FieldLabel(seleccionEdificio, "Codigo"));
        vlcEdificio.add(new FieldLabel(txtNombreEdificio, "Nombre"));
        vlcEdificio.add(new FieldLabel(txtDireccionEdificio, "Direccion"));
                
        fsEdificio.add(vlcEdificio);
        
        txtEstado = new TextField();        
                
        txtEstado.setValue("Pendiente");               
        
		contenedorDerecho.add(new FieldLabel(txtEstado, "Estado"));
        contenedorDerecho.add(fsUsuario);		
		contenedorDerecho.add(fsEdificio);						
								
		//contenedorDerecho.add(hpSeguimiento);
		
		contenedor.add(contenedorIzquierdo);
		contenedor.add(contenedorDerecho);
		txtDetalles = new TextArea();
		txtDetalles.setSize("680px", "180px");
		
		
		lblDetalles = new Label();
		lblDetalles.setText("Detalles:");
		
		panelInferior.add(lblDetalles);
		panelInferior.add(txtDetalles);	
		
		/*
		if ( this.modo == Ctes.K_MODO_MODIFICACION ) {
		      txtCodigo.setReadOnly(true);
		      txtCodigo.setEnabled(false);
		}	  
		else {
		   txtCodigo.setReadOnly(false);
		   txtCodigo.setEnabled(true);  
		   cargarProximoCorrelativo();
		}
		 */  	 						
					
		layout.setNorthWidget(contenedor, new BorderLayoutData(200));
		layout.setSouthWidget(panelInferior, new BorderLayoutData(200));
		  
		  // PESTA�A SEGUIMEINTO
		  
		  layoutSeguimiento = new BorderLayoutContainer();		  
  		  
		  Toolbar toolbar = new Toolbar();

	       toolbar.setWidth("100%");
		       
	       btnAgregar = new ToolbarButton();
			
		   btnAgregar.setText("Agregar Nota");
		   
		   btnModificar = new ToolbarButton();
		   
		   btnModificar.setText("Modificar Nota");
		   
		   btnEliminar= new ToolbarButton();
			
		   btnEliminar.setText("Eliminar Nota");
			
		   toolbar.addButton(btnAgregar);
		   toolbar.addButton(btnModificar);
		   toolbar.addButton(btnEliminar);
			
		   toolbar.addFill();								   			
		   	   	   
		   VerticalPanel vp = new VerticalPanel();
		   vp.setWidth("100%");
							   
		   vp.add(toolbar);		
		  		  	  
		  layoutSeguimiento.setNorthWidget(vp, new BorderLayoutData(40));
		  
		  crearGrilla();
		  		  		  
		  layoutSeguimiento.setCenterWidget(grillaSeguimiento);
		  
		  tabPanel.add(layoutSeguimiento, "Seguimiento");
		  		  
		  // BOTONES FORM
		  btnConfirmar = new Button();	   
		  btnConfirmar.setText("Confirmar");
		  btnConfirmar.setSize("70px", "30px");
		  
		  btnCancelar = new Button();	   
		  btnCancelar.setText("Cancelar");
		  btnCancelar.setSize("70px", "30px");	  	
		  
		  this.addButton(btnConfirmar);
		  this.addButton(btnCancelar);		  		  
	}

	private void crearGrilla() {
		  ColumnConfig<DTNotaSeguimiento, String> notaCol  	                = new ColumnConfig<DTNotaSeguimiento, String>(props.descripcion()   , 100, "Nota");
		  ColumnConfig<DTNotaSeguimiento, Date>   fechaSeguimientoCol 	    = new ColumnConfig<DTNotaSeguimiento, Date>(props.fechaSeguimiento(), 100, "Fecha");
		  ColumnConfig<DTNotaSeguimiento, String> usuarioCol 	            = new ColumnConfig<DTNotaSeguimiento, String>(props.usuario(), 100, "Usuario");
		  		  	      	 
	      List<ColumnConfig<DTNotaSeguimiento, ?>> l = new ArrayList<ColumnConfig<DTNotaSeguimiento, ?>>();
	      l.add(notaCol);
	      fechaSeguimientoCol.setCell(new com.google.gwt.cell.client.DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));	      
	      l.add(fechaSeguimientoCol);
	      l.add(usuarioCol);
	      	      	      	      
	      cm = new ColumnModel<DTNotaSeguimiento>(l);
	 
	      store = new ListStore<DTNotaSeguimiento>(props.key());	      	     	      
	      
	      grillaSeguimiento = new Grid<DTNotaSeguimiento>(store, cm);
	      
	      grillaSeguimiento.getView().setAutoExpandColumn(notaCol);
	      grillaSeguimiento.getView().setStripeRows(true);
	      grillaSeguimiento.getView().setColumnLines(true);
	      grillaSeguimiento.setBorders(false);
	 
	      grillaSeguimiento.setColumnReordering(true);
	      grillaSeguimiento.setStateful(true);
	      grillaSeguimiento.setStateId("Grilla");
	      grillaSeguimiento.setSize("100%", "100%");	     			
	}

	private void cargarProximoCorrelativo() {
		manejadorCorrelativos.obtenerProximoCorrelativo(Ctes.K_CORR_SOL, new AsyncCallback<String>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}

			@Override
			public void onSuccess(String result) {
			   txtCodigo.setValue(result);
			}
		});		
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
       if(  changeInfo instanceof DTCliente ){  
		   seleccionCliente.txtCodigo.setValue(((DTCliente)changeInfo).getCodigo());
	       txtNombreCliente.setValue(((DTCliente)changeInfo).getNombre());
	       seleccionEdificio.setCodigoEntidadAux(((DTCliente)changeInfo).getCodigo());
	       seleccionEdificio.txtCodigo.setValue("");
	       txtNombreEdificio.setValue("");
	       txtDireccionEdificio.setValue("");
       }
       else if (changeInfo instanceof DTEdificio){
          seleccionEdificio.txtCodigo.setValue(((DTEdificio)changeInfo).getCodigo());
          txtNombreEdificio.setValue(((DTEdificio)changeInfo).getNombre());
          txtDireccionEdificio.setValue(((DTEdificio)changeInfo).getDireccion());
       }
       else if (changeInfo instanceof DTNotaSeguimiento) {
          if (modoNotaActual == Ctes.K_MODO_ALTA) {
    	     listaNotasSeguimiento.add(((DTNotaSeguimiento)changeInfo));
          }
          else if (modoNotaActual == Ctes.K_MODO_MODIFICACION) {
        	 modificarDatosNota((DTNotaSeguimiento) changeInfo); 
          }
          renumerarNotas();
          cargarGrilla();
       }
       else if (changeInfo instanceof DTUsuario) {
    	   seleccionUsuario.txtCodigo.setValue(((DTUsuario) changeInfo).getId());
    	   
    	   String nombre   = ((DTUsuario) changeInfo).getNombre();
    	   String apellido = ((DTUsuario) changeInfo).getApellido();
    	       	       	  
    	   txtNombreUsuario.setValue((nombre == null? "" : nombre) + " " + (apellido == null? "" : apellido));    	   
       }
	}
	
	private void modificarDatosNota(DTNotaSeguimiento changeInfo) {
	    for (DTNotaSeguimiento unaNota : listaNotasSeguimiento) {
	    	if (unaNota.getNumeroNotaSeguimiento() == ((DTNotaSeguimiento) changeInfo).getNumeroNotaSeguimiento()) {
	    		unaNota.setDescripcion(((DTNotaSeguimiento) changeInfo).getDescripcion());
	    		unaNota.setSituacion(((DTNotaSeguimiento) changeInfo).getSituacion());
	    		unaNota.setFechaSeguimiento(((DTNotaSeguimiento) changeInfo).getFechaSeguimiento());
	    		break;
	    	}
	    }		
	}

	private void renumerarNotas() {
		int j = 1;
		for (int i = 0; i < listaNotasSeguimiento.size(); i ++) { 
		   this.listaNotasSeguimiento.get(i).setNumeroNotaSeguimiento(j);
		   j ++;		   
		}			
	}

	private void cargarGrilla(){
		grillaSeguimiento.getStore().clear();
		this.grillaSeguimiento.mask("Cargando...");
		store.addAll(listaNotasSeguimiento);
        grillaSeguimiento.reconfigure(store, cm);	
        grillaSeguimiento.unmask();				
	}
	
	public void cerrarme(){		
		this.hide();
		observableManager.notify(observableManager, null);		
	}
}
