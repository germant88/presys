package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.EdificioProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorEdificios;
import com.sistemas.presys.client.rpc.IRPCManejadorEdificiosAsync;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMEdificios extends FormABMGenerico {

	private static final EdificioProperties props = GWT.create(EdificioProperties.class);
	
	protected IRPCManejadorEdificiosAsync manejadorEdificios;
	
	public FormABMEdificios(){
		super();		
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Edificios");
	}
	
	@Override
	protected void crearManejadorRPC() {
		manejadorEdificios = GWT.create(IRPCManejadorEdificios.class);
	}
	
	
	@Override
	protected void crearGrilla(){	      
		  ColumnConfig<DTEdificio, String> codigoCol 	    = new ColumnConfig<DTEdificio, String>(props.codigo()   , 100, "Codigo");
		  ColumnConfig<DTEdificio, String> nombreCol 	    = new ColumnConfig<DTEdificio, String>(props.nombre()   , 100, "Nombre");
		  ColumnConfig<DTEdificio, String> direccionCol     = new ColumnConfig<DTEdificio, String>(props.direccion(), 100, "Direccion");
		  	      
	 
	      List<ColumnConfig<DTEdificio, ?>> l = new ArrayList<ColumnConfig<DTEdificio, ?>>();
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(direccionCol);
	      	      	      
	      cm = new ColumnModel<DTEdificio>(l);
	 
	      store = new ListStore<DTEdificio>(props.key());	      	     	      
	      
	      grilla = new Grid<DTEdificio>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	     
	}
	
	
	@Override
	protected void ejecutarAgregar(){
		FormEdificio form = new FormEdificio(observableManager, Ctes.K_MODO_ALTA, null);			  
		form.show();
	}
	
	
	@Override
	protected void cargarGrilla(){
		grilla.getStore().clear();
		this.grilla.mask("Cargarndo edificios...");
		manejadorEdificios.obtenerEdificios(new  AsyncCallback<ArrayList<DTEdificio>>() {			               
			@SuppressWarnings("unchecked")
			@Override
			public void onSuccess(ArrayList<DTEdificio> result) {
				 store.addAll(result);
                 grilla.reconfigure(store, cm);	
                 grilla.unmask();
			}
			
			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}
		});			
	}

	@Override
	protected void eliminarSeleccionado(){
		ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "�Realmente desea eliminar el edificio?");
	    box.addHideHandler(hadlerEliminarEdificio);	
	    ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
	    box.show();
	}
	
	
	 final HideHandler hadlerEliminarEdificio = new HideHandler() {
	     @Override
	     public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarEdificioSeleccionado();
	        }	        
	     }
	 };
	 
	 private void eliminarEdificioSeleccionado(){
	    DTEdificio edificioSeleccionado;
		   
	    edificioSeleccionado = (DTEdificio) grilla.getSelectionModel().getSelectedItem();
	   	    
	    eliminarEdificio(edificioSeleccionado);            	    
	 }
	 
	 private void eliminarEdificio(DTEdificio edificioSeleccionado) {
			manejadorEdificios.eliminarEdificio(edificioSeleccionado.getCodigo(), new AsyncCallback() {

				@Override
				public void onSuccess(Object result) {
			       cargarGrilla();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}			
			}); 
     }

	 public void errorDebeSeleccionarUnElemento() {
			/*final Dialog simple = new Dialog();
		    simple.setHeadingText("Atencion");
		    simple.setPredefinedButtons(PredefinedButton.OK);
		    simple.setBodyStyleName("pad-text");
		    simple.add(new Label("Debe seleccionar un segmento en la grilla"));
		    simple.getBody().addClassName("pad-text");
		    simple.setHideOnButtonClick(true);
		    simple.setWidth(300);
		   
		   simple.show();
		   */
		   
			MessageBox box = new MessageBox("Atencion", "Debe seleccionar un edificio en la grilla");
		    box.show();
		}
	 
	 @Override
	 protected void modificarSeleccionado(){
		 DTEdificio edificioSeleccionado;
		   
		 edificioSeleccionado = (DTEdificio) grilla.getSelectionModel().getSelectedItem();
		   
		   if (edificioSeleccionado != null) {
		      modificarEdificio(edificioSeleccionado);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	 }

	private void modificarEdificio(DTEdificio edificioSeleccionado) {
		FormEdificio form = new FormEdificio(observableManager, Ctes.K_MODO_MODIFICACION, edificioSeleccionado.getCodigo());			  
	    form.show();
	}
	
	@Override
	protected void buscar() {
		 Integer buscarPor;
		   if (this.rbtnFiltrarCodigo.getValue() == true) {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargarndo edificios...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorEdificios.buscarEdificio(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTEdificio>>() {
			
			@Override
			public void onSuccess(ArrayList<DTEdificio> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();
	               ponerFocoEnFiltro();
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}
}
