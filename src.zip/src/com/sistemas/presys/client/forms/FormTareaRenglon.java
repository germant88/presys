package com.sistemas.presys.client.forms;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.gwtext.client.widgets.form.Label;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorTareasAsync;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.datatypes.DTTareaRenglon;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormTareaRenglon extends Window implements IObserver{
    protected IRPCManejadorTareasAsync manejadorTareas;
	private SeleccionObjeto seleccionTarea;
	protected FieldSet fsTarea;
    private DTTarea tareaSeleccionada;    
	private ObservableManager observableManager;
	private ObservableManager observableManagerSeleccion;	
    private TextField txtNombre;
	private TextArea  txtDescripcion;
	
	private Integer modo;
    private Integer codigo;

    private Button btnAceptar;
	private Button btnCancelar;
	private BorderLayoutContainer layout;
	private ContentPanel panelCentral;	
    private VerticalLayoutContainer vlc;
    
    private DTTareaRenglon tareaRenglon;
	
	public FormTareaRenglon(ObservableManager xobsManager, Integer xmodo,
			         DTTareaRenglon xtareaRenglon) {
		super();
		tareaSeleccionada = null;
	   	observableManagerSeleccion = new ObservableManager();
		observableManagerSeleccion.addObserver(this);		
		observableManager          = xobsManager;
		modo                       = xmodo;
		tareaRenglon                      = xtareaRenglon;					    	    
    	CreateComponents();
    	initEvents();
    	if (modo == Ctes.K_MODO_MODIFICACION) {
    		cargarPantallaConTareaRenglon();
    	}   		
	}

	private void cargarPantallaConTareaRenglon() {
		this.seleccionTarea.txtCodigo.setValue(tareaRenglon.getTareaXDefecto().getCodigo());		
		this.txtNombre.setValue(tareaRenglon.getTareaXDefecto().getNombre());
		tareaSeleccionada = tareaRenglon.getTareaXDefecto();
		this.txtDescripcion.setValue(tareaRenglon.getDescripcion());	
	}

	private void initEvents() {
       btnAceptar.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
				if ((tareaSeleccionada == null) || (txtDescripcion.getValue() == null)) {
	        	     MessageBox box = new MessageBox("Atencion");												    												    												    
				     box.setMessage("Debe ingresar los datos necesarios para agregar la tarea");
					 box.show();
	           	}
	           else {						
				if (modo == Ctes.K_MODO_MODIFICACION) {
				    tareaRenglon.setDescripcion(txtDescripcion.getValue());					
				    tareaRenglon.setTareaXDefecto(tareaSeleccionada);				    				    
				    observableManager.notify(observableManager, tareaRenglon);
				}
				else {   
		        	DTTareaRenglon tareaRenglonNueva = new DTTareaRenglon();
		        	tareaRenglonNueva.setTareaXDefecto(tareaSeleccionada);		        	
		        	tareaRenglonNueva.setDescripcion(txtDescripcion.getValue());           	           			        	
		           	
		           	observableManager.notify(observableManager, tareaRenglonNueva);
				}
	           	cerrarme();	           	
	           }
			}
		});		
	}

	private void CreateComponents() {
		   this.setMaximizable(true);
		   this.setModal(true);		
		   this.setHeadingText("Ingreso de Tareas");		 
		   this.setSize("500px", "430px");	   	   	
		   		   			   
		   layout = new BorderLayoutContainer();
			   		   							   
		   panelCentral = new ContentPanel();	  
		   panelCentral.setSize("100%", "100%");    	
		   panelCentral.setHeaderVisible(false);
		   
		   VerticalLayoutContainer vlcTarea = new VerticalLayoutContainer();
			       
		   fsTarea = new FieldSet();
	       fsTarea.setHeadingText("Tarea");
	       fsTarea.setCollapsible(true);
	       fsTarea.setSize("310px", "120px");
	       fsTarea.setPosition(15, 10);
	       
	       txtNombre = new TextField();
	       txtNombre.setReadOnly(true);
	               
	       seleccionTarea = new SeleccionObjeto(observableManagerSeleccion, 5);        
	       vlcTarea.add(new FieldLabel(seleccionTarea, "Codigo"));
	       vlcTarea.add(new FieldLabel(txtNombre, "Nombre"));
	       
	       fsTarea.add(vlcTarea);	       	       	       
	       
	       Label lblDescripcion = new Label();
	       lblDescripcion.setText("Descripcion:");
	       lblDescripcion.setPosition(15,40);
	       
	       txtDescripcion = new TextArea();
		   txtDescripcion.setSize("450px", "100px");
		   txtDescripcion.setPosition(15, 50);
		   
		   vlc = new VerticalLayoutContainer();
		   vlc.setHeight("100%");
		   
		   vlc.add(fsTarea);		   
		   vlc.add(lblDescripcion);
		   vlc.add(txtDescripcion);
		   
		   panelCentral.add(vlc);
		   
		   layout.setCenterWidget(panelCentral);
		   		  
		   btnAceptar = new Button();	   
		   btnAceptar.setText("Aceptar");
		   btnAceptar.setSize("70px", "30px");
	  
		   btnCancelar = new Button();	   
		   btnCancelar.setText("Cancelar");
		   btnCancelar.setSize("70px", "30px");	  	
	  
		   this.add(layout);
		   this.addButton(btnAceptar);
		   this.addButton(btnCancelar); 
		
	}

	protected void cerrarme() {
		this.hide();
	}
	
	@Override
	public void update(Object theObserved, Object changeInfo) {
		  if (changeInfo instanceof DTTarea) {
	         seleccionTarea.txtCodigo.setValue(((DTTarea)changeInfo).getCodigo());
		     txtNombre.setValue(((DTTarea)changeInfo).getNombre());
		     txtDescripcion.setValue(((DTTarea) changeInfo).getDescripcion());
		     tareaSeleccionada = (DTTarea)changeInfo;
	      }			
	}	
}
