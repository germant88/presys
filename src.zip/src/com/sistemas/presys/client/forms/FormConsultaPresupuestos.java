package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.widgets.Button;
import com.gwtext.client.widgets.Component;
import com.gwtext.client.widgets.Toolbar;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.event.ButtonListener;
import com.gwtext.client.widgets.form.Label;
import com.gwtext.client.widgets.menu.Menu;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.form.CheckBox;
import com.sencha.gxt.widget.core.client.form.DateField;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.GridPresupuestosProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorConsultasPresupuestos;
import com.sistemas.presys.client.rpc.IRPCManejadorConsultasPresupuestosAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.utiles.Ctes;
import com.google.gwt.user.client.Cookies;

public class FormConsultaPresupuestos extends Window implements IObserver{
	
	private static final GridPresupuestosProperties props = GWT.create(GridPresupuestosProperties.class);
	
	private final IRPCManejadorConsultasPresupuestosAsync manejadorConsultasPresupuestos = GWT
			.create(IRPCManejadorConsultasPresupuestos.class);
	
	private ListStore<DTGridPresupuesto> store;
	private ColumnModel<DTGridPresupuesto> cm;
	private Grid<DTGridPresupuesto> grilla;
	
	protected BorderLayoutContainer layout;
	
	protected ToolbarButton btnBuscar;
	
	protected ToolbarButton btnTrazabilidad;
	
	protected ToolbarButton btnExportarPDF;
	
    protected TextField txtFiltroCodigo;
	protected DateField dtfFechaDesde;
	protected DateField dtfFechaHasta;
	
	protected VerticalPanel contenedorTipos;
	protected VerticalPanel contenedorEstados;
	protected VerticalPanel contenedorCliente;
	protected VerticalPanel contenedorProducto;
	protected VerticalPanel contenedorOtros;
	
	protected CheckBox chkSolicitud;
	
	protected CheckBox chkPresupuesto;
	
	protected CheckBox chkSoloPendientes;
	
    protected CheckBox chkSoloUsuarioActual;
	
	protected FieldSet fsCliente;
	
	protected TextField txtNombreCliente;
	  
	private SeleccionObjeto seleccionCliente;
	
	private SeleccionObjeto seleccionProducto;	
	
	protected ObservableManager observableManager;
	
	protected ObservableManager observableManagerSeleccion;
	
	protected ObservableManager observableManagerSeleccionCliente;
	
	protected ObservableManager observableManagerSeleccionProducto;
	
	protected Integer modo;
	
	public FormConsultaPresupuestos(ObservableManager xObservableManager, Integer xModo) {
		super();
		observableManagerSeleccionCliente = new ObservableManager();
		observableManagerSeleccionCliente.addObserver(this);
		observableManagerSeleccionProducto = new ObservableManager();
		observableManagerSeleccionProducto.addObserver(this);		
		observableManager = new ObservableManager();
		observableManager.addObserver(this);
		
		observableManagerSeleccion = xObservableManager;
		modo = xModo;
		
		createComponents();
		initEvents();
	}

	private void initEvents() {		
		btnTrazabilidad.addListener(new ButtonListener() {
			
			@Override
			public void onStateSave(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onStateRestore(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onShow(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onRender(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onHide(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onEnable(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onDisable(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onDestroy(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeStateRestore(Component component,
					JavaScriptObject state) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeShow(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeRender(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeHide(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeDestroy(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public void onToggle(Button button, boolean pressed) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMouseOver(Button button, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMouseOut(Button button, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuTriggerOver(Button button, Menu menu, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuTriggerOut(Button button, Menu menu, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuShow(Button button, Menu menu) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuHide(Button button, Menu menu) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onClick(Button button, EventObject e) {
               MostrarTrazabilidadDeDocumento();
			}
		});
		
		btnExportarPDF.addListener(new ButtonListener() {
			
			@Override
			public void onStateSave(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onStateRestore(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onShow(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onRender(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onHide(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onEnable(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onDisable(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onDestroy(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeStateRestore(Component component,
					JavaScriptObject state) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeShow(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeRender(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeHide(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeDestroy(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public void onToggle(Button button, boolean pressed) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMouseOver(Button button, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMouseOut(Button button, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuTriggerOver(Button button, Menu menu, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuTriggerOut(Button button, Menu menu, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuShow(Button button, Menu menu) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuHide(Button button, Menu menu) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onClick(Button button, EventObject e) {
               reportePresupuestoPDF();				
			}
		});
		
		btnBuscar.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(Button button, boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(Button button, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(Button button, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(Button button, Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(Button button, Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(Button button, EventObject e) {
	       buscarPresupuestos();					
		}
	});
      
      grilla.addCellDoubleClickHandler(new CellDoubleClickHandler() {
		
		@Override
		public void onCellClick(CellDoubleClickEvent event) {
           if (modo == Ctes.K_MODO_CONSULTA) {
              verPresupuestoOSolicitud();   
           }
           else if ((modo == Ctes.K_MODO_SELECCION_SOL_ORIGEN) || (modo == Ctes.K_MODO_CONSULTA_PRESUPUESTOS_PENDIENTES)) {
              seleccionarSolicitudOrigen();   
           }				          
		}
	});
			
	}

	protected void reportePresupuestoPDF() {
        Map<String, String> parametros = new HashMap();
        parametros.put("CodigoPresupuesto", grilla.getSelectionModel().getSelectedItem().getId());
		FormReportePendientes form = new FormReportePendientes(Ctes.K_REPORTE_PRESUPUESTO, parametros, Ctes.K_SUB_REPORTE_PRESUPUESTO);
		form.show();
	}

	protected void MostrarTrazabilidadDeDocumento() {
       FormTrazabilidad form = new FormTrazabilidad(this.grilla.getSelectionModel().getSelectedItem().getId(), this.grilla.getSelectionModel().getSelectedItem().getTipoDoc());
       form.show();		
	}

	protected void verPresupuestoOSolicitud() {				
		DTGridPresupuesto seleccionado;
		   
		seleccionado = grilla.getSelectionModel().getSelectedItem();
		   
		   if (seleccionado != null) {		      
			   verPresupuestoOSolicitudSeleccionada(seleccionado);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }			
	}	

	private void verPresupuestoOSolicitudSeleccionada(
			DTGridPresupuesto seleccionado) {
		if (seleccionado.getTipoDoc().equals(Ctes.K_TDOC_PRESUPUESTO)) {
	       FormPresupuesto form  = new FormPresupuesto(observableManager, Ctes.K_MODO_MODIFICACION, seleccionado.getId(), seleccionado.getTipoDoc());
	       form.show();
	    }
		else {
			FormSolicitud form = new FormSolicitud(observableManager, Ctes.K_MODO_MODIFICACION, seleccionado.getId(), seleccionado.getTipoDoc());			  
		    form.show();	
		}						
	}
	
	private void seleccionarSolicitudOrigen() {
		DTGridPresupuesto seleccionado;
		
		seleccionado = grilla.getSelectionModel().getSelectedItem();
		
		if (seleccionado != null) {
	       observableManagerSeleccion.notify(observableManagerSeleccion, seleccionado);
	       cerrarme();
		}
	}
	

	private void cerrarme() {
	   this.hide();	
	}

	protected void buscarPresupuestos() {
		grilla.getStore().clear();
		this.grilla.mask("Cargando...");

		if ((modo != Ctes.K_MODO_SELECCION_SOL_ORIGEN) && (modo != Ctes.K_MODO_CONSULTA_PRESUPUESTOS_PENDIENTES) ) {
			ArrayList<String> tiposDocumentos = new ArrayList<String>();
			
			if (chkSolicitud.getValue()) {
				tiposDocumentos.add(Ctes.K_TDOC_SOLICITUD);	
			}
			if (chkPresupuesto.getValue()) {
				tiposDocumentos.add(Ctes.K_TDOC_PRESUPUESTO);
			}
						            			
			ArrayList<Integer> estadoPendiente = new ArrayList<Integer>();
		    		    
			if (chkSoloPendientes.getValue()) {
				estadoPendiente.add(Ctes.K_ESTADO_SOLICITUD_PENDIENTE);	
			}
			
			manejadorConsultasPresupuestos.buscarPresupuestos(txtFiltroCodigo.getValue(), dtfFechaDesde.getValue(), dtfFechaHasta.getValue(), estadoPendiente, tiposDocumentos, seleccionCliente.txtCodigo.getValue(), null, seleccionProducto.txtCodigo.getValue(),  new AsyncCallback<ArrayList<DTGridPresupuesto>>() {
				
				@Override
				public void onSuccess(ArrayList<DTGridPresupuesto> result) {
					guardarFiltrosCookies();
					store.addAll(result);
	                grilla.reconfigure(store, cm);	
	                grilla.unmask();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					grilla.unmask();					
				}
			});
		}				
		else {
			    ArrayList<Integer> estadoPendiente = new ArrayList<Integer>();
			    estadoPendiente.add(Ctes.K_ESTADO_SOLICITUD_PENDIENTE);
             
			    ArrayList<String> tiposDocumentos = new ArrayList<String>();
				
			    if (modo == Ctes.K_MODO_CONSULTA_PRESUPUESTOS_PENDIENTES) {
					tiposDocumentos.add(Ctes.K_TDOC_PRESUPUESTO);
			    }
			    else {
			    	if (chkSolicitud.getValue()) {
						tiposDocumentos.add(Ctes.K_TDOC_SOLICITUD);	
					}
					
					if (chkPresupuesto.getValue()) {
						tiposDocumentos.add(Ctes.K_TDOC_PRESUPUESTO);
					}
			    }
			    // Se buscan solo las solicitudes pendientes, porque son las que se pueden presupuestar 
			    manejadorConsultasPresupuestos.buscarPresupuestos(txtFiltroCodigo.getValue(), dtfFechaDesde.getValue(), dtfFechaHasta.getValue(), estadoPendiente, tiposDocumentos, seleccionCliente.txtCodigo.getValue(), null, seleccionProducto.txtCodigo.getValue(),  new AsyncCallback<ArrayList<DTGridPresupuesto>>() {
				
				@Override
				public void onSuccess(ArrayList<DTGridPresupuesto> result) {
					guardarFiltrosCookies();
					store.addAll(result);
	                grilla.reconfigure(store, cm);	
	                grilla.unmask();	                
				}
				
				@Override
				public void onFailure(Throwable caught) {
					grilla.unmask();					
				}
			});
		}
	}

	private void createComponents() {
		this.setMaximizable(true);
        this.setModal(true);
		
        if (modo == Ctes.K_MODO_SELECCION_SOL_ORIGEN) {
           this.setHeadingText("Seleccion de solicitud origen");	
        }
        else {
           this.setHeadingText("Consulta de presupuestos");
        }
            
        this.setSize("800px", "600px");
		   
		layout = new BorderLayoutContainer();
		   
		this.add(layout);
					
		ContentPanel panelCabezal = new ContentPanel();
		panelCabezal.setHeaderVisible(false);
		panelCabezal.setWidth("100%");
		
		final TabPanel panelTabs = new TabPanel();
	    panelTabs.setWidth("786px");
		panelTabs.setHeight(100);
								    
        txtFiltroCodigo = new TextField();
        txtFiltroCodigo.setWidth("150px");
        
        HorizontalPanel contenedor = new HorizontalPanel();
		
		VerticalPanel panelIzq = new VerticalPanel();
		
		VerticalPanel panelCentral = new VerticalPanel();
		
		VerticalPanel panelDerecha = new VerticalPanel();
		
		panelIzq.add(new FieldLabel(txtFiltroCodigo, "C\u00f3digo"));        
        
        contenedor.add(panelIzq);
        contenedor.add(panelCentral);
        contenedor.add(panelDerecha);
        
        panelTabs.add(contenedor, "C\u00f3digo");
        
        dtfFechaDesde = new DateField();
        dtfFechaHasta = new DateField();
                       
        HorizontalPanel contenedorFecha = new HorizontalPanel();
		
		VerticalPanel panelIzqFecha = new VerticalPanel();
		
		VerticalPanel panelCentralFecha = new VerticalPanel();
		
		VerticalPanel panelDerechaFecha = new VerticalPanel();
						
		panelIzqFecha.add(new FieldLabel(dtfFechaDesde, "Desde"));
		panelIzqFecha.add(new FieldLabel(dtfFechaHasta, "Hasta"));
        
        contenedorFecha.add(panelIzqFecha);
        contenedorFecha.add(panelCentralFecha);
        contenedorFecha.add(panelDerechaFecha);
        
        panelTabs.add(contenedorFecha, "Fecha");
        
        if (modo != Ctes.K_MODO_CONSULTA_PRESUPUESTOS_PENDIENTES) {
	        contenedorTipos = new VerticalPanel();
	        contenedorTipos.setWidth("100%");
	        
	        chkSolicitud = new CheckBox();
	        chkSolicitud.setBoxLabel("Solicitud");
	        chkSolicitud.setValue(true);
	        
	                  
	        chkPresupuesto = new CheckBox();
	        chkPresupuesto.setBoxLabel("Presupuesto");
	        
	        
	        if (modo != Ctes.K_MODO_SELECCION_SOL_ORIGEN) {
	           chkPresupuesto.setValue(true);
	        }
	        else {
	        	chkPresupuesto.setValue(false);
	        }
	                
	        contenedorTipos.add(chkSolicitud);       
	        contenedorTipos.add(chkPresupuesto);
	        
	        panelTabs.add(contenedorTipos, "Tipos");
        }
        //HorizontalPanel hpToolbars = new HorizontalPanel();
        //hpToolbars.setWidth("100%");
        
        contenedorEstados = new VerticalPanel();
        contenedorEstados.setWidth("100%");
        
        chkSoloPendientes = new CheckBox();
        chkSoloPendientes.setBoxLabel("Solamente pendientes");
        chkSoloPendientes.setValue(true);
        
        contenedorEstados.add(chkSoloPendientes);
        
        if ((modo != Ctes.K_MODO_CONSULTA_PRESUPUESTOS_PENDIENTES) && (modo != Ctes.K_MODO_CONSULTA_PENDIENTES)) {
           panelTabs.add(contenedorEstados, "Estado");           	
        }        
        
        VerticalLayoutContainer vlcCliente = new VerticalLayoutContainer();        
                                                
        seleccionCliente = new SeleccionObjeto(observableManagerSeleccionCliente, 1);
                
    	seleccionCliente.txtCodigo.setReadOnly(false);
    	seleccionCliente.btnBuscar.setEnabled(true);
                        
        vlcCliente.add(new FieldLabel(seleccionCliente, "Codigo"));              
        
        contenedorCliente = new VerticalPanel();
        contenedorCliente.setWidth("100%");
        
        contenedorCliente.add(vlcCliente);
        
        panelTabs.add(contenedorCliente, "Ciente");
        
        
        VerticalLayoutContainer vlcProducto = new VerticalLayoutContainer();
        
                                                
        seleccionProducto = new SeleccionObjeto(observableManagerSeleccionProducto, 3);
                
        seleccionProducto.txtCodigo.setReadOnly(false);
        seleccionProducto.btnBuscar.setEnabled(true);
                        
        vlcProducto.add(new FieldLabel(seleccionProducto, "Codigo"));        
        
        
        contenedorProducto = new VerticalPanel();
        contenedorProducto.setWidth("100%");
        
        contenedorProducto.add(vlcProducto);
        
        panelTabs.add(contenedorProducto, "Producto");
                        
        chkSoloUsuarioActual = new CheckBox();
        chkSoloUsuarioActual.setBoxLabel("Mostrar solo de usuario actual");              
                                                       
        contenedorOtros = new VerticalPanel();
        contenedorOtros.setWidth("100%");
        
        contenedorOtros.add(chkSoloUsuarioActual);
        
        panelTabs.add(contenedorOtros, "Otros");
                        
        Toolbar toolbar = new Toolbar();

		toolbar.setWidth("100%");
		
		btnBuscar = new ToolbarButton();
		
		btnBuscar.setText("Buscar");
		
		toolbar.addButton(btnBuscar);
		
		toolbar.addFill();
		
		btnTrazabilidad = new ToolbarButton();
		btnTrazabilidad.setText("Trazabilidad");
		
		btnExportarPDF = new ToolbarButton();
		btnExportarPDF.setText("PDF");
		
	   toolbar.addButton(btnExportarPDF);
	   toolbar.addButton(btnTrazabilidad);				
				
	   VerticalPanel vp = new VerticalPanel();
	   vp.setWidth("100%");
				
	   vp.add(panelTabs);
	   vp.add(toolbar);
		
	   panelCabezal.setWidget(vp);				
		 
	   layout.setNorthWidget(panelCabezal, new BorderLayoutData(130));
		
		// CENTER	   
	   ContentPanel contenedorCentral = new ContentPanel();
	   contenedorCentral.setHeaderVisible(false);
	   createGrilla();
	   contenedorCentral.add(grilla);
	   layout.setCenterWidget(contenedorCentral);
	   
	   //COOKIES
	   cargarFiltrosCookies();
	}	
	
	private void cargarFiltrosCookies() {
		String soloPendientes = "";
		soloPendientes = Cookies.getCookie(Ctes.K_COOKIE_FILTRO_ESTADO);
		
		if ((soloPendientes == null) || (soloPendientes.trim().equals("") == true)) {
			soloPendientes = "S";
		}
		
		if (soloPendientes.equals("S")) {
			chkSoloPendientes.setValue(true);
		}
		else
		{
			chkSoloPendientes.setValue(false);
		}		
	}
	
	private void guardarFiltrosCookies(){
		if (chkSoloPendientes.getValue()) {
			Cookies.setCookie(Ctes.K_COOKIE_FILTRO_ESTADO, "S");
		}
		else {
			Cookies.setCookie(Ctes.K_COOKIE_FILTRO_ESTADO, "N");
		}
			
	}
	
	
	private void createGrilla() {
		ColumnConfig<DTGridPresupuesto, String> idCol                   = new ColumnConfig<DTGridPresupuesto, String>(props.id(), 100, "Codigo");
		ColumnConfig<DTGridPresupuesto, Date>   fechaCol                = new ColumnConfig<DTGridPresupuesto, Date>  (props.fecha(), 100, "Fecha");
		ColumnConfig<DTGridPresupuesto, String> nombreClienteCol        = new ColumnConfig<DTGridPresupuesto, String>(props.nombreCliente(), 100, "Cliente");
		ColumnConfig<DTGridPresupuesto, String> nombreEdificioCol       = new ColumnConfig<DTGridPresupuesto, String>(props.nombreEdificio(), 100, "Edificio");
	    ColumnConfig<DTGridPresupuesto, String> estadoCol               = new ColumnConfig<DTGridPresupuesto, String>(props.nombreEstado(), 100, "Estado");
	    ColumnConfig<DTGridPresupuesto, Date>   seguimientoCol          = new ColumnConfig<DTGridPresupuesto, Date>  (props.seguimiento(), 100, "Seguimiento");
	    ColumnConfig<DTGridPresupuesto, String> nombreTipoDocumentoCol  = new ColumnConfig<DTGridPresupuesto, String>  (props.nombreTipoDocumento(), 100, "Tipo");
	 
      List<ColumnConfig<DTGridPresupuesto, ?>> l = new ArrayList<ColumnConfig<DTGridPresupuesto, ?>>();
      l.add(idCol);
      fechaCol.setCell(new com.google.gwt.cell.client.DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));
      l.add(fechaCol);
      l.add(nombreClienteCol);
      l.add(nombreEdificioCol);      
      l.add(nombreTipoDocumentoCol);       
      
      estadoCol.setCell(new AbstractCell<String>() {

		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context,
				String value, SafeHtmlBuilder sb) {
			  String style = "style='color: " + (value.equals("Pendiente") ? "blue" : (value.equals("Presupuestada") ? "green" : (value.equals("Modificado") ? "orange" : (value.equals("Ganado") ? "green" : (value.equals("Perdido") ? "red" : (value.equals("Cancelado") ? "red" : "red")))))) + "'";	  
	          sb.appendHtmlConstant("<span " + style + ">" + value + "</span>");			
		}
	});
      
      l.add(estadoCol);
      seguimientoCol.setCell(new com.google.gwt.cell.client.DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));      
      l.add(seguimientoCol);
           	      	      
      cm = new ColumnModel<DTGridPresupuesto>(l);
 
      store = new ListStore<DTGridPresupuesto>(props.key());	      	     	      
      
      grilla = new Grid<DTGridPresupuesto>(store, cm);
      
      grilla.getView().setStripeRows(true);
      grilla.getView().setColumnLines(true);
      grilla.getView().setAutoExpandColumn(nombreClienteCol);
      
      
      grilla.setBorders(false);
	      
      grilla.setColumnReordering(true);
      grilla.setStateful(true);
      grilla.setStateId("Grilla");
      grilla.setSize("100%", "100%");	      		
}
	
	public void errorDebeSeleccionarUnElemento() {
		final Dialog simple = new Dialog();
	    simple.setHeadingText("Atencion");
	    simple.setPredefinedButtons(PredefinedButton.OK);
	    simple.setBodyStyleName("pad-text");
	    simple.add(new Label("Debe seleccionar un renglon en la grilla"));
	    simple.getBody().addClassName("pad-text");
	    simple.setHideOnButtonClick(true);
	    simple.setWidth(300);
	   
	   simple.show();
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
		if(  changeInfo instanceof DTCliente ){  
		      seleccionCliente.txtCodigo.setValue(((DTCliente)changeInfo).getCodigo());
		  }
		else if ( changeInfo instanceof DTProducto) {
			seleccionProducto.txtCodigo.setValue(((DTProducto)changeInfo).getCodigo());
		}
		else {
		   this.buscarPresupuestos();
		}
	}
}
