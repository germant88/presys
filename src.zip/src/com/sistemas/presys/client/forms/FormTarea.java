package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorTareas;
import com.sistemas.presys.client.rpc.IRPCManejadorTareasAsync;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.excepciones.LogicException;

public class FormTarea extends FormEntidadGenerico{
    protected IRPCManejadorTareasAsync manejadorTareas;
	private TextField txtNombre;
	private TextArea  txtDescripcion;
	
	public FormTarea(ObservableManager xobsManager, Integer xmodo,
			         String xcodigo) {
		super(xobsManager, xmodo, xcodigo);		
	}
	
	@Override
	protected void crearManejadorRPC() {
		 manejadorTareas = GWT.create(IRPCManejadorTareas.class);
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Tarea");		
	}	
	
	@Override
	protected String  obtenerCodigoCorrelativo(){
		return "";
	}
	
	@Override
	protected void createComponents(){
		super.createComponents();
						
		txtNombre = new TextField();
	    vlc.add(new FieldLabel(txtNombre, "Nombre"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
	    
	    txtDescripcion = new TextArea();
	    vlc.add(new FieldLabel(txtDescripcion, "Descripcion"),new VerticalLayoutData(450, 150, new Margins(30,1,1,15)));
	    						
		txtNombre.focus();
		this.setFocusWidget(txtNombre);
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	protected void agregarEntidad(){
		manejadorTareas.agregarTarea(txtCodigo.getValue(), txtNombre.getValue(), txtDescripcion.getValue(), new AsyncCallback() {

			@Override
			public void onFailure(Throwable caught) {
				 MessageBox box = new MessageBox("Error");												    												    												    
			     box.setMessage("Se produjo un error al intentar agregar la tarea: " + caught.getMessage());
				 box.show();					
			}

			@Override
			public void onSuccess(Object result) {
		        cerrarme();					
			}
		});	
	}
	
	@Override
	protected void modificarEntidad() {
		manejadorTareas.modificarTarea(txtCodigo.getValue() , txtNombre.getValue(), txtDescripcion.getValue(), new AsyncCallback<Void>() {

					@Override
					public void onFailure(
							Throwable caught) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onSuccess(Void result) {
						cerrarme();  						
					}
				});
    }
	
	@Override
	protected void cargarPantalla(String xcodigo) {
		manejadorTareas.obtenerPorCodigo(xcodigo, new AsyncCallback<DTTarea>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(DTTarea result) {
				cargarPantallaConObjeto(result);
				
			}
		});     			
    }

	@Override
    protected void cargarPantallaConObjeto(Object entidad) {
       DTTarea tarea = (DTTarea) entidad;
		
	   this.txtCodigo.setValue(String.valueOf(tarea.getCodigo()));
 	   this.txtNombre.setValue(tarea.getNombre() != null ? tarea.getNombre() : "");
 	   this.txtDescripcion.setValue(tarea.getDescripcion() != null ? tarea.getDescripcion() : "");        	    	   	   
    }
}
