package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.sencha.gxt.core.client.util.Format;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.ToggleGroup;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Dialog.PredefinedButton;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.form.Radio;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sencha.gxt.widget.core.client.info.Info;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.ClienteProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorClientes;
import com.sistemas.presys.client.rpc.IRPCManejadorClientesAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMClientes extends Window implements IObserver {

	private static final ClienteProperties props = GWT.create(ClienteProperties.class);
	private final IRPCManejadorClientesAsync manejadorClientes = GWT
				.create(IRPCManejadorClientes.class);
	private Button btnAgregar;
	private Button btnModificar;
	private Button btnEliminar;
	private Button btnBuscar;
	private Radio rbtnFiltrarCodigo;
	private Radio rbtnFiltrarNombre;
	private ToggleGroup tgFiltrarPor;
	private TextField txtFiltro;
	
	ListStore<DTCliente> store;
	ColumnModel<DTCliente> cm;
		
	private Grid<DTCliente> grilla;
	
	ObservableManager observableManager;
	
	public FormABMClientes() {
	   super();
	   observableManager = new ObservableManager();
	   observableManager.addObserver(this);			   
	   createComponents();	   
	   events();
	   this.setFocusWidget(txtFiltro);
	   cargarGrilla();	   
	}
	
	public void ponerFocoEnFiltro(){
		this.setFocusWidget(txtFiltro);		
		txtFiltro.setCursorPos(txtFiltro.getText().length());
		txtFiltro.focus();
	}

	private void createComponents() {
	   
	   this.setMaximizable(true);
	   this.setModal(true);
	   this.setHeadingText("Clientes");	   
	   this.setSize("900px", "550px");	   
	   
	   BorderLayoutContainer layout = new BorderLayoutContainer();
	 
	   this.add(layout);
	   
	   crearGrilla();
	   
	   // NORTH
	   ContentPanel panelSuperior = new ContentPanel();
	   panelSuperior.setHeaderVisible(false);

	   HorizontalPanel hp = new HorizontalPanel();
	   hp.setWidth("300px");
	   
	   rbtnFiltrarCodigo = new Radio();
	   rbtnFiltrarNombre = new Radio();
	   rbtnFiltrarCodigo.setBoxLabel("Codigo");
	   rbtnFiltrarNombre.setBoxLabel("Nombre");
	   rbtnFiltrarNombre.setValue(true);
	   tgFiltrarPor = new ToggleGroup();
	   tgFiltrarPor.add(rbtnFiltrarCodigo);
	   tgFiltrarPor.add(rbtnFiltrarNombre);
	   
	   txtFiltro = new TextField();
	   txtFiltro.setWidth("250px");
	   
	   btnBuscar = new Button();
	   btnBuscar.setText("Buscar");
	   btnBuscar.setSize("70px", "30px");
	   
	   hp.add(rbtnFiltrarCodigo);
	   hp.add(rbtnFiltrarNombre);
	   hp.add(txtFiltro);
	   hp.add(btnBuscar);
	   
	   hp.setSpacing(15);
	   	   	   
	   panelSuperior.add(hp, new MarginData(0, 350, 0, 0));
	    
	   layout.setNorthWidget(panelSuperior, new BorderLayoutData(50));
	 
	   // CENTER	   
	   ContentPanel panelCentral = new ContentPanel();
	   panelCentral.setHeaderVisible(false);
	   panelCentral.add(grilla);
	   layout.setCenterWidget(panelCentral);
	   
	   
	   btnAgregar = new Button();	   
	   btnAgregar.setText("Agregar");
	   btnAgregar.setSize("100%", "20px");
	   
	   btnModificar = new Button();
	   btnModificar.setText("Modificar");
	   btnModificar.setSize("100%", "20px");
	   
	   btnEliminar  = new Button();
	   btnEliminar.setText("Eliminar");
	   btnEliminar.setSize("100%", "20px");
	   
	   //RIGHT
	   VerticalLayoutContainer panelDerecha = new VerticalLayoutContainer();
	
	   
	   panelDerecha.add(btnAgregar, new VerticalLayoutData( 100, 100, new Margins(50,1,1,5)));
	   panelDerecha.add(btnModificar, new VerticalLayoutData( 100, 50, new Margins(1,1,1,5)));
	   panelDerecha.add(btnEliminar, new VerticalLayoutData( 100, 50, new Margins(1,1,1,5)));
	   layout.setEastWidget(panelDerecha, new BorderLayoutData(90));
	   
	}
	
	
	private void events() {	
		btnAgregar.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
			   FormCliente form = new FormCliente(observableManager, Ctes.K_MODO_ALTA, null);
			   			  
			   form.show();
			}
		});
		
		btnEliminar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				 ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "Realmente desea eliminar el cliente?");
			     box.addHideHandler(hideHandler);	
			     ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
			     ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
			     ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
			     box.show();
				
						
			}
		});
		
		btnModificar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {				
			   modificarClienteSeleccionado();	
			}

		});				
		
		btnBuscar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
               buscarClientes();				
			}
		});
		
		grilla.addCellDoubleClickHandler(new CellDoubleClickHandler() {
			
			@Override
			public void onCellClick(CellDoubleClickEvent event) {
				modificarClienteSeleccionado();				
			}
		});
		
		 txtFiltro.addKeyDownHandler(new KeyDownHandler() {
			
			@Override
			public void onKeyDown(KeyDownEvent event) {
				 if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {				   
					 buscarClientes();	
					 ponerFocoEnFiltro();					 
				 }				
			}
		});
	}
	
	protected void buscarClientes() {
       Integer buscarPor;
	   if (this.rbtnFiltrarCodigo.getValue() == true) {
          	  buscarPor = Ctes.K_BUSCAR_X_COD;
       }
	   else {
		   buscarPor = Ctes.K_BUSCAR_X_NOM;
	   }
	   
	   grilla.getStore().clear();
	   this.grilla.mask("Cargarndo clientes...");
	   this.btnBuscar.setEnabled(false);
	   
	   manejadorClientes.buscarCliente(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTCliente>>() {
		
		@Override
		public void onSuccess(ArrayList<DTCliente> result) {
			   store.addAll(result);
               grilla.reconfigure(store, cm);	
               grilla.unmask();
               ponerFocoEnFiltro();
               btnBuscar.setEnabled(true);
		}
		
		@Override
		public void onFailure(Throwable caught) {
			 grilla.unmask();
			 btnBuscar.setEnabled(true);
		}
	});
	   
	}

	protected void modificarClienteSeleccionado() {
		 DTCliente clienteSeleccionado;
		   
		   clienteSeleccionado = grilla.getSelectionModel().getSelectedItem();
		   
		   if (clienteSeleccionado != null) {
		      modificarCliente(clienteSeleccionado);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	}

	private void modificarCliente(DTCliente clienteSeleccionado) {
	   FormCliente form = new FormCliente(observableManager, Ctes.K_MODO_MODIFICACION, clienteSeleccionado.getCodigo());			  
       form.show();			
	}

	protected void eliminarClienteSeleccionado() {
	   DTCliente clienteSeleccionado;
	   
	   clienteSeleccionado = grilla.getSelectionModel().getSelectedItem();
	   
	   if (clienteSeleccionado != null) {
	      eliminarCliente(clienteSeleccionado);            
	   }
	   else {		   
		   errorDebeSeleccionarUnElemento();		   
	   }
	}

	
	private void eliminarCliente(DTCliente clienteSeleccionado) {
		manejadorClientes.eliminarCliente(clienteSeleccionado.getCodigo(), new AsyncCallback() {

			@Override
			public void onSuccess(Object result) {
		       cargarGrilla();				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}			
		}); 
	}

	private void crearGrilla(){	      
		  ColumnConfig<DTCliente, String> codigoCol = new ColumnConfig<DTCliente, String>(props.codigo(), 100, "Codigo");
		  ColumnConfig<DTCliente, String> nombreCol = new ColumnConfig<DTCliente, String>(props.nombre(), 100, "Nombre");
		  ColumnConfig<DTCliente, String> rutCol = new ColumnConfig<DTCliente, String>(props.rut(), 100, "Rut");
		  ColumnConfig<DTCliente, String> telefonoCol = new ColumnConfig<DTCliente, String>(props.telefono(), 100, "Telefono");
	      ColumnConfig<DTCliente, String> emailCol = new ColumnConfig<DTCliente, String>(props.email(), 100, "Email");
	      ColumnConfig<DTCliente, String> direccionCol = new ColumnConfig<DTCliente, String>(props.direccion(), 100, "Direccion");
	 
	      List<ColumnConfig<DTCliente, ?>> l = new ArrayList<ColumnConfig<DTCliente, ?>>();
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(rutCol);
	      l.add(telefonoCol);
	      l.add(emailCol);
	      l.add(direccionCol);
	      
	      cm = new ColumnModel<DTCliente>(l);
	 
	      store = new ListStore<DTCliente>(props.key());	      	     	      
	      
	      grilla = new Grid<DTCliente>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	      
	}

	private void cargarGrilla() {		
		grilla.getStore().clear();
		this.grilla.mask("Cargando clientes...");
		manejadorClientes.obtenerClientes(new AsyncCallback<ArrayList<DTCliente>>(
				) {
					@Override
					public void onSuccess(ArrayList<DTCliente> result) {
					   store.addAll(result);
                       grilla.reconfigure(store, cm);	
                       grilla.unmask();
					}
					
					@Override
					public void onFailure(Throwable caught) {
						grilla.unmask();						
					}
		});		
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
		cargarGrilla();		
	}

	public void errorDebeSeleccionarUnElemento() {
		final Dialog simple = new Dialog();
	    simple.setHeadingText("Atencion");
	    simple.setPredefinedButtons(PredefinedButton.OK);
	    simple.setBodyStyleName("pad-text");
	    simple.add(new Label("Debe seleccionar un cliente en la grilla"));
	    simple.getBody().addClassName("pad-text");
	    simple.setHideOnButtonClick(true);
	    simple.setWidth(300);
	   
	   simple.show();
	}
	
	 final HideHandler hideHandler = new HideHandler() {
	      @Override
	      public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarClienteSeleccionado();
	        }	        
	      }
	    };
	 

}
