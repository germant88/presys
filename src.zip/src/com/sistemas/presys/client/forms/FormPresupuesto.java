package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.HasDirection.Direction;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.widgets.Component;
import com.gwtext.client.widgets.Toolbar;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.event.ButtonListener;
import com.gwtext.client.widgets.form.Label;
import com.gwtext.client.widgets.menu.Menu;
import com.sencha.gxt.cell.core.client.PropertyDisplayCell;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer.HorizontalLayoutData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.form.DateField;
import com.sencha.gxt.widget.core.client.form.DateTimePropertyEditor;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.NumberField;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.DoublePropertyEditor;
import com.sencha.gxt.widget.core.client.form.SpinnerField;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.NotaImpresionPresupuestoProperties;
import com.sistemas.presys.client.properties.NotaSeguimientoProperties;
import com.sistemas.presys.client.properties.RenglonPresupuestoProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativos;
import com.sistemas.presys.client.rpc.IRPCManejadorCorrelativosAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorSolicitudesPresupuestos;
import com.sistemas.presys.client.rpc.IRPCManejadorSolicitudesPresupuestosAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorUtiles;
import com.sistemas.presys.client.rpc.IRPCManejadorUtilesAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTTareaRenglon;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.model.Garantia;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormPresupuesto extends Window implements IObserver{

	protected final IRPCManejadorCorrelativosAsync manejadorCorrelativos = GWT
			.create(IRPCManejadorCorrelativos.class);
	
	private static final NotaSeguimientoProperties props = GWT.create(NotaSeguimientoProperties.class);
	
	private static final NotaImpresionPresupuestoProperties propsNotaImpresion = GWT.create(NotaImpresionPresupuestoProperties.class);
	
	private static final RenglonPresupuestoProperties propsRenglonPresupuesto = GWT.create(RenglonPresupuestoProperties.class);
	
	private   Button btnAgregar;
	private   Button btnModificar;
	private   Button btnEliminar;
	protected Button btnConfirmar;
	protected Button btnCancelar;
	
	protected BorderLayoutContainer layout;
	
	protected BorderLayoutContainer layoutSeguimiento;
	
	protected BorderLayoutContainer layoutNotasImpresion;
	
	protected BorderLayoutContainer layoutOtrosDatos;
	
	private Integer modoNotaActual;
	
	protected FieldSet fsCliente;
	
	protected FieldSet fsEdificio;
	
	protected FieldSet fsUsuario;
	
	protected FieldSet fsFormaDePago;
	
	protected FieldSet fsGarantia;
	
    protected TextField txtCodigo;
    
    protected Button btnSolOrigen;
    
    protected TextField tipoDocumentoOrigen;
    
    protected TextField codigoSolOrigen;
    
    protected TextField txtNombreCliente;
    
    protected TextField txtNombreEdificio;       
    
    protected TextField txtDireccionEdificio;
    
    protected TextField txtNombreFormaDePago;
    
    protected TextField txtNombreUsuario;
    
    protected TextField txtNombreGarantia;        
    
    protected TextField txtUsuarioAsignado;
    
    protected DateField dtfFechaIngreso;
    	
	private TextArea txtDetalles;
	
	private SeleccionObjeto seleccionCliente;
	
	private SeleccionObjeto seleccionEdificio;
	
	private SeleccionObjeto seleccionUsuario;
	
	private SeleccionObjeto seleccionFormaDePago;
	
	private SeleccionObjeto seleccionGarantia;
	
	private DateField dtfFechaDeSeguimiento;
	
	private TextField txtEstado;
	
	private Label lblDetalles;
	
	private NumberField<Double> txtTotal;
	
	private NumberField<Double> txtSuperficie;
	
	private NumberField<Double> txtLeyesNIMontoMax;
	
	private NumberField<Double> txtCostoAdicionalBano;	
	
	private TabPanel tabPanel;
	
	private SpinnerField spinnerFieldEjecucionDias;
	private SpinnerField spinnerFieldEjecucionMeses;
	private SpinnerField spinnerFieldEjecucionAnios;
	
	private SpinnerField spinnerFieldValidezDias;
	private SpinnerField spinnerFieldValidezMeses;
	private SpinnerField spinnerFieldValidezAnios;		
			
	ToolbarButton btnAgregarNota;
	
	ToolbarButton btnModificarNota;
	
	ToolbarButton btnEliminarNota;

	ObservableManager observableManager;
	
	ObservableManager observableManagerSeleccion;
	
	ObservableManager observableNotas;
	
	ObservableManager observableNotasImpresion;
	
	ObservableManager observableRenglon;
	
	ObservableManager observableSolicitudOrigen;
	
    ToolbarButton btnAgregarNotaImpresion;
	
	ToolbarButton btnModificarNotaImpresion;
	
	ToolbarButton btnEliminarNotaImpresion;
	
	
	Integer modo;     
    
	private String codigo;
	
	private String tipoDocumento;
	
	private Grid<DTNotaSeguimiento> grillaSeguimiento;
	
	private ListStore<DTNotaSeguimiento> store;
	private ColumnModel<DTNotaSeguimiento> cm;
	
	private Grid<DTNotaImpresionPresupuesto> grillaNotaImpresion;
	
	private ListStore<DTNotaImpresionPresupuesto> storeNotasImpresion;
	private ColumnModel<DTNotaImpresionPresupuesto> cmNotasImpresion;
	
	private Grid<DTRenglonPresupuesto> grillaRenglones;
	
	private ListStore<DTRenglonPresupuesto> storeRenglones;
	private ColumnModel<DTRenglonPresupuesto> cmRenglones;
	
	private ArrayList<DTNotaSeguimiento> listaNotasSeguimiento;
	
	private ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresion;
	
	private ArrayList<DTRenglonPresupuesto> listaRenglones;
	
	protected IRPCManejadorSolicitudesPresupuestosAsync manejadorSolicitudes;
	
	protected IRPCManejadorUtilesAsync manejadorUtiles;
    
	public FormPresupuesto(ObservableManager xobsManager, Integer xmodo, String xcodigo, String xtipoDocumento){
		super();
		observableManagerSeleccion = new ObservableManager();
		observableManagerSeleccion.addObserver(this);
		observableNotas            = new ObservableManager();
		observableNotas.addObserver(this);			
		observableNotasImpresion = new ObservableManager();
		observableNotasImpresion.addObserver(this);		
		observableRenglon          = new ObservableManager();
		observableRenglon.addObserver(this);
		observableSolicitudOrigen = new ObservableManager();
		observableSolicitudOrigen.addObserver(this);
		observableManager          = xobsManager;
		modo                       = xmodo;
		codigo                     = xcodigo;		
		tipoDocumento              = xtipoDocumento;
	    listaNotasSeguimiento = new ArrayList<DTNotaSeguimiento>();
	    listaNotasImpresion   = new ArrayList<DTNotaImpresionPresupuesto>();
	    listaRenglones        = new ArrayList<DTRenglonPresupuesto>();
		
		manejadorSolicitudes = GWT.create(IRPCManejadorSolicitudesPresupuestos.class);
		manejadorUtiles = GWT.create(IRPCManejadorUtiles.class);
		createComponents();
		initEvents();
		if ((modo == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {		    
			cargarPantalla(codigo, tipoDocumento);         	
			cargarListaNotas(codigo, tipoDocumento);
		}	                
	}		

	private void cargarListaNotas(String codigoSolicitud, String tipoDocumento) {
		manejadorSolicitudes.obtenerNotasDeSolicitud(codigoSolicitud, tipoDocumento, new AsyncCallback<List<DTNotaSeguimiento>>(
				
				) {
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onSuccess(List<DTNotaSeguimiento> result) {
						listaNotasSeguimiento = (ArrayList<DTNotaSeguimiento>) result;
						cargarGrilla();
					}
		});				
	}
	

	private void cargarPantalla(String codigo, String tipoDocumento) {
       manejadorSolicitudes.obtenerPorCodigo(codigo, tipoDocumento, new AsyncCallback<DTSolicitudPresupuesto>() {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onSuccess(DTSolicitudPresupuesto result) {
			cargarPantallaConObjeto(result);			
		}
	});
		
	}

	protected void cargarPantallaConObjeto(DTSolicitudPresupuesto result) {
		// Cabezal
		this.txtCodigo.setValue(result.getCodigo());
		this.dtfFechaIngreso.setValue(result.getFecha());		
		this.seleccionCliente.txtCodigo.setValue(result.getCliente().getCodigo());
		this.txtNombreCliente.setValue(result.getCliente().getNombre());
		this.seleccionEdificio.txtCodigo.setValue(result.getEdificio().getCodigo());
		this.txtNombreEdificio.setValue(result.getEdificio().getNombre());
		this.txtDireccionEdificio.setValue(result.getEdificio().getDireccion());
		this.seleccionUsuario.txtCodigo.setValue(result.getUsuarioAsignado().getId());
		this.txtNombreUsuario.setValue((result.getUsuarioAsignado().getNombre() == null ? "" : result.getUsuarioAsignado().getNombre()) + " " + (result.getUsuarioAsignado().getApellido() == null ? "" : result.getUsuarioAsignado().getApellido()));
		this.txtDetalles.setValue(result.getDetalles());				
				
		switch (result.getEstado()) {
		case 1 :
			this.txtEstado.setValue("Pendiente");
			break;
		case 2 :
			this.txtEstado.setValue("Presupuestada");
			break;
		case 3 :
			this.txtEstado.setValue("Modificado");
			break;
		}
				
		//this.txtUsuarioAsignado.setValue(result.getUsuarioAsignado().getId());
		
		this.seleccionFormaDePago.txtCodigo.setValue(result.getFormaDePago().getCodigo());
		this.txtNombreFormaDePago.setValue(result.getFormaDePago().getNombre());
				
		this.seleccionGarantia.txtCodigo.setValue(result.getGarantia().getCodigo());
		this.txtNombreGarantia.setValue(result.getGarantia().getNombre());
		
		this.txtSuperficie.setValue(result.getSuperficie().doubleValue());
		
		this.txtLeyesNIMontoMax.setValue(result.getLeyesSociales());
		
		this.txtCostoAdicionalBano.setValue(result.getCostoBQ());
		
		this.spinnerFieldEjecucionDias.setText(result.getTiempoEjecucionDias().toString());
		this.spinnerFieldEjecucionMeses.setText(result.getTiempoEjecucionMeses().toString());
		this.spinnerFieldEjecucionAnios.setText(result.getTiempoEjecucionAnios().toString());
		
		this.spinnerFieldValidezDias.setText(result.getValidezDias().toString());
		this.spinnerFieldValidezMeses.setText(result.getValidezMeses().toString());
		this.spinnerFieldValidezAnios.setText(result.getValidezAnios().toString());
		
		//this.txtNombreCliente.setValue(result.getCliente().getNombre());
		
		if (result.getSolicitudPresupuestoOrigen() != null) {
			this.codigoSolOrigen.setValue(result.getSolicitudPresupuestoOrigen().getCodigo());
			this.tipoDocumentoOrigen.setValue(result.getSolicitudPresupuestoOrigen().getTipoDocumento());
		}
		
		// Renglones
		listaRenglones = result.getRenglonesSolicitud();
		renumerarRenglones();
		actualizarTotal(); // Aca abr�a que obtener el total grabado en la base de datos.
		cargarGrillaRenglones();
		
		// Notas de impresion
		listaNotasImpresion.clear();
		for (int i = 0; i < result.getListaNotaImpresionPresupuesto().size(); i ++) {
			listaNotasImpresion.add(result.getListaNotaImpresionPresupuesto().get(i));
		}
		
		cargarGrillaNotasImpresion();
	}

	private void initEvents() {
       btnConfirmar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		   if (modo == Ctes.K_MODO_MODIFICACION) {			   
			   modificarSolicitud();
		   }
		   else if ( modo == Ctes.K_MODO_ALTA) {
			   agregarSolicitud();
		   }			
		   else if (modo == Ctes.K_MODO_CONSULTA) {
			   cerrarme();
		   }
	    }
	   });
              
       btnCancelar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		   cerrarme();			
		}
	});       
       
       btnAgregar.addClickHandler(new ClickHandler() {		
		@Override
		public void onClick(ClickEvent event) {		   
			FormRenglonPresupuesto form = new FormRenglonPresupuesto(observableRenglon, 1, null);
			form.show();
		}
	});       
       
       btnEliminar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		   if (!(grillaRenglones.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe seleccionar al menos un renglon para eliminar");
				 box.show();
		   }
		   else {
			  eliminarRenglones(grillaRenglones.getSelectionModel().getSelectedItems());   
		   }			
		}
	});
       
       grillaRenglones.addCellDoubleClickHandler(new CellDoubleClickHandler() {
		
		@Override
		public void onCellClick(CellDoubleClickEvent event) {								
			if (!(grillaRenglones.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box1 = new MessageBox("Atencion");												    												    												    
			     box1.setMessage("Debe seleccionar un renglon para poder modificarlo");
				 box1.show();
		   }
		   else {			   
			   if (modo == Ctes.K_MODO_CONSULTA) {
				   consultarRenglon(grillaRenglones.getSelectionModel().getSelectedItem());   
			   }
			   else {
				   modificarRenglon(grillaRenglones.getSelectionModel().getSelectedItem());
			   }			      
		   }				
		}
	});
       
        btnModificar.addClickHandler(new ClickHandler() {		
		@Override
		public void onClick(ClickEvent event) {
			if (!(grillaRenglones.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe seleccionar un renglon para poder modificarlo");
				 box.show();
		   }
		   else {
			  modificarRenglon(grillaRenglones.getSelectionModel().getSelectedItem());   
		   }				
		}
	});
        
        
       
    btnSolOrigen.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		   FormConsultaPresupuestos form = new FormConsultaPresupuestos(observableSolicitudOrigen, Ctes.K_MODO_SELECCION_SOL_ORIGEN);
		   form.show();
		}
	});
    
        btnAgregarNota.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
		   modoNotaActual = Ctes.K_MODO_ALTA;
		   FormNotaSeguimiento form = new FormNotaSeguimiento(observableNotas, Ctes.K_MODO_ALTA, null);
		   form.show();				   
		}
	});
       
        
      btnEliminarNota.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			if (!(grillaSeguimiento.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe seleccionar al menos una nota para eliminar");
				 box.show();
		   }
		   else {
			  eliminarNotas(grillaSeguimiento.getSelectionModel().getSelectedItems());   
		   }				
		}
	});
      
      btnModificarNota.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			if (!(grillaSeguimiento.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe seleccionar al menos una nota para poder modificarla");
				 box.show();
		   }
		   else {
			  modificarNota(grillaSeguimiento.getSelectionModel().getSelectedItem());   
		   }			
		}
	});
    
      btnAgregarNotaImpresion.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
		   modoNotaActual = Ctes.K_MODO_ALTA;
		   FormNotaImpresionPresupuesto form = new FormNotaImpresionPresupuesto(observableNotasImpresion, Ctes.K_MODO_ALTA, null);
		   form.show();				
		}
	});
      
      btnModificarNotaImpresion.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			if (!(grillaNotaImpresion.getSelectionModel().getSelectedItems().size() > 0)) { 
	        	   MessageBox box = new MessageBox("Atencion");												    												    												    
				   box.setMessage("Debe seleccionar una nota de impresi�n para poder modificarla");
				   box.show();        	           	   
	           }
	           else {
	              modoNotaActual = Ctes.K_MODO_MODIFICACION;
	        	  FormNotaImpresionPresupuesto form = new FormNotaImpresionPresupuesto(observableNotasImpresion, Ctes.K_MODO_MODIFICACION, grillaNotaImpresion.getSelectionModel().getSelectedItem());
	              form.show();
	           }			
		}
	});
      
      btnEliminarNotaImpresion.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			eliminarNotasImpresion(grillaNotaImpresion.getSelectionModel().getSelectedItems());			
		}
	});
      
	}
	
	private void eliminarNotasImpresion(List<DTNotaImpresionPresupuesto> selectedItems){
		  for (DTNotaImpresionPresupuesto notaImpresionPresupuestoAEliminar : selectedItems) {
	   	     listaNotasImpresion.remove(notaImpresionPresupuestoAEliminar);
	      }
	      renumerarNotasImpresion();	   
		  cargarGrillaNotasImpresion();
	}
	
	
	private void eliminarNotas(List<DTNotaSeguimiento> selectedItems) {
		 for (DTNotaSeguimiento nota : selectedItems) {
		   	   listaNotasSeguimiento.remove(nota);
		      }
		      renumerarNotas();	   
			  cargarGrilla();
		}
		
		private void modificarNota(DTNotaSeguimiento nota) {
			modoNotaActual = Ctes.K_MODO_MODIFICACION;
			FormNotaSeguimiento form = new FormNotaSeguimiento(observableNotas, Ctes.K_MODO_MODIFICACION, nota);
			form.show();
		}

	
	protected void modificarRenglon(DTRenglonPresupuesto selectedItem) {		
		FormRenglonPresupuesto form = new FormRenglonPresupuesto(observableRenglon, Ctes.K_MODO_MODIFICACION, selectedItem);
		form.show();				
	}
	
	private void renumerarNotas() {
		int j = 1;
		for (int i = 0; i < listaNotasSeguimiento.size(); i ++) { 
		   this.listaNotasSeguimiento.get(i).setNumeroNotaSeguimiento(j);
		   j ++;		   
		}			
	}
	
	protected void consultarRenglon(DTRenglonPresupuesto selectedItem) {		
		FormRenglonPresupuesto form = new FormRenglonPresupuesto(observableRenglon, Ctes.K_MODO_CONSULTA, selectedItem);
		form.show();
	}

	protected void eliminarRenglones(List<DTRenglonPresupuesto> selectedItems) {
       for (DTRenglonPresupuesto renglonAEliminar : selectedItems) {
    	   listaRenglones.remove(renglonAEliminar);
       }
       renumerarRenglones();
	   actualizarTotal();
	   cargarGrillaRenglones();
	}

	private void modificarSolicitud() {
       manejadorSolicitudes.modificar(txtCodigo.getValue(), Ctes.K_TDOC_PRESUPUESTO, dtfFechaIngreso.getValue(), seleccionUsuario.txtCodigo.getValue(), 
                seleccionCliente.txtCodigo.getValue(), seleccionEdificio.txtCodigo.getValue(), txtDetalles.getValue(),
                1 /*Pendiente*/, dtfFechaDeSeguimiento.getValue(),listaNotasSeguimiento, 
                this.seleccionFormaDePago.txtCodigo.getValue(), this.seleccionGarantia.txtCodigo.getValue(),
                this.txtSuperficie.getValue().intValue(), this.txtLeyesNIMontoMax.getValue(), this.txtCostoAdicionalBano.getValue(),
                Integer.valueOf(this.spinnerFieldEjecucionDias.getText()), Integer.valueOf(this.spinnerFieldEjecucionMeses.getText()), Integer.valueOf(this.spinnerFieldEjecucionAnios.getText()),
                Integer.valueOf(this.spinnerFieldValidezDias.getText()), Integer.valueOf(this.spinnerFieldValidezMeses.getText()), Integer.valueOf(this.spinnerFieldValidezAnios.getText()),
                this.listaNotasImpresion,
                new AsyncCallback<Void>() {

					@Override
					public void onFailure(Throwable caught) {
						MessageBox box = new MessageBox("Error");												    												    												    
					     box.setMessage("Se produjo un error al intentar ingresar la solicitud: " + caught.getMessage());
						 box.show();									
					}

					@Override
					public void onSuccess(Void result) {
						MessageBox box = new MessageBox("Informacion");												    												    												    
					    box.setMessage("Se modifico correctamente la solicitud " + txtCodigo.getValue());
						box.show();
						cerrarme();						
					}
				});		
	}
	
	
	private void agregarSolicitud(){
		manejadorSolicitudes.agregar(txtCodigo.getValue(), Ctes.K_TDOC_PRESUPUESTO, dtfFechaIngreso.getValue(), seleccionUsuario.txtCodigo.getValue(), 
                seleccionCliente.txtCodigo.getValue(), seleccionEdificio.txtCodigo.getValue(), txtDetalles.getValue(),
                1 /*Pendiente*/, dtfFechaDeSeguimiento.getValue(),listaNotasSeguimiento, this.txtTotal.getValue(), this.codigoSolOrigen.getValue(),
                this.tipoDocumentoOrigen.getValue(), this.listaRenglones,
                this.seleccionFormaDePago.txtCodigo.getValue(), 
                this.seleccionGarantia.txtCodigo.getValue(),
                (this.txtSuperficie.getValue() != null ? this.txtSuperficie.getValue().intValue() : 0), 
                this.txtLeyesNIMontoMax.getValue(), 
                this.txtCostoAdicionalBano.getValue(),
                Integer.valueOf(this.spinnerFieldEjecucionDias.getText()), 
                Integer.valueOf(this.spinnerFieldEjecucionMeses.getText()), 
                Integer.valueOf(this.spinnerFieldEjecucionAnios.getText()),
                Integer.valueOf(this.spinnerFieldValidezDias.getText()), 
                Integer.valueOf(this.spinnerFieldValidezMeses.getText()), 
                Integer.valueOf(this.spinnerFieldValidezAnios.getText()),
                this.listaNotasImpresion,
                new AsyncCallback<Void>() {

					@Override
					public void onFailure(
							Throwable caught) {
						 MessageBox box = new MessageBox("Error");												    												    												    
					     box.setMessage("Se produjo un error al intentar ingresar la solicitud: " + caught.getMessage());
						 box.show();													
					}

					@Override
					public void onSuccess(Void result) {
						ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "Se ingreso correctamente la solicitud " + txtCodigo.getValue() + ".\n Desea exportar el reporte en formato PDF?");
					     box.addHideHandler(hideHandler);	
					     ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
					     ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
					     ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
					     box.show();
																		
						cerrarme();						
					}											
	});		
   }					

	private void createComponents() {
		this.setMaximizable(false);
        this.setModal(true);
        this.setResizable(false);
		
        this.setHeadingText("Ingreso de solicitud de presupuesto");
    
        this.setSize("700px", "700px");
        
        tabPanel = new TabPanel();
        tabPanel.setSize("100%", "100%");
		   
		layout = new BorderLayoutContainer();
		   
		this.add(tabPanel);
		
		tabPanel.add(layout, "General");		  
		
		VerticalPanel panelInferior = new VerticalPanel();
		panelInferior.setSize("100%", "100%");
		
		HorizontalPanel contenedor = new HorizontalPanel();
		
		VerticalPanel contenedorIzquierdo = new VerticalPanel();
				
		HorizontalPanel contenedorCentral = new HorizontalPanel();
		contenedorCentral.setSize("100%", "100%");
		
		txtCodigo = new TextField();	   
		txtCodigo.setValue("0");
		
		if ( (this.modo == Ctes.K_MODO_MODIFICACION) || (this.modo == Ctes.K_MODO_CONSULTA) ) {
		      txtCodigo.setReadOnly(true);
		      txtCodigo.setEnabled(false);
		   }	  
		   else {
			   txtCodigo.setReadOnly(false);
			   txtCodigo.setEnabled(true);  
			   cargarProximoCorrelativo();
	    }
		
		dtfFechaIngreso = new DateField();
		dtfFechaIngreso.setValue(new Date());
		dtfFechaIngreso.setPropertyEditor(new DateTimePropertyEditor("dd/MM/yyyy"));
		
		if ((this.modo == Ctes.K_MODO_MODIFICACION) || (this.modo == Ctes.K_MODO_CONSULTA) ) {
			dtfFechaIngreso.setReadOnly(true);
			dtfFechaIngreso.setEnabled(false);
		}
		else {
			dtfFechaIngreso.setReadOnly(false);
			dtfFechaIngreso.setEnabled(true);	
		}
		
		VerticalLayoutContainer vlcCliente = new VerticalLayoutContainer();
		
        
		fsCliente = new FieldSet();
        fsCliente.setHeadingText("Cliente");
        fsCliente.setCollapsible(true);
        fsCliente.setSize("310px", "90px");
                                
        txtNombreCliente = new TextField();
        txtNombreCliente.setReadOnly(true);
                
        seleccionCliente = new SeleccionObjeto(observableManagerSeleccion, 1);
        
        if ( (modo  == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA) ) {
        	seleccionCliente.txtCodigo.setReadOnly(true);
        	seleccionCliente.btnBuscar.setEnabled(false);
        }
        else {
        	seleccionCliente.txtCodigo.setReadOnly(false);
        	seleccionCliente.btnBuscar.setEnabled(true);
        }
                
        vlcCliente.add(new FieldLabel(seleccionCliente, "Codigo"));
        vlcCliente.add(new FieldLabel(txtNombreCliente, "Nombre"));
        
        fsCliente.add(vlcCliente);
        
        Button btnSolicitudOrigen = new Button();
        btnSolicitudOrigen.setText("Buscar");
        
        if ((modo == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {
        	btnSolicitudOrigen.setEnabled(false);
        }
        
        codigoSolOrigen = new TextField();
        codigoSolOrigen.setReadOnly(true);
        codigoSolOrigen.setWidth(80);
        
        tipoDocumentoOrigen = new TextField();
        tipoDocumentoOrigen.setReadOnly(true);
        tipoDocumentoOrigen.setWidth(80);
        
        
        FieldLabel flFecha = new FieldLabel(dtfFechaIngreso, "Fecha");
        flFecha.setLabelWidth(110);
        
        FieldLabel flCodigo = new FieldLabel(txtCodigo, "Codigo");
        flCodigo.setLabelWidth(110);
                
        contenedorIzquierdo.add(flFecha);
		contenedorIzquierdo.add(flCodigo);
		
		HorizontalPanel hpSolOrigen = new HorizontalPanel();
		hpSolOrigen.setSpacing(5);
		
		FieldLabel flDocumentoOrigen = new FieldLabel(codigoSolOrigen, "Documento Origen");
		flDocumentoOrigen.setLabelWidth(110);
		
		hpSolOrigen.add(flDocumentoOrigen);
		hpSolOrigen.add(tipoDocumentoOrigen);
		
		btnSolOrigen = new Button();
        btnSolOrigen.setText("...");
        if ((modo == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {
        	btnSolOrigen.setEnabled(false);
        }
		hpSolOrigen.add(btnSolOrigen);
		
		
		dtfFechaDeSeguimiento = new DateField();
        dtfFechaDeSeguimiento.setPropertyEditor(new DateTimePropertyEditor("dd/MM/yyyy"));
        dtfFechaDeSeguimiento.setReadOnly(true);
        
		contenedorIzquierdo.add(hpSolOrigen);
		contenedorIzquierdo.add(fsCliente);
		
		HorizontalPanel hpSeguimiento = new HorizontalPanel();
		
		hpSeguimiento.add(new FieldLabel(dtfFechaDeSeguimiento, "Seguimiento"));
		
		contenedorIzquierdo.add(hpSeguimiento);
		
		VerticalPanel contenedorDerecho = new VerticalPanel();
		
		VerticalLayoutContainer vlcUsuario = new VerticalLayoutContainer();
        
		fsUsuario = new FieldSet();
		fsUsuario.setHeadingText("Asignado a:");
		fsUsuario.setCollapsible(true);
		fsUsuario.setSize("310px", "90px");
                                
        txtNombreUsuario = new TextField();
        txtNombreUsuario.setReadOnly(true);
                
        seleccionUsuario = new SeleccionObjeto(observableManagerSeleccion, 4);        
        vlcUsuario.add(new FieldLabel(seleccionUsuario, "Codigo"));
        vlcUsuario.add(new FieldLabel(txtNombreUsuario, "Nombre"));
        
        fsUsuario.add(vlcUsuario);
		
		/*
		txtUsuarioAsignado = new TextField();
		if (modo == Ctes.K_MODO_MODIFICACION) {
			txtUsuarioAsignado.setReadOnly(true);
		}
		else {
			txtUsuarioAsignado.setReadOnly(false);
		}*/
		
		VerticalLayoutContainer vlcEdificio = new VerticalLayoutContainer();
		
		fsEdificio = new FieldSet();
		fsEdificio.setHeadingText("Edificio");
		fsEdificio.setCollapsible(true);
		fsEdificio.setSize("310px", "110px");
        		
        seleccionEdificio = new SeleccionObjeto(observableManagerSeleccion, 2);
        txtNombreEdificio = new TextField();
        txtNombreEdificio.setReadOnly(true);
        txtDireccionEdificio = new TextField();
        txtDireccionEdificio.setReadOnly(true);
        
        if ((modo  == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {
        	seleccionEdificio.txtCodigo.setReadOnly(true);
        	seleccionEdificio.btnBuscar.setEnabled(false);
        }
        else {
        	seleccionEdificio.txtCodigo.setReadOnly(false);
        	seleccionEdificio.btnBuscar.setEnabled(true);
        }
		
        
        vlcEdificio.add(new FieldLabel(seleccionEdificio, "Codigo"));
        vlcEdificio.add(new FieldLabel(txtNombreEdificio, "Nombre"));
        vlcEdificio.add(new FieldLabel(txtDireccionEdificio, "Direccion"));
        
        fsEdificio.add(vlcEdificio);
        
        txtEstado = new TextField();        
                
        txtEstado.setValue("Pendiente");
        txtEstado.setReadOnly(true);
        
        
        
        
        
        Label lblVacio = new Label("");        
        
		contenedorDerecho.add(new FieldLabel(txtEstado, "Estado"));
		contenedorDerecho.add(fsUsuario);	
        contenedorDerecho.add(lblVacio);
		contenedorDerecho.add(fsEdificio);						
								
		//contenedorDerecho.add(hpSeguimiento);
		
		contenedor.add(contenedorIzquierdo);
		contenedor.add(contenedorDerecho);
		
		txtTotal = new NumberField<Double>(new DoublePropertyEditor());
		
		txtTotal.setReadOnly(true);
		txtTotal.getElement().setAttribute("text-align", "right");
		txtTotal.setFormat(NumberFormat.getFormat("$#,##0.00"));
		txtTotal.setDirection(Direction.RTL);
		
			
		txtDetalles = new TextArea();
		txtDetalles.setSize("680px", "50px");
		
		if (modo == Ctes.K_MODO_CONSULTA) {
			txtDetalles.setReadOnly(true);
		}
		else {
			txtDetalles.setReadOnly(false);
		}
		
		
		lblDetalles = new Label();
		lblDetalles.setText("Detalles:");
		
		
		FieldLabel flblTotal = new FieldLabel(txtTotal, "Total");
		flblTotal.setPosition(340, 10);
		
		
		panelInferior.add(flblTotal);
		panelInferior.add(lblDetalles);
		panelInferior.add(txtDetalles);	
		
		/*
		if ( this.modo == Ctes.K_MODO_MODIFICACION ) {
		      txtCodigo.setReadOnly(true);
		      txtCodigo.setEnabled(false);
		}	  
		else {
		   txtCodigo.setReadOnly(false);
		   txtCodigo.setEnabled(true);  
		   cargarProximoCorrelativo();
		}
		 */  	 
				
		//txtCodigo.setReadOnly(false);
		//txtCodigo.setEnabled(true);
		
	
		crearGrillaRenglones();
		
		  ContentPanel panelCentral = new ContentPanel();
		   panelCentral.setHeaderVisible(false);
		   panelCentral.add(grillaRenglones);
		   
		
		contenedorCentral.add(grillaRenglones);
		
		
		   btnAgregar = new Button();	   
		   btnAgregar.setText("Agregar");
		   btnAgregar.setSize("100%", "20px");
		   
		   btnModificar = new Button();
		   btnModificar.setText("Modificar");
		   btnModificar.setSize("100%", "20px");
		   
		   btnEliminar  = new Button();
		   btnEliminar.setText("Eliminar");
		   btnEliminar.setSize("100%", "20px");
		   
		   if ((modo == Ctes.K_MODO_MODIFICACION)|| (modo == Ctes.K_MODO_CONSULTA)) {
			   btnAgregar.setEnabled(false);
			   btnModificar.setEnabled(false);
			   btnEliminar.setEnabled(false);
		   }
		   
		   //RIGHT
		   VerticalLayoutContainer panelDerecha = new VerticalLayoutContainer();
				   
		   panelDerecha.add(btnAgregar, new VerticalLayoutData( 100, 100, new Margins(50,1,1,5)));
		   panelDerecha.add(btnModificar, new VerticalLayoutData( 100, 50, new Margins(1,1,1,5)));
		   panelDerecha.add(btnEliminar, new VerticalLayoutData( 100, 50, new Margins(1,1,1,5)));
		   layout.setEastWidget(panelDerecha, new BorderLayoutData(90));
		
		layout.setNorthWidget(contenedor, new BorderLayoutData(260));
		layout.setCenterWidget(grillaRenglones, new BorderLayoutData(180));
		layout.setSouthWidget(panelInferior, new BorderLayoutData(150));
		  
		  // PESTA�A OTROS
		  layoutOtrosDatos = new BorderLayoutContainer();
		
		  HorizontalPanel contenedorOtros = new HorizontalPanel();
		  
          VerticalLayoutContainer contenedorOtrosCentral = new VerticalLayoutContainer();
					  
			VerticalLayoutContainer vlcFormaDePago = new VerticalLayoutContainer();
			
			fsFormaDePago = new FieldSet();
			fsFormaDePago.setHeadingText("Forma de pago");
			fsFormaDePago.setCollapsible(true);
			fsFormaDePago.setSize("310px", "110px");
	        		
	        seleccionFormaDePago = new SeleccionObjeto(observableManagerSeleccion, 6);
	        txtNombreFormaDePago = new TextField();
	        txtNombreFormaDePago.setReadOnly(true);	        
	        
	        if ((modo  == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {
	        	seleccionFormaDePago.txtCodigo.setReadOnly(true);
	        	seleccionFormaDePago.btnBuscar.setEnabled(false);
	        }
	        else {
	        	seleccionFormaDePago.txtCodigo.setReadOnly(false);
	        	seleccionFormaDePago.btnBuscar.setEnabled(true);
	        }
				        
	        vlcFormaDePago.add(new FieldLabel(seleccionFormaDePago, "Codigo"));
	        vlcFormaDePago.add(new FieldLabel(txtNombreFormaDePago, "Nombre"));	        
	        
	        fsFormaDePago.add(vlcFormaDePago);
	        
	        VerticalLayoutContainer vlcGarantia = new VerticalLayoutContainer();
			
			fsGarantia = new FieldSet();
			fsGarantia.setHeadingText("Garantia");
			fsGarantia.setCollapsible(true);
			fsGarantia.setSize("310px", "110px");
	        		
	        seleccionGarantia = new SeleccionObjeto(observableManagerSeleccion, 7);
	        txtNombreGarantia = new TextField();
	        txtNombreGarantia.setReadOnly(true);	        
	        
	        if ((modo  == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {
	        	seleccionGarantia.txtCodigo.setReadOnly(true);
	        	seleccionGarantia.btnBuscar.setEnabled(false);
	        }
	        else {
	        	seleccionGarantia.txtCodigo.setReadOnly(false);
	        	seleccionGarantia.btnBuscar.setEnabled(true);
	        }
				        
	        vlcGarantia.add(new FieldLabel(seleccionGarantia, "Codigo"));
	        vlcGarantia.add(new FieldLabel(txtNombreGarantia, "Nombre"));	        
	        
	        fsGarantia.add(vlcGarantia);
		  
		  VerticalLayoutContainer contenedorIzquierdoOtros = new VerticalLayoutContainer();
		  
		  contenedorIzquierdoOtros.add(fsFormaDePago, new VerticalLayoutData(500, 50, new Margins(15,1,1,5)));
		  contenedorIzquierdoOtros.add(fsGarantia, new VerticalLayoutData(500, 50, new Margins(15,1,1,5)));
		  
		  VerticalPanel contenedorDerechoOtros = new VerticalPanel();
		  
			txtSuperficie = new NumberField<Double>(new DoublePropertyEditor());
						
			txtSuperficie.getElement().setAttribute("text-align", "right");
			txtSuperficie.setFormat(NumberFormat.getFormat("#0"));
			//txtSuperficie.setDirection(Direction.RTL);
			
			//contenedorDerechoOtros.add(new FieldLabel(txtSuperficie, "Superficie (m2)"));
			
			
			FieldLabel fieldLabelSuperficie = new FieldLabel(txtSuperficie, "Superficie (m2)");
			fieldLabelSuperficie.setLabelWidth(270);
			
			contenedorOtrosCentral.add(fieldLabelSuperficie, new VerticalLayoutData(500, 50, new Margins(15,1,1,5)));
			
			txtLeyesNIMontoMax = new NumberField<Double>(new DoublePropertyEditor());
			
			txtLeyesNIMontoMax.getElement().setAttribute("text-align", "right");
			txtLeyesNIMontoMax.setFormat(NumberFormat.getFormat("$ #,##0.00"));
			
			
			FieldLabel fieldLabelLeyes = new FieldLabel(txtLeyesNIMontoMax, "Leyes sociales no incluidas hasta ($)");
			fieldLabelLeyes.setLabelWidth(270);
			
			contenedorOtrosCentral.add(fieldLabelLeyes, new VerticalLayoutData(500, 50, new Margins(15,1,1,5)));
						
            txtCostoAdicionalBano = new NumberField<Double>(new DoublePropertyEditor());
			
            txtCostoAdicionalBano.getElement().setAttribute("text-align", "right");
            txtCostoAdicionalBano.setFormat(NumberFormat.getFormat("$ #,##0.00"));
                                    
            FieldLabel fieldCostoBQ = new FieldLabel(txtCostoAdicionalBano, "Costo adicional por alquiler de ba\u00F1o qu\u00EDmico ($)");
            fieldCostoBQ.setLabelWidth(270);
            
            contenedorOtrosCentral.add(fieldCostoBQ, new VerticalLayoutData(500, 50, new Margins(15,1,1,5)));
            
            HorizontalLayoutContainer panelTiempoEjecucion = new HorizontalLayoutContainer();
            panelTiempoEjecucion.setWidth("100%");
                                                
            spinnerFieldEjecucionDias = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
            spinnerFieldEjecucionDias.setIncrement(1);  
            spinnerFieldEjecucionDias.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
            spinnerFieldEjecucionDias.setValue(0);
    	    spinnerFieldEjecucionDias.setMinValue(0);  
    	    spinnerFieldEjecucionDias.setMaxValue(999);
    	    spinnerFieldEjecucionDias.setWidth(50);
    	    
    	    FieldLabel flTiempoEjecDias = new FieldLabel(spinnerFieldEjecucionDias, "D\u00EDas");    	    
    	    flTiempoEjecDias.setLabelWidth(35);
    	    
    	    panelTiempoEjecucion.add(flTiempoEjecDias, new HorizontalLayoutData(80, 30, new Margins(1,1,1,1)));
    	    
    	    spinnerFieldEjecucionMeses = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
            spinnerFieldEjecucionMeses.setIncrement(1);  
            spinnerFieldEjecucionMeses.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
            spinnerFieldEjecucionMeses.setValue(0);
    	    spinnerFieldEjecucionMeses.setMinValue(0);  
    	    spinnerFieldEjecucionMeses.setMaxValue(999);
    	    spinnerFieldEjecucionMeses.setWidth(50);
    	    
    	    FieldLabel flTiempoEjecMeses = new FieldLabel(spinnerFieldEjecucionMeses, "Meses");    	    
    	    flTiempoEjecMeses.setLabelWidth(35);
    	    
    	    panelTiempoEjecucion.add(flTiempoEjecMeses, new HorizontalLayoutData(80, 30, new Margins(1,1,1,30)));
    	    
    	    spinnerFieldEjecucionAnios = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
            spinnerFieldEjecucionAnios.setIncrement(1);  
            spinnerFieldEjecucionAnios.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
            spinnerFieldEjecucionAnios.setValue(0);
    	    spinnerFieldEjecucionAnios.setMinValue(0);  
    	    spinnerFieldEjecucionAnios.setMaxValue(999);
    	    spinnerFieldEjecucionAnios.setWidth(50);
    	    
    	    FieldLabel flTiempoEjecAnios = new FieldLabel(spinnerFieldEjecucionAnios, "A\u00F1os");    	    
    	    flTiempoEjecAnios.setLabelWidth(35);
    	    
    	    panelTiempoEjecucion.add(flTiempoEjecAnios, new HorizontalLayoutData(80, 30, new Margins(1,1,1,30)));
            
    	    FieldLabel fieldTiempoEjec = new FieldLabel(panelTiempoEjecucion, "Tiempo de ejecuci\u00F3n");
    	    fieldTiempoEjec.setLabelWidth(270);
    	    
            contenedorOtrosCentral.add(fieldTiempoEjec, new VerticalLayoutData(500, 50, new Margins(15,1,1,5)));
            
            
            
            HorizontalLayoutContainer panelValidezOfertas = new HorizontalLayoutContainer();
            panelValidezOfertas.setWidth("100%");
                                                
            spinnerFieldValidezDias = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
            spinnerFieldValidezDias.setIncrement(1);  
            spinnerFieldValidezDias.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
            spinnerFieldValidezDias.setValue(0);
            spinnerFieldValidezDias.setMinValue(0);  
            spinnerFieldValidezDias.setMaxValue(999);
            spinnerFieldValidezDias.setWidth(50);
    	    
    	    FieldLabel flValidezDias = new FieldLabel(spinnerFieldValidezDias, "D\u00EDas");    	    
    	    flValidezDias.setLabelWidth(35);
    	    
    	    panelValidezOfertas.add(flValidezDias, new HorizontalLayoutData(80, 30, new Margins(1,1,1,1)));
    	    
    	    spinnerFieldValidezMeses = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
    	    spinnerFieldValidezMeses.setIncrement(1);  
    	    spinnerFieldValidezMeses.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
    	    spinnerFieldValidezMeses.setValue(0);
    	    spinnerFieldValidezMeses.setMinValue(0);  
    	    spinnerFieldValidezMeses.setMaxValue(999);
    	    spinnerFieldValidezMeses.setWidth(50);
    	    
    	    FieldLabel flValidezMeses = new FieldLabel(spinnerFieldValidezMeses, "Meses");    	    
    	    flValidezMeses.setLabelWidth(35);
    	    
    	    panelValidezOfertas.add(flValidezMeses, new HorizontalLayoutData(80, 30, new Margins(1,1,1,30)));
    	    
    	    spinnerFieldValidezAnios = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
    	    spinnerFieldValidezAnios.setIncrement(1);  
    	    spinnerFieldValidezAnios.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
    	    spinnerFieldValidezAnios.setValue(0);
    	    spinnerFieldValidezAnios.setMinValue(0);  
    	    spinnerFieldValidezAnios.setMaxValue(999);
    	    spinnerFieldValidezAnios.setWidth(50);
    	    
    	    FieldLabel flValidezAnios = new FieldLabel(spinnerFieldValidezAnios, "A\u00F1os");    	    
    	    flValidezAnios.setLabelWidth(35);
    	    
    	    panelValidezOfertas.add(flValidezAnios, new HorizontalLayoutData(80, 30, new Margins(1,1,1,30)));
            
    	    FieldLabel fieldValidez = new FieldLabel(panelValidezOfertas, "Validez de las ofertas");
    	    fieldValidez.setLabelWidth(270);
    	    
            contenedorOtrosCentral.add(fieldValidez, new VerticalLayoutData(500, 50, new Margins(15,1,1,5)));
    	    
		  contenedorOtros.add(contenedorIzquierdoOtros);
		  contenedorOtros.add(contenedorDerechoOtros);
		  
		  
		  layoutOtrosDatos.setNorthWidget(contenedorOtros, new BorderLayoutData(260));
		  layoutOtrosDatos.setCenterWidget(contenedorOtrosCentral);
		  
		  tabPanel.add(layoutOtrosDatos, "Otros");
         					
		  // PESTA�A SEGUIMEINTO
		  
		  layoutSeguimiento = new BorderLayoutContainer();		  
  		  
		  Toolbar toolbar = new Toolbar();

	       toolbar.setWidth("100%");
		       
	       btnAgregarNota = new ToolbarButton();
			
		   btnAgregarNota.setText("Agregar Nota");
		   
		   btnModificarNota = new ToolbarButton();
		   
		   btnModificarNota.setText("Modificar Nota");
		   
		   btnEliminarNota = new ToolbarButton();
			
		   btnEliminarNota.setText("Eliminar Nota");
			
		   toolbar.addButton(btnAgregarNota);
		   toolbar.addButton(btnModificarNota);
		   toolbar.addButton(btnEliminarNota);
			
		   toolbar.addFill();								   			
		   	   	   
		   VerticalPanel vp = new VerticalPanel();
		   vp.setWidth("100%");
							   
		   vp.add(toolbar);		
		  		  	  
		  layoutSeguimiento.setNorthWidget(vp, new BorderLayoutData(40));
		  
		  crearGrilla();
		  		  		  
		  layoutSeguimiento.setCenterWidget(grillaSeguimiento);
		  
		  tabPanel.add(layoutSeguimiento, "Seguimiento");
		  
		  // PESTANIA NOTAS DE IMPRESION
		 		  
		  layoutNotasImpresion = new BorderLayoutContainer();		  
  		  
		  Toolbar toolbarNotasImpresion = new Toolbar();

		  toolbarNotasImpresion.setWidth("100%");
		       
	      btnAgregarNotaImpresion = new ToolbarButton();
			
		  btnAgregarNotaImpresion.setText("Agregar nota impresion");
		   
		  btnModificarNotaImpresion = new ToolbarButton();
		   
		  btnModificarNotaImpresion.setText("Modificar nota impresion");
		   
		  btnEliminarNotaImpresion = new ToolbarButton();
			
		  btnEliminarNotaImpresion.setText("Eliminar nota impresion");
		  
		  if ((modo == Ctes.K_MODO_MODIFICACION)|| (modo == Ctes.K_MODO_CONSULTA)) {
			  btnAgregarNotaImpresion.disable();			
			  btnModificarNotaImpresion.disable();			   			   
			  btnEliminarNotaImpresion.disable();				  
		  }
			
		  toolbarNotasImpresion.addButton(btnAgregarNotaImpresion);
		  toolbarNotasImpresion.addButton(btnModificarNotaImpresion);
		  toolbarNotasImpresion.addButton(btnEliminarNotaImpresion);
			
		  toolbarNotasImpresion.addFill();								   			
		   	   	   
		  VerticalPanel vpNotaImpresion = new VerticalPanel();
		  vpNotaImpresion.setWidth("100%");
							   
		  vpNotaImpresion.add(toolbarNotasImpresion);		
		  		  	  
		  layoutNotasImpresion.setNorthWidget(vpNotaImpresion, new BorderLayoutData(40));
		  
		  crearGrillaNotasImpresion();
		  		  		  
		  layoutNotasImpresion.setCenterWidget(grillaNotaImpresion);
		  
		  tabPanel.add(layoutNotasImpresion, "Nota impresion");
				  		  
		  // BOTONES FORM
		  btnConfirmar = new Button();	   
		  btnConfirmar.setText("Confirmar");
		  btnConfirmar.setSize("70px", "30px");
		  
		  if (modo == Ctes.K_MODO_CONSULTA) {
			  btnConfirmar.setEnabled(false);
		  }
		  
		  btnCancelar = new Button();	   
		  btnCancelar.setText("Cancelar");
		  btnCancelar.setSize("70px", "30px");	  	
		  
		  this.addButton(btnConfirmar);
		  this.addButton(btnCancelar);		  		  
	}

	private void crearGrilla() {
		  ColumnConfig<DTNotaSeguimiento, String> notaCol  	                = new ColumnConfig<DTNotaSeguimiento, String>(props.descripcion()   , 100, "Nota");
		  ColumnConfig<DTNotaSeguimiento, Date>   fechaSeguimientoCol 	    = new ColumnConfig<DTNotaSeguimiento, Date>(props.fechaSeguimiento(), 100, "Fecha");
		  ColumnConfig<DTNotaSeguimiento, String> usuarioCol 	            = new ColumnConfig<DTNotaSeguimiento, String>(props.usuario(), 100, "Usuario");
		  		  	      	 
	      List<ColumnConfig<DTNotaSeguimiento, ?>> l = new ArrayList<ColumnConfig<DTNotaSeguimiento, ?>>();
	      l.add(notaCol);
	      fechaSeguimientoCol.setCell(new com.google.gwt.cell.client.DateCell(DateTimeFormat.getFormat("dd/MM/yyyy")));	      
	      l.add(fechaSeguimientoCol);
	      l.add(usuarioCol);
	      	      	      	      
	      cm = new ColumnModel<DTNotaSeguimiento>(l);
	 
	      store = new ListStore<DTNotaSeguimiento>(props.key());	      	     	      
	      
	      grillaSeguimiento = new Grid<DTNotaSeguimiento>(store, cm);
	      
	      grillaSeguimiento.getView().setAutoExpandColumn(notaCol);
	      grillaSeguimiento.getView().setStripeRows(true);
	      grillaSeguimiento.getView().setColumnLines(true);
	      grillaSeguimiento.setBorders(false);
	 
	      grillaSeguimiento.setColumnReordering(true);
	      grillaSeguimiento.setStateful(true);
	      grillaSeguimiento.setStateId("Grilla");
	      grillaSeguimiento.setSize("100%", "100%");	     			
	}
	
	private void crearGrillaNotasImpresion() {
		  ColumnConfig<DTNotaImpresionPresupuesto, String> codigoCol      = new ColumnConfig<DTNotaImpresionPresupuesto, String>(propsNotaImpresion.codigoNotaImpresionXDefecto(),      100, "Codigo");
		  ColumnConfig<DTNotaImpresionPresupuesto, String> nombreCol      = new ColumnConfig<DTNotaImpresionPresupuesto, String>(propsNotaImpresion.nombre(),      100, "Nombre");
		  ColumnConfig<DTNotaImpresionPresupuesto, String> descripcionCol = new ColumnConfig<DTNotaImpresionPresupuesto, String>(propsNotaImpresion.descripcion(), 100, "Descripcion");
		  		  	      	 
	      List<ColumnConfig<DTNotaImpresionPresupuesto, ?>> l = new ArrayList<ColumnConfig<DTNotaImpresionPresupuesto, ?>>();
	      l.add(codigoCol);	      
	      l.add(nombreCol);
	      l.add(descripcionCol);	      	      	      	     
	      
	  	  cmNotasImpresion = new ColumnModel<DTNotaImpresionPresupuesto>(l);
	 
	      storeNotasImpresion = new ListStore<DTNotaImpresionPresupuesto>(propsNotaImpresion.key());	      	     	      
	      
	      grillaNotaImpresion = new Grid<DTNotaImpresionPresupuesto>(storeNotasImpresion, cmNotasImpresion);
	      
	      grillaNotaImpresion.getView().setAutoExpandColumn(descripcionCol);
	      grillaNotaImpresion.getView().setStripeRows(true);
	      grillaNotaImpresion.getView().setColumnLines(true);
	      grillaNotaImpresion.setBorders(false);
	 
	      grillaNotaImpresion.setColumnReordering(true);
	      grillaNotaImpresion.setStateful(true);
	      grillaNotaImpresion.setStateId("Grilla nota impresion");
	      grillaNotaImpresion.setSize("100%", "100%");	     			
	}
	
	
	private void crearGrillaRenglones () {
		  ColumnConfig<DTRenglonPresupuesto, Integer>  numeroCol  	     = new ColumnConfig<DTRenglonPresupuesto, Integer>(propsRenglonPresupuesto.numeroRenglon(), 100, "Numero");
		  ColumnConfig<DTRenglonPresupuesto, String>   nombreProductoCol = new ColumnConfig<DTRenglonPresupuesto, String>(propsRenglonPresupuesto.nombreProducto(), 100, "Producto");
		  ColumnConfig<DTRenglonPresupuesto, Double>   importeCol        = new ColumnConfig<DTRenglonPresupuesto, Double>(propsRenglonPresupuesto.importe(), 100, "Importe");
		  		  	      	 
	      List<ColumnConfig<DTRenglonPresupuesto, ?>> l = new ArrayList<ColumnConfig<DTRenglonPresupuesto, ?>>();
	      l.add(numeroCol);	      
	      l.add(nombreProductoCol);	      	      
	      final NumberFormat numberFormat = NumberFormat.getFormat("0.00");
	      importeCol.setAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
	      importeCol.setCell(new PropertyDisplayCell<Double>(new DoublePropertyEditor(numberFormat)));
	      l.add(importeCol);	      
	      	      	      	      
	      cmRenglones = new ColumnModel<DTRenglonPresupuesto>(l);
	 
	      storeRenglones = new ListStore<DTRenglonPresupuesto>(propsRenglonPresupuesto.key());	      	     	      
	      
	      grillaRenglones = new Grid<DTRenglonPresupuesto>(storeRenglones, cmRenglones);
	      
	      grillaRenglones.getView().setAutoExpandColumn(nombreProductoCol);
	      grillaRenglones.getView().setStripeRows(true);
	      grillaRenglones.getView().setColumnLines(true);
	      grillaRenglones.setBorders(false);
	 
	      grillaRenglones.setColumnReordering(true);
	      grillaRenglones.setStateful(true);
	      grillaRenglones.setStateId("Grilla");
	      grillaRenglones.setSize("100%", "100%");	      
	}

	private void cargarProximoCorrelativo() {
		manejadorCorrelativos.obtenerProximoCorrelativo(Ctes.K_CORR_PRES, new AsyncCallback<String>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}

			@Override
			public void onSuccess(String result) {
			   txtCodigo.setValue(result);
			}
		});		
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
       if(  changeInfo instanceof DTCliente ){  
	   seleccionCliente.txtCodigo.setValue(((DTCliente)changeInfo).getCodigo());
       txtNombreCliente.setValue(((DTCliente)changeInfo).getNombre());
       seleccionEdificio.setCodigoEntidadAux(((DTCliente)changeInfo).getCodigo());
       seleccionEdificio.txtCodigo.setValue("");
       txtNombreEdificio.setValue("");
       txtDireccionEdificio.setValue("");
       }
       else if (changeInfo instanceof DTEdificio){
          seleccionEdificio.txtCodigo.setValue(((DTEdificio)changeInfo).getCodigo());
          txtNombreEdificio.setValue(((DTEdificio)changeInfo).getNombre());
          txtDireccionEdificio.setValue(((DTEdificio)changeInfo).getDireccion());
       }
       else if (changeInfo instanceof DTUsuario) {
    	   seleccionUsuario.txtCodigo.setValue(((DTUsuario) changeInfo).getId());
    	   
    	   String nombre   = ((DTUsuario) changeInfo).getNombre();
    	   String apellido = ((DTUsuario) changeInfo).getApellido();
    	       	       	  
    	   txtNombreUsuario.setValue((nombre == null? "" : nombre) + " " + (apellido == null? "" : apellido));    	   
       }
       else if (changeInfo instanceof FormaDePago) {
     	  seleccionFormaDePago.txtCodigo.setValue(((FormaDePago) changeInfo).getCodigo());
     	  String nombre = ((FormaDePago) changeInfo).getNombre();
     	  txtNombreFormaDePago.setValue((nombre == null ? "" : nombre));
       }
       else if (changeInfo instanceof Garantia) {
    	  seleccionGarantia.txtCodigo.setValue(((Garantia) changeInfo).getCodigo());
      	  String nombre = ((Garantia) changeInfo).getNombre();
      	  txtNombreGarantia.setValue((nombre == null ? "" : nombre)); 
       }
       else if (changeInfo instanceof DTNotaSeguimiento) {
    	   if (modoNotaActual == Ctes.K_MODO_ALTA) {
    	      listaNotasSeguimiento.add(((DTNotaSeguimiento)changeInfo));
    	   }
    	  renumerarNotas();
          cargarGrilla();
       }
       else if (changeInfo instanceof DTNotaImpresionPresupuesto) {
    	  if (modoNotaActual == Ctes.K_MODO_ALTA) { 
    	     listaNotasImpresion.add((DTNotaImpresionPresupuesto) changeInfo);
    	  }    	  
    	  renumerarNotasImpresion();
    	  cargarGrillaNotasImpresion();    	  
       } 
       else if (changeInfo instanceof DTRenglonPresupuesto){    	   
    	   if (((DTRenglonPresupuesto) changeInfo).getNumeroRenglon() != null) {
    		   for (int i = 0; i < listaRenglones.size(); i ++) {
    			   DTRenglonPresupuesto unRenglon = listaRenglones.get(i);
    			   if (unRenglon.getNumeroRenglon() == ((DTRenglonPresupuesto) changeInfo).getNumeroRenglon()) {
    				   unRenglon.setImporte(((DTRenglonPresupuesto) changeInfo).getImporte());
    				   unRenglon.setDescripcion(((DTRenglonPresupuesto) changeInfo).getDescripcion());
    				   unRenglon.setProducto(((DTRenglonPresupuesto) changeInfo).getProducto());
    			   }
    		   }
    		   renumerarRenglones();
        	   actualizarTotal();
        	   cargarGrillaRenglones();
    	   }
    	   else {
    	   listaRenglones.add((DTRenglonPresupuesto) changeInfo);
    	   renumerarRenglones();
    	   actualizarTotal();
    	   cargarGrillaRenglones();
    	   }
       }
       else if (changeInfo instanceof DTGridPresupuesto) {
    	   String codigoDocumentoOrigen = "";
    	   String tipoDocumentoOrigen   = "";
    	   
    	   codigoDocumentoOrigen = ((DTGridPresupuesto)changeInfo).getId();
    	   tipoDocumentoOrigen   = ((DTGridPresupuesto)changeInfo).getTipoDoc();
    	   this.codigoSolOrigen.setValue(codigoDocumentoOrigen);
    	   this.tipoDocumentoOrigen.setValue(tipoDocumentoOrigen);
    	   cargarPantallaConSolicitudOrigen(codigoDocumentoOrigen, tipoDocumentoOrigen);
       }
	}
	
	private void cargarPantallaConSolicitudOrigen(String id, String tipoDocumento) {
       this.manejadorSolicitudes.obtenerPorCodigo(id, tipoDocumento, new AsyncCallback<DTSolicitudPresupuesto>() {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub			
		}

		@Override
		public void onSuccess(DTSolicitudPresupuesto result) {
		   if ( result != null ) {
			   cargarDatosDeSolicitudOrigen(result);	   			   
		   }						
		}
	});
		
	}


	private void renumerarNotasImpresion() {
		int j = 1;
		for (int i = 0; i < listaNotasImpresion.size(); i ++) { 
		   this.listaNotasImpresion.get(i).setNumeroNotaImpresionPresupuesto(j);
		   j ++;		   
		}	
	}

	private void cargarGrillaNotasImpresion() {
		grillaNotaImpresion.getStore().clear();
		grillaNotaImpresion.mask("Cargando notas...");		
		storeNotasImpresion.addAll(listaNotasImpresion);
		grillaNotaImpresion.reconfigure(storeNotasImpresion, cmNotasImpresion);
		grillaNotaImpresion.unmask();	
	}

	
	
	
	protected void cargarDatosDeSolicitudOrigen(DTSolicitudPresupuesto result) {
       this.txtDetalles.setValue(result.getDetalles());
       this.seleccionCliente.txtCodigo.setValue(result.getCliente().getCodigo());
       this.txtNombreCliente.setValue(result.getCliente().getNombre());
       this.seleccionEdificio.txtCodigo.setValue(result.getEdificio().getCodigo());
       this.txtNombreEdificio.setValue(result.getEdificio().getNombre());
       this.txtDireccionEdificio.setValue(result.getEdificio().getDireccion());       
       this.listaRenglones = result.getRenglonesSolicitud();
       renumerarRenglones();
	   actualizarTotal();
	   cargarGrillaRenglones();
	   
	   if (result.getTipoDocumento() == Ctes.K_TDOC_PRESUPUESTO) {
		    this.seleccionFormaDePago.txtCodigo.setValue(result.getFormaDePago().getCodigo());
			this.txtNombreFormaDePago.setValue(result.getFormaDePago().getNombre());					
			this.seleccionGarantia.txtCodigo.setValue(result.getGarantia().getCodigo());
			this.txtNombreGarantia.setValue(result.getGarantia().getNombre());			
			this.txtSuperficie.setValue(result.getSuperficie().doubleValue());			
			this.txtLeyesNIMontoMax.setValue(result.getLeyesSociales());		
			this.txtCostoAdicionalBano.setValue(result.getCostoBQ());			
			this.spinnerFieldEjecucionDias.setText(result.getTiempoEjecucionDias().toString());
			this.spinnerFieldEjecucionMeses.setText(result.getTiempoEjecucionMeses().toString());
			this.spinnerFieldEjecucionAnios.setText(result.getTiempoEjecucionAnios().toString());			
			this.spinnerFieldValidezDias.setText(result.getValidezDias().toString());
			this.spinnerFieldValidezMeses.setText(result.getValidezMeses().toString());
			this.spinnerFieldValidezAnios.setText(result.getValidezAnios().toString());
			this.listaNotasImpresion = result.getListaNotaImpresionPresupuesto();
			this.renumerarNotasImpresion();
			cargarGrillaNotasImpresion();			
	   }
	}

	private void cargarGrillaRenglones() {
       grillaRenglones.getStore().clear();
       grillaRenglones.mask("Cargando renglones...");
       storeRenglones.addAll(listaRenglones);
       grillaRenglones.reconfigure(storeRenglones, cmRenglones);
       grillaRenglones.unmask();
	}

	private void cargarGrilla(){
		grillaSeguimiento.getStore().clear();
		this.grillaSeguimiento.mask("Cargando notas...");
		store.addAll(listaNotasSeguimiento);
        grillaSeguimiento.reconfigure(store, cm);	
        grillaSeguimiento.unmask();				
	}
	
	public void cerrarme(){		
		this.hide();
		observableManager.notify(observableManager, null);		
	}
	
	private void renumerarRenglones(){
		int j = 1;
		for (int i = 0; i < listaRenglones.size(); i ++) { 
		   this.listaRenglones.get(i).setNumeroRenglon(j);
		   j ++;		   
		}
	}
	
	private void actualizarTotal(){
		double total = 0;
		for (int i = 0; i < listaRenglones.size(); i ++) { 
			   total += this.listaRenglones.get(i).getImporte();			   		  
	    }
		this.txtTotal.setValue(total);
	}
	
	final HideHandler hideHandler = new HideHandler() {
	      @Override
	      public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	        	Map<String, String> parametros = new HashMap();
	            parametros.put("CodigoPresupuesto", txtCodigo.getText());
	     		FormReportePendientes form = new FormReportePendientes(Ctes.K_REPORTE_PRESUPUESTO, parametros, Ctes.K_SUB_REPORTE_PRESUPUESTO);
	     		form.show();
	        }	        
	      }
	};
}
