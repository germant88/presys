package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.UsuarioProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuarios;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuariosAsync;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMUsuarios extends FormABMGenerico{

   private static final UsuarioProperties props = GWT.create(UsuarioProperties.class);	
   protected IRPCManejadorUsuariosAsync manejadorUsuarios;
   
   public FormABMUsuarios(){
	   super();
   }

   @Override
	protected void setTitulo() {
		this.setHeadingText("Usuarios");
	}
	
	@Override
	protected void crearManejadorRPC() {
		manejadorUsuarios = GWT.create(IRPCManejadorUsuarios.class);
	}
	
	@Override
	protected void crearGrilla(){	      
		  ColumnConfig<DTUsuario, String> idCol 	        = new ColumnConfig<DTUsuario, String>(props.id()   , 100, "Codigo");
		  ColumnConfig<DTUsuario, String> nombreCol         = new ColumnConfig<DTUsuario, String>(props.nombre()   , 100, "Nombre");
		  ColumnConfig<DTUsuario, String> apellidoCol       = new ColumnConfig<DTUsuario, String>(props.apellido() , 100, "Apellido");
		  
	      List<ColumnConfig<DTUsuario, ?>> l = new ArrayList<ColumnConfig<DTUsuario, ?>>();
	      l.add(idCol);
	      l.add(nombreCol);
	      l.add(apellidoCol);
	      	      	      	     
	      cm = new ColumnModel<DTUsuario>(l);	      
	 
	      store = new ListStore<DTUsuario>(props.key());	      
	      
	      grilla = new Grid<DTUsuario>(store, cm);	      	      
	      	      
          grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	      	      	      
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	      
	}
	
	@Override
	protected void ejecutarAgregar(){
		FormUsuario form = new FormUsuario(observableManager, Ctes.K_MODO_ALTA, null);			  
		form.show();	
	}
	
	@Override
	protected void cargarGrilla(){
		grilla.getStore().clear();
		this.grilla.mask("Cargando usuarios...");
		manejadorUsuarios.obtenerUsuarios(new AsyncCallback<ArrayList<DTUsuario>>() {

			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}

			@Override
			public void onSuccess(ArrayList<DTUsuario> result) {
				 store.addAll(result);
                 grilla.reconfigure(store, cm);	
                 grilla.unmask();				
			}
		});		
	}
	
	@Override
	protected void eliminarSeleccionado(){
		ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "�Realmente desea eliminar el usuario?");
	    box.addHideHandler(hadlerEliminarUsuario);	
	    ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
	    box.show();
	}
		
	 final HideHandler hadlerEliminarUsuario = new HideHandler() {
	     @Override
	     public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarUsuarioSeleccionado();
	        }	        
	     }
	 };
	 
	 private void eliminarUsuarioSeleccionado(){
	    DTUsuario usuarioSeleccionado;
		   
	    usuarioSeleccionado = (DTUsuario) grilla.getSelectionModel().getSelectedItem();
	   	    
	    eliminarUsuario(usuarioSeleccionado);            	    
	 }
	 
	 private void eliminarUsuario(DTUsuario usuarioSeleccionado) {
			manejadorUsuarios.eliminarUsuario(usuarioSeleccionado.getId(), new AsyncCallback() {

				@Override
				public void onSuccess(Object result) {
			       cargarGrilla();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					MessageBox box = new MessageBox("Error");												    												    												    
				    box.setMessage("Se produjo un error al intentar eliminar el usuario: " + caught.getMessage());
					box.show();									
				}			
			}); 
     }
	 
	 
	 @Override
	 protected void modificarSeleccionado(){
		 DTUsuario usuarioSeleccionado;
		   
		 usuarioSeleccionado = (DTUsuario) grilla.getSelectionModel().getSelectedItem();
		   
		   if (usuarioSeleccionado != null) {
		      modificarUsuario(usuarioSeleccionado);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	 }

	private void modificarUsuario(DTUsuario usuarioSeleccionado) {
		FormUsuario form = new FormUsuario(observableManager, Ctes.K_MODO_MODIFICACION, usuarioSeleccionado.getId());			  
	    form.show();
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
		cargarGrilla();		
	}
	
	@Override
	protected void buscar(){
		Integer buscarPor;
		   if (this.rbtnFiltrarCodigo.getValue() == true) {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargarndo usuarios...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorUsuarios.buscarUsuario(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTUsuario>>() {
			
			@Override
			public void onSuccess(ArrayList<DTUsuario> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();
	               ponerFocoEnFiltro();
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}	   
}
