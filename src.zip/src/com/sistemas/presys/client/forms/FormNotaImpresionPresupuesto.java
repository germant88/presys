package com.sistemas.presys.client.forms;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.gwtext.client.widgets.form.Label;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorNotasImpresionAsync;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.datatypes.DTTareaRenglon;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormNotaImpresionPresupuesto extends Window implements IObserver{

	    protected IRPCManejadorNotasImpresionAsync manejadorNotasImpresion;
		private SeleccionObjeto seleccionNotasImpresion;
		protected FieldSet fsNotaImpresion;
	    private DTNotaImpresion notaImpresionSeleccionada;    
		private ObservableManager observableManager;
		private ObservableManager observableManagerSeleccion;	
	    private TextField txtNombre;
		private TextArea  txtDescripcion;
		
		private Integer modo;
	    private Integer codigo;

	    private Button btnAceptar;
		private Button btnCancelar;
		private BorderLayoutContainer layout;
		private ContentPanel panelCentral;	
	    private VerticalLayoutContainer vlc;
	    
	    private DTNotaImpresionPresupuesto notaImpresionPresupuesto;
	
	
	    public FormNotaImpresionPresupuesto(ObservableManager xobsManager, Integer xmodo,
	    		DTNotaImpresionPresupuesto xnotaImpresionPresupuesto) {
			super();
			notaImpresionSeleccionada = null;
		  	observableManagerSeleccion = new ObservableManager();
			observableManagerSeleccion.addObserver(this);		
			observableManager          = xobsManager;
			modo                       = xmodo;
			notaImpresionPresupuesto                      = xnotaImpresionPresupuesto;					    	    
			CreateComponents();
			initEvents();
			if (modo == Ctes.K_MODO_MODIFICACION) {
				cargarPantallaConNotaImpresionPresupuesto();
	   }   		
}

private void cargarPantallaConNotaImpresionPresupuesto() {
	this.seleccionNotasImpresion.txtCodigo.setValue(notaImpresionPresupuesto.getNotaImpresionXDefecto().getCodigo());		
	this.txtNombre.setValue(notaImpresionPresupuesto.getNotaImpresionXDefecto().getNombre());
	notaImpresionSeleccionada = notaImpresionPresupuesto.getNotaImpresionXDefecto();
	this.txtDescripcion.setValue(notaImpresionPresupuesto.getDescripcion());	
}

private void initEvents() {
  btnAceptar.addClickHandler(new ClickHandler() {			
		@Override
		public void onClick(ClickEvent event) {
			if ((notaImpresionSeleccionada == null) || (txtDescripcion.getValue() == null)) {
       	     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe ingresar los datos necesarios para agregar la nota de impresion");
				 box.show();
          	}
          else {						
			if (modo == Ctes.K_MODO_MODIFICACION) {
				notaImpresionPresupuesto.setDescripcion(txtDescripcion.getValue());					
				notaImpresionPresupuesto.setNotaImpresionXDefecto(notaImpresionSeleccionada);				    				    
			    observableManager.notify(observableManager, notaImpresionPresupuesto);
			}
			else {   
	        	DTNotaImpresionPresupuesto notaImpresionPresupuestoNueva = new DTNotaImpresionPresupuesto();
	        	notaImpresionPresupuestoNueva.setNotaImpresionXDefecto(notaImpresionSeleccionada);		        	
	        	notaImpresionPresupuestoNueva.setDescripcion(txtDescripcion.getValue());           	           			        	
	           	
	           	observableManager.notify(observableManager, notaImpresionPresupuestoNueva);
			}
          	cerrarme();	           	
          }
		}
	});		
}

private void CreateComponents() {
	   this.setMaximizable(true);
	   this.setModal(true);		
	   this.setHeadingText("Ingreso de notas de impresion");		 
	   this.setSize("500px", "430px");	   	   	
	   		   			   
	   layout = new BorderLayoutContainer();
		   		   							   
	   panelCentral = new ContentPanel();	  
	   panelCentral.setSize("100%", "100%");    	
	   panelCentral.setHeaderVisible(false);
	   
	   VerticalLayoutContainer vlcNotasImpresion = new VerticalLayoutContainer();
		       
	  fsNotaImpresion = new FieldSet();
	  fsNotaImpresion.setHeadingText("Nota impresion");
	  fsNotaImpresion.setCollapsible(true);
	  fsNotaImpresion.setSize("310px", "120px");
	  fsNotaImpresion.setPosition(15, 10);
      
      txtNombre = new TextField();
      txtNombre.setReadOnly(true);
              
      seleccionNotasImpresion = new SeleccionObjeto(observableManagerSeleccion, 8);        
      vlcNotasImpresion.add(new FieldLabel(seleccionNotasImpresion, "Codigo"));
      vlcNotasImpresion.add(new FieldLabel(txtNombre, "Nombre"));
      
      fsNotaImpresion.add(vlcNotasImpresion);	       	       	       
      
      Label lblDescripcion = new Label();
      lblDescripcion.setText("Descripcion:");
      lblDescripcion.setPosition(15,40);
      
      txtDescripcion = new TextArea();
	   txtDescripcion.setSize("450px", "100px");
	   txtDescripcion.setPosition(15, 50);
	   
	   vlc = new VerticalLayoutContainer();
	   vlc.setHeight("100%");
	   
	   vlc.add(fsNotaImpresion);		   
	   vlc.add(lblDescripcion);
	   vlc.add(txtDescripcion);
	   
	   panelCentral.add(vlc);
	   
	   layout.setCenterWidget(panelCentral);
	   		  
	   btnAceptar = new Button();	   
	   btnAceptar.setText("Aceptar");
	   btnAceptar.setSize("70px", "30px");
 
	   btnCancelar = new Button();	   
	   btnCancelar.setText("Cancelar");
	   btnCancelar.setSize("70px", "30px");	  	
 
	   this.add(layout);
	   this.addButton(btnAceptar);
	   this.addButton(btnCancelar); 
	
}

protected void cerrarme() {
	this.hide();
}
	    
	    
	    
	@Override
	public void update(Object theObserved, Object changeInfo) {
		  if (changeInfo instanceof DTNotaImpresion) {
	         seleccionNotasImpresion.txtCodigo.setValue(((DTNotaImpresion)changeInfo).getCodigo());
		     txtNombre.setValue(((DTNotaImpresion)changeInfo).getNombre());
		     txtDescripcion.setValue(((DTNotaImpresion) changeInfo).getDescripcion());
		     notaImpresionSeleccionada = (DTNotaImpresion)changeInfo;
	      }		
	}

	
}
