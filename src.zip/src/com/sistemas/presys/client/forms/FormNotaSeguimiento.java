package com.sistemas.presys.client.forms;

import java.util.Date;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.DateField;
import com.sencha.gxt.widget.core.client.form.DateTimePropertyEditor;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorUtiles;
import com.sistemas.presys.client.rpc.IRPCManejadorUtilesAsync;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormNotaSeguimiento extends Window{
	
	private final IRPCManejadorUtilesAsync manejadorUtiles = GWT
   			.create(IRPCManejadorUtiles.class);
	
	private DateField dtfFechaIngreso;
	private TextArea  txtSituacion;
	private TextArea  txtNota;
	private DateField dtfFechaSeguimiento;
	
	private ObservableManager observableManager;
    private Integer modo;
    private DTNotaSeguimiento nota;

    private Button btnAceptar;
	private Button btnCancelar;
	private BorderLayoutContainer layout;
	private ContentPanel panelCentral; 
    
    private VerticalLayoutContainer vlc;
	
	public FormNotaSeguimiento(ObservableManager xobsManager, Integer xmodo, DTNotaSeguimiento xnota){
		observableManager = xobsManager;
		modo              = xmodo;
		nota              = xnota;
		createComponents();	
		initEvents();
		if ((modo == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {		    
			cargarPantalla();         				
		}
	}
	
	private void cargarPantalla() {
		if (nota.getFechaIngreso() != null) {
		   this.dtfFechaIngreso.setValue(nota.getFechaIngreso());
		}
		if (nota.getSituacion() != null) {
		   this.txtSituacion.setText(nota.getSituacion());
		}
		if (nota.getDescripcion() != null) {
		   this.txtNota.setText(nota.getDescripcion());
		}
		if (nota.getFechaSeguimiento() != null) {
		  this.dtfFechaSeguimiento.setValue(nota.getFechaSeguimiento());
		}
	}
	
	private void initEvents() {
		btnCancelar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
			   cerrarme();				
			}
		});		
		
		btnAceptar.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {				
				obtenerUsuarioLogueadoYCargarNota();							
			}
		});
	}

	private void createComponents(){
		 this.setMaximizable(true);
		 this.setModal(true);
		 
		 this.setHeadingText("Nota de seguimiento");
		 
		 this.setSize("600px", "700px");
		 
		 layout = new BorderLayoutContainer();
		   
		 this.add(layout);
		 
		 panelCentral = new ContentPanel();	  
		 panelCentral.setSize("100%", "100%");
		 panelCentral.setHeaderVisible(false);
		   
		 vlc = new VerticalLayoutContainer();
		 vlc.setHeight("100%");

		 panelCentral.add(vlc);
		   		 
		 dtfFechaIngreso = new DateField();	 		 		 
		 dtfFechaIngreso.setPropertyEditor(new DateTimePropertyEditor("dd/MM/yyyy"));
		 dtfFechaIngreso.setReadOnly(true);
		 dtfFechaIngreso.setValue(new Date());
		 
		 txtSituacion = new TextArea();
		 txtSituacion.setSize("450px", "100px");
		 
		 txtNota = new TextArea();
		 txtNota.setSize("450px", "100px");
		 
		 dtfFechaSeguimiento = new DateField();	 		 		 
		 dtfFechaSeguimiento.setPropertyEditor(new DateTimePropertyEditor("dd/MM/yyyy"));

		 vlc.add(new FieldLabel(dtfFechaIngreso,   "Fecha ingreso"), new VerticalLayoutData(100, 30, new Margins(10,1,1,15)));		 		 
		 vlc.add(new FieldLabel(txtSituacion,   "Situacion"), new VerticalLayoutData(100, 100, new Margins(10,1,1,15)));
		 vlc.add(new FieldLabel(txtNota,   "Nota"), new VerticalLayoutData(100, 100, new Margins(10,1,1,15)));
		 vlc.add(new FieldLabel(dtfFechaSeguimiento,   "Fecha alerta"), new VerticalLayoutData(100, 30, new Margins(10,1,1,15)));
		   
		 layout.setCenterWidget(panelCentral);
	  
		 btnAceptar = new Button();	   
		 btnAceptar.setText("Aceptar");
		 btnAceptar.setSize("70px", "30px");
	  
		 btnCancelar = new Button();	   
		 btnCancelar.setText("Cancelar");
		 btnCancelar.setSize("70px", "30px");	  	
	  
		 this.addButton(btnAceptar);
		 this.addButton(btnCancelar);
	}


	private void obtenerUsuarioLogueadoYCargarNota() {
	       manejadorUtiles.obtenerUsuarioLogueado(new AsyncCallback<String>() {
			
			@Override
			public void onSuccess(String result) {
				if (modo == Ctes.K_MODO_MODIFICACION) {
					
					nota.setUsuario(result);
					nota.setSituacion(txtSituacion.getText());
					nota.setDescripcion(txtNota.getText());
					nota.setFechaSeguimiento(dtfFechaSeguimiento.getValue());
									
					observableManager.notify(observableManager, nota);						
				}
				else {
					
					DTNotaSeguimiento nota = new DTNotaSeguimiento();
					nota.setSituacion(txtSituacion.getText());
					nota.setDescripcion(txtNota.getText());
					nota.setFechaSeguimiento(dtfFechaSeguimiento.getValue());
					
					nota.setUsuario(result);
					
					observableManager.notify(observableManager, nota);	
				}				
				
				cerrarme();  						         
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub				
			}
		});	
	}	       
	       	     	
	private void cerrarme(){
		this.hide();
	}
}
