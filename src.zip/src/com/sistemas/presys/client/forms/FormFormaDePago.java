package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorFormasPagos;
import com.sistemas.presys.client.rpc.IRPCManejadorFormasPagosAsync;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.model.FormaDePago;

public class FormFormaDePago extends FormEntidadGenerico{
    protected IRPCManejadorFormasPagosAsync manejadorFormasDePagos;
	private TextField txtNombre;
	private TextArea  txtDescripcion;

	public FormFormaDePago(ObservableManager xobsManager, Integer xmodo,
			String xcodigo) {
		super(xobsManager, xmodo, xcodigo);       
	}
	
	@Override
	protected void crearManejadorRPC() {
		 manejadorFormasDePagos = GWT.create(IRPCManejadorFormasPagos.class);
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Forma de pago");		
	}	
	
	@Override
	protected String  obtenerCodigoCorrelativo(){
		return "";
	}
	
	@Override
	protected void createComponents(){
		super.createComponents();
						
		txtNombre = new TextField();
	    vlc.add(new FieldLabel(txtNombre, "Nombre"),new VerticalLayoutData(300, 50, new Margins(30,1,1,15)));
	    
	    txtDescripcion = new TextArea();
	    vlc.add(new FieldLabel(txtDescripcion, "Descripcion"),new VerticalLayoutData(450, 150, new Margins(30,1,1,15)));
	    						
		txtNombre.focus();
		this.setFocusWidget(txtNombre);
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	protected void agregarEntidad(){
		manejadorFormasDePagos.agregar(txtCodigo.getValue(), txtNombre.getValue(), txtDescripcion.getValue(), new AsyncCallback() {

			@Override
			public void onFailure(Throwable caught) {
				 MessageBox box = new MessageBox("Error");												    												    												    
			     box.setMessage("Se produjo un error al intentar agregar la forma de pago: " + caught.getMessage());
				 box.show();					
			}

			@Override
			public void onSuccess(Object result) {
		        cerrarme();					
			}
		});	
	}
	
	@Override
	protected void modificarEntidad() {
		manejadorFormasDePagos.modificar(txtCodigo.getValue() , txtNombre.getValue(), txtDescripcion.getValue(), new AsyncCallback<Void>() {

					@Override
					public void onFailure(
							Throwable caught) {
						 MessageBox box = new MessageBox("Error");												    												    												    
					     box.setMessage("Se produjo un error al intentar modificar la forma de pago: " + caught.getMessage());
						 box.show();											
					}

					@Override
					public void onSuccess(Void result) {
						cerrarme();  						
					}
				});
    }
	
	@Override
	protected void cargarPantalla(String xcodigo) {
		manejadorFormasDePagos.obtenerFormaDePagoPorCodigo(xcodigo, new AsyncCallback<FormaDePago>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(FormaDePago result) {
				cargarPantallaConObjeto(result);				
			}
		});     			
    }

	@Override
    protected void cargarPantallaConObjeto(Object entidad) {
       FormaDePago formaDePago = (FormaDePago) entidad;
		
	   this.txtCodigo.setValue(String.valueOf(formaDePago.getCodigo()));
 	   this.txtNombre.setValue(formaDePago.getNombre() != null ? formaDePago.getNombre() : "");
 	   this.txtDescripcion.setValue(formaDePago.getDescripcion() != null ? formaDePago.getDescripcion() : "");        	    	   	   
    }
}



