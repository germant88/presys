package com.sistemas.presys.client.forms;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.core.client.util.ToggleGroup;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.form.Radio;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMGenerico extends Window implements IObserver {
	
	//protected final IRPCManejadorProductosAsync manejadorProductos = GWT.create(IRPCManejadorProductos.class);
	
	protected Button btnAgregar;
	protected Button btnModificar;
	protected Button btnEliminar;
	protected Button btnBuscar;
	protected Radio rbtnFiltrarCodigo;
	protected Radio rbtnFiltrarNombre;
	protected ToggleGroup tgFiltrarPor;
	protected TextField txtFiltro;
	
	protected ListStore store;
	protected ColumnModel cm;
		
	protected Grid grilla;
	
	protected ObservableManager observableManager;
	
	public FormABMGenerico() {
	   super();
	   observableManager = new ObservableManager();
	   observableManager.addObserver(this);			   
	   crearManejadorRPC();
	   createComponents();	   
	   events();
	   this.setFocusWidget(txtFiltro);
	   cargarGrilla();	   
	}
	
	protected void crearManejadorRPC() {
		// 		
	}

	public void ponerFocoEnFiltro(){
		this.setFocusWidget(txtFiltro);		
		txtFiltro.setCursorPos(txtFiltro.getText().length());
		txtFiltro.focus();
	}

	protected void createComponents() {
	   
	   this.setMaximizable(true);
	   this.setModal(true);
	   setTitulo();
	   this.setSize("900px", "550px");	   
	   
	   BorderLayoutContainer layout = new BorderLayoutContainer();
	 
	   this.add(layout);
	   
	   crearGrilla();
	   
	   // NORTH
	   ContentPanel panelSuperior = new ContentPanel();
	   panelSuperior.setHeaderVisible(false);

	   HorizontalPanel hp = new HorizontalPanel();
	   hp.setWidth("300px");
	   
	   rbtnFiltrarCodigo = new Radio();
	   rbtnFiltrarNombre = new Radio();
	   rbtnFiltrarCodigo.setBoxLabel("Codigo");
	   rbtnFiltrarNombre.setBoxLabel("Nombre");
	   rbtnFiltrarNombre.setValue(true);
	   tgFiltrarPor = new ToggleGroup();
	   tgFiltrarPor.add(rbtnFiltrarCodigo);
	   tgFiltrarPor.add(rbtnFiltrarNombre);
	   
	   txtFiltro = new TextField();
	   txtFiltro.setWidth("250px");
	   
	   btnBuscar = new Button();
	   btnBuscar.setText("Buscar");
	   btnBuscar.setSize("70px", "30px");
	   
	   hp.add(rbtnFiltrarCodigo);
	   hp.add(rbtnFiltrarNombre);
	   hp.add(txtFiltro);
	   hp.add(btnBuscar);
	   
	   hp.setSpacing(15);
	   	   	   
	   panelSuperior.add(hp, new MarginData(0, 350, 0, 0));
	    
	   layout.setNorthWidget(panelSuperior, new BorderLayoutData(50));
	 
	   // CENTER	   
	   ContentPanel panelCentral = new ContentPanel();
	   panelCentral.setHeaderVisible(false);
	   panelCentral.add(grilla);
	   layout.setCenterWidget(panelCentral);
	   
	   
	   btnAgregar = new Button();	   
	   btnAgregar.setText("Agregar");
	   btnAgregar.setSize("100%", "20px");
	   
	   btnModificar = new Button();
	   btnModificar.setText("Modificar");
	   btnModificar.setSize("100%", "20px");
	   
	   btnEliminar  = new Button();
	   btnEliminar.setText("Eliminar");
	   btnEliminar.setSize("100%", "20px");
	   
	   //RIGHT
	   VerticalLayoutContainer panelDerecha = new VerticalLayoutContainer();
	
	   
	   panelDerecha.add(btnAgregar, new VerticalLayoutData( 100, 100, new Margins(50,1,1,5)));
	   panelDerecha.add(btnModificar, new VerticalLayoutData( 100, 50, new Margins(1,1,1,5)));
	   panelDerecha.add(btnEliminar, new VerticalLayoutData( 100, 50, new Margins(1,1,1,5)));
	   layout.setEastWidget(panelDerecha, new BorderLayoutData(90));	   
	}
	
	
	protected void setTitulo() {
		//this.setHeadingText("Clientes");	   
	}

	protected void events() {	
		btnAgregar.addClickHandler(new ClickHandler() {			
			@Override
			public void onClick(ClickEvent event) {
			  
				//FormCliente form = new FormCliente(observableManager, Ctes.K_MODO_ALTA, null);
			   			  
			    //form.show();
			    			    
			    ejecutarAgregar();
			}
		});
		
		btnEliminar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				
				if (grilla.getSelectionModel().getSelectedItem() != null) {
					eliminarSeleccionado();	
				}
				else {
					errorDebeSeleccionarUnElemento();						
				}				
			}
		});
		
		btnModificar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {				
			   modificarSeleccionado();	
			}

		});				
		
		btnBuscar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
               //buscarClientes();	
               buscar();
			}
		});
		
		grilla.addCellDoubleClickHandler(new CellDoubleClickHandler() {
			
			@Override
			public void onCellClick(CellDoubleClickEvent event) {
				modificarSeleccionado();				
			}
		}); 
		
		 txtFiltro.addKeyDownHandler(new KeyDownHandler() {
			
			@Override
			public void onKeyDown(KeyDownEvent event) {
				 if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {				   
					 buscar();	
					 ponerFocoEnFiltro();					 
				 }				
			}
		});
	}
	
	protected void buscar() {
		// TODO Auto-generated method stub
		
	}

	protected void eliminarSeleccionado() {
		// TODO Auto-generated method stub
		
	}

	protected void buscarClientes() {
       Integer buscarPor;
	   if (this.rbtnFiltrarCodigo.getValue() == true) {
          	  buscarPor = Ctes.K_BUSCAR_X_COD;
       }
	   else {
		   buscarPor = Ctes.K_BUSCAR_X_NOM;
	   }
	   
	   grilla.getStore().clear();
	   this.grilla.mask("Cargarndo clientes...");
	   this.btnBuscar.setEnabled(false);
	   
	   /*manejadorClientes.buscarCliente(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTCliente>>() {
		
		@Override
		public void onSuccess(ArrayList<DTCliente> result) {
			   store.addAll(result);
               grilla.reconfigure(store, cm);	
               grilla.unmask();
               ponerFocoEnFiltro();
               btnBuscar.setEnabled(true);
		}
		
		@Override
		public void onFailure(Throwable caught) {
			 grilla.unmask();
			 btnBuscar.setEnabled(true);
		}
	});*/
	   
	}

	protected void modificarSeleccionado() {
		/* DTCliente clienteSeleccionado;
		   
		   clienteSeleccionado = grilla.getSelectionModel().getSelectedItem();
		   
		   if (clienteSeleccionado != null) {
		      modificarCliente(clienteSeleccionado);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }*/		
	}

	private void modificarCliente(DTCliente clienteSeleccionado) {
	   FormCliente form = new FormCliente(observableManager, Ctes.K_MODO_MODIFICACION, clienteSeleccionado.getCodigo());			  
       form.show();			
	}

	protected void eliminarClienteSeleccionado() {
	   /*DTCliente clienteSeleccionado;
	   
	   clienteSeleccionado = grilla.getSelectionModel().getSelectedItem();
	   
	   if (clienteSeleccionado != null) {
	      eliminarCliente(clienteSeleccionado);            
	   }
	   else {		   
		   errorDebeSeleccionarUnElemento();		   
	   }*/
	}

	
	private void eliminarCliente(DTCliente clienteSeleccionado) {
		/*manejadorClientes.eliminarCliente(clienteSeleccionado.getCodigo(), new AsyncCallback() {

			@Override
			public void onSuccess(Object result) {
		       cargarGrilla();				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}			
		});*/ 
	}

	protected void crearGrilla(){	      
        
	}

	protected void cargarGrilla() {		
	//	
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
		cargarGrilla();		
	}

	public void errorDebeSeleccionarUnElemento() {
        //
	}
	
	protected void ejecutarAgregar(){
		//
	}
	
	 final HideHandler hideHandler = new HideHandler() {
	      @Override
	      public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarSeleccionado();
	        }	        
	      }
	    };
}
