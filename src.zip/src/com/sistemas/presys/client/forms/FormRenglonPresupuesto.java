package com.sistemas.presys.client.forms;


import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.HasDirection.Direction;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gwtext.client.widgets.form.Label;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.TabPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FieldSet;
import com.sencha.gxt.widget.core.client.form.NumberField;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor.DoublePropertyEditor;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.componentes.SeleccionObjeto;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.TareaRenglonProperties;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTTareaRenglon;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormRenglonPresupuesto extends Window implements IObserver{
	
	private static final TareaRenglonProperties props = GWT.create(TareaRenglonProperties.class);
	
	private SeleccionObjeto seleccionProducto;
	private TextArea        txtDescripcion;	
	protected FieldSet      fsProducto;
    protected TextField     txtProducto;    
    protected TextField     txtNombreProducto;
    protected NumberField<Double>   txtImporte;
	
    private DTProducto productoSeleccionado;
    
	private ObservableManager observableManager;
	private ObservableManager observableManagerSeleccion;
	private ObservableManager observableManagerTareas;
	
    private Integer modo;
    private Integer codigo;

    private Button btnAceptar;
	private Button btnCancelar;
	private BorderLayoutContainer layout;
	private ContentPanel panelCentral;
	private DTRenglonPresupuesto renglon;
	
	private TabPanel tabPanel;
    
    private VerticalLayoutContainer vlc;
    
    protected BorderLayoutContainer layoutTareas;
    
    private Grid<DTTareaRenglon> grillaTareas;
    
	private ListStore<DTTareaRenglon> storeGrillaTareas;
	private ColumnModel<DTTareaRenglon> cmGrillaTareas;
	
	private ArrayList<DTTareaRenglon> listaTareasRenglon;
	    
    private Button btnNuevaTarea;
    private Button btnEditarTarea;
    private Button btnEliminarTarea;
    
    public FormRenglonPresupuesto(ObservableManager xobsManager, Integer xmodo, DTRenglonPresupuesto xrenglon){
    	super();
		productoSeleccionado = null;
    	observableManagerSeleccion = new ObservableManager();
		observableManagerSeleccion.addObserver(this);
		observableManagerTareas = new ObservableManager();
		observableManagerTareas.addObserver(this);		
		listaTareasRenglon         = new ArrayList<DTTareaRenglon>();
		observableManager          = xobsManager;		
		modo                       = xmodo;
		renglon                    = xrenglon;
		
    	CreateComponents();
    	initEvents();
    			 
    	if ((modo == Ctes.K_MODO_MODIFICACION) || (modo == Ctes.K_MODO_CONSULTA)) {
    		cargarPantallaConRenglon();
    	}    	
    	
    	if (modo == Ctes.K_MODO_CONSULTA) {
    		deshabilitarCampos();
    	}
    }
    
   private void deshabilitarCampos() {
      fsProducto.setEnabled(false);
      txtNombreProducto.setEnabled(false);
      txtImporte.setEnabled(false);
      txtImporte.setReadOnly(true);
      txtDescripcion.setEnabled(false);
      btnNuevaTarea.setEnabled(false);
      btnEditarTarea.setEnabled(false);
      btnEliminarTarea.setEnabled(false);      
	}

private void cargarPantallaConRenglon() {
		this.seleccionProducto.txtCodigo.setValue(renglon.getProducto().getCodigo());		
		this.txtNombreProducto.setValue(renglon.getProducto().getNombre());
		productoSeleccionado = renglon.getProducto();
		this.txtImporte.setValue(renglon.getImporte());
		this.txtDescripcion.setValue(renglon.getDescripcion());
		
		listaTareasRenglon.clear();
		for (int i = 0; i < renglon.getListaTareasRenglon().size(); i ++) {
			listaTareasRenglon.add(renglon.getListaTareasRenglon().get(i));
		}
		
		cargarGrillaTareasRenglon();
	}

private void initEvents() {
      btnAceptar.addClickHandler(new ClickHandler() {		
		@Override
		public void onClick(ClickEvent event) {
           if ((productoSeleccionado == null) || (txtImporte.getValue() == null)) {
        	     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe ingresar los datos necesarios para agregar el renglon");
				 box.show();
           	}
           else {						
			if (modo == Ctes.K_MODO_MODIFICACION) {
			    renglon.setImporte(txtImporte.getValue());
			    renglon.setDescripcion(txtDescripcion.getValue());
			    renglon.setProducto(productoSeleccionado);
			    renglon.getListaTareasRenglon().clear();
			    renglon.setListaTareasRenglon(listaTareasRenglon);
			    
			    observableManager.notify(observableManager, renglon);
			}
			else if (modo == Ctes.K_MODO_CONSULTA) {
				cerrarme();
			}
			else {   
	        	DTRenglonPresupuesto renglonNuevo = new DTRenglonPresupuesto();
				renglonNuevo.setImporte(txtImporte.getValue());
				renglonNuevo.setDescripcion(txtDescripcion.getValue());           	           	
				renglonNuevo.setProducto(productoSeleccionado);
	           	renglonNuevo.setListaTareasRenglon(listaTareasRenglon);
								
	           	observableManager.notify(observableManager, renglonNuevo);
			}
           	cerrarme();
           }
		}
	});
	   
      btnCancelar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
           cerrarme();			
		}
	});
      
      btnNuevaTarea.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
           FormTareaRenglon form = new FormTareaRenglon(observableManagerTareas, Ctes.K_MODO_ALTA, null);
           form.show();
		}
	});
      
      btnEditarTarea.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
           if (!(grillaTareas.getSelectionModel().getSelectedItems().size() > 0)) { 
        	   MessageBox box = new MessageBox("Atencion");												    												    												    
			   box.setMessage("Debe seleccionar una tarea para poder modificarla");
			   box.show();        	           	   
           }
           else {
              FormTareaRenglon form = new FormTareaRenglon(observableManagerTareas, Ctes.K_MODO_MODIFICACION, grillaTareas.getSelectionModel().getSelectedItem());
              form.show();
           }
		}
	});
      
     btnEliminarTarea.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
			if (!(grillaTareas.getSelectionModel().getSelectedItems().size() > 0)) {
			     MessageBox box = new MessageBox("Atencion");												    												    												    
			     box.setMessage("Debe seleccionar al menos una tarea para eliminar");
				 box.show();
		   }
		   else {
			  eliminarTareas(grillaTareas.getSelectionModel().getSelectedItems());   
		   }			
		}
	});
      
   }

private void eliminarTareas(List<DTTareaRenglon> selectedItems){
	  for (DTTareaRenglon renglonAEliminar : selectedItems) {
   	   listaTareasRenglon.remove(renglonAEliminar);
      }
      renumerarTareas();	   
	  cargarGrillaTareasRenglon();
}

protected void cerrarme() {
	this.hide();
}

private void CreateComponents(){	   
	   this.setMaximizable(true);
	   this.setModal(true);		
	   this.setHeadingText("Ingreso de renglon de presupuesto");		 
	   this.setSize("500px", "430px");	   	   	
	   
	   tabPanel = new TabPanel();
       tabPanel.setSize("100%", "100%");
		   
		layout = new BorderLayoutContainer();
		   
		this.add(tabPanel);
		
		tabPanel.add(layout, "General");	
	   
	   panelCentral = new ContentPanel();	  
	   panelCentral.setSize("100%", "100%");    	
	   panelCentral.setHeaderVisible(false);
	   
	   VerticalLayoutContainer vlcProducto = new VerticalLayoutContainer();
		       
	   fsProducto = new FieldSet();
       fsProducto.setHeadingText("Producto");
       fsProducto.setCollapsible(true);
       fsProducto.setSize("310px", "120px");
       fsProducto.setPosition(15, 10);
       
       txtNombreProducto = new TextField();
       txtNombreProducto.setReadOnly(true);
               
       seleccionProducto = new SeleccionObjeto(observableManagerSeleccion, 3);        
       vlcProducto.add(new FieldLabel(seleccionProducto, "Codigo"));
       vlcProducto.add(new FieldLabel(txtNombreProducto, "Nombre"));
       
       fsProducto.add(vlcProducto);
       
       txtImporte = new NumberField<Double>(new DoublePropertyEditor());       
       txtImporte.setFormat(NumberFormat.getFormat("$#,##0.00"));
       txtImporte.setStyleName("inputImportes");
       txtImporte.setDirection(Direction.RTL); // Alinear a la derecha
       
       FieldLabel flblImporte = new FieldLabel(txtImporte, "Importe");
       flblImporte.setPosition(15, 25);
       
       Label lblDescripcion = new Label();
       lblDescripcion.setText("Descripcion:");
       lblDescripcion.setPosition(15,40);
       
       txtDescripcion = new TextArea();
	   txtDescripcion.setSize("450px", "100px");
	   txtDescripcion.setPosition(15, 50);
	   
	   vlc = new VerticalLayoutContainer();
	   vlc.setHeight("100%");
	   
	   vlc.add(fsProducto);
	   vlc.add(flblImporte);
	   vlc.add(lblDescripcion);
	   vlc.add(txtDescripcion);
	   
	   panelCentral.add(vlc);
	   
	   layout.setCenterWidget(panelCentral);
	   
	   // TAB TAREAS
	   
	   layoutTareas = new BorderLayoutContainer();
	   
	   btnNuevaTarea = new Button();
	   btnNuevaTarea.setText("Agregar");
	   btnNuevaTarea.setSize("60px", "20px");
		
	   btnEditarTarea = new Button();
	   btnEditarTarea.setText("Editar");
	   btnEditarTarea.setSize("60px", "20px");
	   
	   btnEliminarTarea = new Button();
	   btnEliminarTarea.setText("Eliminar");
	   btnEliminarTarea.setSize("60px", "20px");
	   
	   HorizontalPanel hpCabezalTareasEtiqueta = new HorizontalPanel();
       Label etiquetaTitulo = new Label("Ingrese las tareas asociadas al renglon");
	   hpCabezalTareasEtiqueta.add(etiquetaTitulo);
       
	   HorizontalPanel hpCabezalTareasBotones = new HorizontalPanel();
	   hpCabezalTareasBotones.add(btnNuevaTarea);
	   hpCabezalTareasBotones.add(btnEditarTarea);
	   hpCabezalTareasBotones.add(btnEliminarTarea);
	   hpCabezalTareasBotones.setHeight("30px");
	   hpCabezalTareasBotones.setSpacing(5);
	   
       VerticalPanel vpCabezalTareas = new VerticalPanel();
	   vpCabezalTareas.add(hpCabezalTareasEtiqueta);
	   vpCabezalTareas.add(hpCabezalTareasBotones);
	   
	   vpCabezalTareas.setHeight("50px");
	  
 	   layoutTareas.setNorthWidget(vpCabezalTareas, new BorderLayoutData(50));
	  
	   crearGrillaTareas();		  
	  		  		  
 	   layoutTareas.setCenterWidget(grillaTareas);
	  
 	   tabPanel.add(layoutTareas, "Tareas");
		  
	   btnAceptar = new Button();	   
	   btnAceptar.setText("Aceptar");
	   btnAceptar.setSize("70px", "30px");
  
	   btnCancelar = new Button();	   
	   btnCancelar.setText("Cancelar");
	   btnCancelar.setSize("70px", "30px");	  	
  
	   this.addButton(btnAceptar);
	   this.addButton(btnCancelar);  	 	   
   }

@Override
public void update(Object theObserved, Object changeInfo) {
	  if (changeInfo instanceof DTProducto) {
         seleccionProducto.txtCodigo.setValue(((DTProducto)changeInfo).getCodigo());
	     txtNombreProducto.setValue(((DTProducto)changeInfo).getNombre());
	     productoSeleccionado = (DTProducto)changeInfo;
      }	
	  if  (changeInfo instanceof DTTareaRenglon) {	    
		 listaTareasRenglon.add((DTTareaRenglon) changeInfo);
   	     renumerarTareas();   	     
   	     cargarGrillaTareasRenglon();
	  }
}
    
    
private void renumerarTareas() {
	int j = 1;
	for (int i = 0; i < listaTareasRenglon.size(); i ++) { 
	   this.listaTareasRenglon.get(i).setNumeroTareaRenglon(j);
	   j ++;		   
	}	
}

private void cargarGrillaTareasRenglon() {
	grillaTareas.getStore().clear();
	grillaTareas.mask("Cargando tareas...");
	storeGrillaTareas.addAll(listaTareasRenglon);
	grillaTareas.reconfigure(storeGrillaTareas, cmGrillaTareas);
    grillaTareas.unmask();	
}

private void crearGrillaTareas() {	
	  ColumnConfig<DTTareaRenglon, String> codigoCol  	   = new ColumnConfig<DTTareaRenglon, String>(props.codigoTareaXDefecto(), 100, "Codigo");
	  ColumnConfig<DTTareaRenglon, String> nombreCol       = new ColumnConfig<DTTareaRenglon, String>(props.nombre() , 100, "Nombre");
	  ColumnConfig<DTTareaRenglon, String> descripcionCol  = new ColumnConfig<DTTareaRenglon, String>(props.descripcion() , 100, "Descripcion");
	  
      List<ColumnConfig<DTTareaRenglon, ?>> l = new ArrayList<ColumnConfig<DTTareaRenglon, ?>>();
      l.add(codigoCol);
      l.add(nombreCol);	      
      l.add(descripcionCol);
      	      	      	      
      cmGrillaTareas = new ColumnModel<DTTareaRenglon>(l);
 
      storeGrillaTareas = new ListStore<DTTareaRenglon>(props.key());	      	     	      
      
      grillaTareas = new Grid<DTTareaRenglon>(storeGrillaTareas, cmGrillaTareas);
      
      grillaTareas.getView().setAutoExpandColumn(descripcionCol);
      grillaTareas.getView().setStripeRows(true);
      grillaTareas.getView().setColumnLines(true);
      grillaTareas.setBorders(false);
 
      grillaTareas.setColumnReordering(true);
      grillaTareas.setStateful(true);
      grillaTareas.setStateId("Grilla");
      grillaTareas.setSize("100%", "100%");		
}       
}
