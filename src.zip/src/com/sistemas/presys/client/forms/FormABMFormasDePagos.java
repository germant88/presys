package com.sistemas.presys.client.forms;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.Dialog;
import com.sencha.gxt.widget.core.client.box.ConfirmMessageBox;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.HideEvent;
import com.sencha.gxt.widget.core.client.event.HideEvent.HideHandler;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.properties.FormaDePagoProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorFormasPagos;
import com.sistemas.presys.client.rpc.IRPCManejadorFormasPagosAsync;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormABMFormasDePagos extends FormABMGenerico{
   private static final FormaDePagoProperties props = GWT.create(FormaDePagoProperties.class);
	
	protected IRPCManejadorFormasPagosAsync manejadorFormasDePagos;
	
	public FormABMFormasDePagos(){
		super();		
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Formas de pagos");
	}
	
	@Override
	protected void crearManejadorRPC() {
		manejadorFormasDePagos = GWT.create(IRPCManejadorFormasPagos.class);
	}
	
	
	@Override
	protected void crearGrilla(){	      
		  ColumnConfig<FormaDePago, String> codigoCol 	      = new ColumnConfig<FormaDePago, String>(props.codigo()     , 100, "Codigo");
		  ColumnConfig<FormaDePago, String> nombreCol 	      = new ColumnConfig<FormaDePago, String>(props.nombre()     , 100, "Nombre");
		  ColumnConfig<FormaDePago, String> descripcionCol    = new ColumnConfig<FormaDePago, String>(props.descripcion(), 100, "Descripcion");
		  	      
	 
	      List<ColumnConfig<FormaDePago, ?>> l = new ArrayList<ColumnConfig<FormaDePago, ?>>();
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(descripcionCol);
	      	      	      
	      cm = new ColumnModel<FormaDePago>(l);
	 
	      store = new ListStore<FormaDePago>(props.key());	      	     	      
	      
	      grilla = new Grid<FormaDePago>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	     
	}
	
	
	@Override
	protected void ejecutarAgregar(){
		FormFormaDePago form = new FormFormaDePago(observableManager, Ctes.K_MODO_ALTA, null);			  
		form.show();
	}
	
	
	@Override
	protected void cargarGrilla(){
		grilla.getStore().clear();
		this.grilla.mask("Cargando edificios...");
		manejadorFormasDePagos.obtenerFormasDePago(new  AsyncCallback<ArrayList<FormaDePago>>() {			               
			@SuppressWarnings("unchecked")
			@Override
			public void onSuccess(ArrayList<FormaDePago> result) {
				 store.addAll(result);
                 grilla.reconfigure(store, cm);	
                 grilla.unmask();
			}
			
			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}
		});			
	}

	@Override
	protected void eliminarSeleccionado(){
		ConfirmMessageBox box = new ConfirmMessageBox("Confirmar", "�Realmente desea eliminar la forma de pago?");
	    box.addHideHandler(hadlerEliminarFormaDePago);	
	    ((TextButton)box.getButtonBar().getWidget(0)).setValue("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setText("Si");
	    ((TextButton)box.getButtonBar().getWidget(0)).setId("SI");
	    box.show();
	}
	
	
	 final HideHandler hadlerEliminarFormaDePago = new HideHandler() {
	     @Override
	     public void onHide(HideEvent event) {
	        Dialog btn = (Dialog) event.getSource();
	        String id = btn.getHideButton().getId();
	        if (id.toUpperCase().equals("SI")) {
	           eliminarFormaDePagoSeleccionada();
	        }	        
	     }
	 };
	 
	 private void eliminarFormaDePagoSeleccionada(){
	    FormaDePago formaDePagoSeleccionada;
		   
	    formaDePagoSeleccionada = (FormaDePago) grilla.getSelectionModel().getSelectedItem();
	   	    
	    eliminarFormaDePago(formaDePagoSeleccionada);            	    
	 }
	 
	 private void eliminarFormaDePago(FormaDePago formaDePagoSeleccionada) {
			manejadorFormasDePagos.eliminar(formaDePagoSeleccionada.getCodigo(), new AsyncCallback() {

				@Override
				public void onSuccess(Object result) {
			       cargarGrilla();				
				}
				
				@Override
				public void onFailure(Throwable caught) {
					// TODO Auto-generated method stub					
				}			
			}); 
     }

	 public void errorDebeSeleccionarUnElemento() {
			/*final Dialog simple = new Dialog();
		    simple.setHeadingText("Atencion");
		    simple.setPredefinedButtons(PredefinedButton.OK);
		    simple.setBodyStyleName("pad-text");
		    simple.add(new Label("Debe seleccionar un segmento en la grilla"));
		    simple.getBody().addClassName("pad-text");
		    simple.setHideOnButtonClick(true);
		    simple.setWidth(300);
		   
		   simple.show();
		   */
		   
			MessageBox box = new MessageBox("Atencion", "Debe seleccionar una forma de pago en la grilla");
		    box.show();
		}
	 
	 @Override
	 protected void modificarSeleccionado(){
		 FormaDePago formaDePagoSeleccionada;
		   
		 formaDePagoSeleccionada = (FormaDePago) grilla.getSelectionModel().getSelectedItem();
		   
		   if (formaDePagoSeleccionada != null) {
		      modificarFormaDePago(formaDePagoSeleccionada);            
		   }
		   else {			   
			   errorDebeSeleccionarUnElemento();			   			   
		   }		
	 }

	private void modificarFormaDePago(FormaDePago formaDePagoSeleccionada) {
		FormFormaDePago form = new FormFormaDePago(observableManager, Ctes.K_MODO_MODIFICACION, formaDePagoSeleccionada.getCodigo());			  
	    form.show();		
	}

	private void modificarEdificio(DTEdificio edificioSeleccionado) {
		FormEdificio form = new FormEdificio(observableManager, Ctes.K_MODO_MODIFICACION, edificioSeleccionado.getCodigo());			  
	    form.show();
	}
		
	@Override
	protected void buscar() {
		 Integer buscarPor;
		   if (this.rbtnFiltrarCodigo.getValue() == true) {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargando formas de pago...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorFormasDePagos.buscarFormaDePago(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<FormaDePago>>() {
			
			@Override
			public void onSuccess(ArrayList<FormaDePago> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();
	               ponerFocoEnFiltro();
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}
}
