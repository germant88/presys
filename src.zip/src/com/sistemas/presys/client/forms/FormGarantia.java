package com.sistemas.presys.client.forms;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.gwtext.client.widgets.form.Label;
import com.sencha.gxt.core.client.util.Margins;
import com.sencha.gxt.widget.core.client.box.MessageBox;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer.VerticalLayoutData;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.NumberPropertyEditor;
import com.sencha.gxt.widget.core.client.form.SpinnerField;
import com.sencha.gxt.widget.core.client.form.TextArea;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.rpc.IRPCManejadorGarantias;
import com.sistemas.presys.client.rpc.IRPCManejadorGarantiasAsync;
import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.model.Garantia;

public class FormGarantia extends FormEntidadGenerico{
    protected IRPCManejadorGarantiasAsync manejadorGarantias;
	private TextField txtNombre;
	private TextArea  txtDescripcion;
	private SpinnerField<Integer> spinnerFieldAnios;
	private SpinnerField<Integer> spinnerFieldMeses;
	private SpinnerField<Integer> spinnerFieldDias;
	

	public FormGarantia(ObservableManager xobsManager, Integer xmodo,
			String xcodigo) {
		super(xobsManager, xmodo, xcodigo);       
	}
	
	@Override
	protected void crearManejadorRPC() {
		 manejadorGarantias = GWT.create(IRPCManejadorGarantias.class);
	}
	
	@Override
	protected void setTitulo() {
		this.setHeadingText("Garantia");		
	}	
	
	@Override
	protected String  obtenerCodigoCorrelativo(){
		return "";
	}
	
	@Override
	protected void createComponents(){
		super.createComponents();
						
		txtNombre = new TextField();
	    vlc.add(new FieldLabel(txtNombre, "Nombre"),new VerticalLayoutData(50, 50, new Margins(30,1,1,15)));
	    
	    spinnerFieldAnios = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
	    spinnerFieldAnios.setIncrement(1);  
	    spinnerFieldAnios.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
	    spinnerFieldAnios.setValue(0);
	    spinnerFieldAnios.setMinValue(0);  
	    spinnerFieldAnios.setMaxValue(999);
	    	   	  	    
	    vlc.add(new FieldLabel(spinnerFieldAnios, "A\u00F1os"),new VerticalLayoutData(50, 50, new Margins(30,1,1,15)));

	    spinnerFieldMeses = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
	    spinnerFieldMeses.setIncrement(1);  
	    spinnerFieldMeses.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
	    spinnerFieldMeses.setValue(0);
	    spinnerFieldMeses.setMinValue(0);  
	    spinnerFieldMeses.setMaxValue(999);
	    	   	  	    
	    vlc.add(new FieldLabel(spinnerFieldMeses, "Meses"),new VerticalLayoutData(50, 50, new Margins(30,1,1,15)));
	    	   
	    spinnerFieldDias = new SpinnerField<Integer>(new NumberPropertyEditor.IntegerPropertyEditor());	  	    	   	      
	    spinnerFieldDias.setIncrement(1);  
	    spinnerFieldDias.getPropertyEditor().setFormat(NumberFormat.getFormat("0"));  	     	    	    
	    spinnerFieldDias.setValue(0);
	    spinnerFieldDias.setMinValue(0);  
	    spinnerFieldDias.setMaxValue(999);
	    	   	  	    
	    vlc.add(new FieldLabel(spinnerFieldDias, "Dias"),new VerticalLayoutData(50, 50, new Margins(30,1,1,15)));

	    
	    						
		txtNombre.focus();
		this.setFocusWidget(txtNombre);
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	protected void agregarEntidad(){
		manejadorGarantias.agregar(txtCodigo.getValue(), txtNombre.getValue(), spinnerFieldAnios.getValue(), spinnerFieldMeses.getValue(), spinnerFieldDias.getValue(), new AsyncCallback() {

			@Override
			public void onFailure(Throwable caught) {
				 MessageBox box = new MessageBox("Error");												    												    												    
			     box.setMessage("Se produjo un error al intentar agregar la garantia: " + caught.getMessage());
				 box.show();					
			}

			@Override
			public void onSuccess(Object result) {
		        cerrarme();					
			}
		});	
	}
	
	@Override
	protected void modificarEntidad() {
		manejadorGarantias.modificar(txtCodigo.getValue() , txtNombre.getValue(), spinnerFieldAnios.getValue(), spinnerFieldMeses.getValue(), spinnerFieldDias.getValue(), new AsyncCallback<Void>() {

					@Override
					public void onFailure(
							Throwable caught) {
						 MessageBox box = new MessageBox("Error");												    												    												    
					     box.setMessage("Se produjo un error al intentar modificar la garantia: " + caught.getMessage());
						 box.show();											
					}

					@Override
					public void onSuccess(Void result) {
						cerrarme();  						
					}
				});
    }
	
	@Override
	protected void cargarPantalla(String xcodigo) {
		manejadorGarantias.obtenerGarantiaPorCodigo(xcodigo, new AsyncCallback<Garantia>() {

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onSuccess(Garantia result) {
				cargarPantallaConObjeto(result);				
			}
		});     			
    }

	@Override
    protected void cargarPantallaConObjeto(Object entidad) {
       Garantia garantia = (Garantia) entidad;
		
	   this.txtCodigo.setValue(String.valueOf(garantia.getCodigo()));
 	   this.txtNombre.setValue(garantia.getNombre() != null ? garantia.getNombre() : "");
 	   this.spinnerFieldAnios.setValue(garantia.getAnios());
 	   this.spinnerFieldMeses.setValue(garantia.getMeses());
 	   this.spinnerFieldDias.setValue(garantia.getDias());
 	   
    }

}
