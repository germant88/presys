package com.sistemas.presys.client.forms;


import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Frame;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sistemas.presys.client.rpc.IRPCManejadorUtiles;
import com.sistemas.presys.client.rpc.IRPCManejadorUtilesAsync;
import com.sistemas.presys.shared.utiles.Ctes;





public class FormReportePendientes extends Window{
	private final IRPCManejadorUtilesAsync manejadorUtiles = GWT
			.create(IRPCManejadorUtiles.class);
		
	private Frame frameReporte;
	private ContentPanel panelCentral;
	protected BorderLayoutContainer layout;
	
	protected String idReporte = "";
	protected String idSubReporte = "";
	
	protected Map parametros;
				
	public FormReportePendientes (String xidReporte, Map xparametros, String xidSubReporte) {
		super();
		
		idReporte = xidReporte;
		parametros = xparametros;
		idSubReporte = xidSubReporte;
		
		CreateComponents();			
	}

	private void CreateComponents() {
		this.setMaximizable(true);
		this.setModal(true);
		this.setWidth("700px");
		this.setHeight("700px");
		
		layout = new BorderLayoutContainer();
		
		this.add(layout);
		
	   panelCentral = new ContentPanel();	  
	   panelCentral.setSize("100%", "100%");
	   panelCentral.setHeaderVisible(false);
	   
	   exportarReporte();
	   	   	   	
	   layout.setCenterWidget(panelCentral);  	  		
	}
	
	public void exportarReporte(){       		
        panelCentral.mask("Cargando...");
		manejadorUtiles.exportarReportePDF(idReporte, parametros, idSubReporte, new AsyncCallback<String>() {			
			@Override
			public void onSuccess(String result) {								
				mostrarReporte(result);				
			}
			
			@Override
			public void onFailure(Throwable caught) {
			
			}
		});
	}

	protected void mostrarReporte(String result) {
		   frameReporte = new Frame(GWT.getModuleBaseURL() + "JasperReportServlet?nombreReporte="+result);
		   
		   frameReporte.setUrl(GWT.getModuleBaseURL() + "JasperReportServlet?nombreReporte="+result);		   		   
		   
		   frameReporte.setSize("100%", "100%");
		   
		   panelCentral.add(frameReporte);
		   
		   panelCentral.unmask();
	}
	
}
