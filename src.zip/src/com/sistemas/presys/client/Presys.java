package com.sistemas.presys.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.RootLayoutPanel;

public class Presys implements EntryPoint {
	private AppView appView;
	
	
	public void onModuleLoad() {
		iniciarAplicacion();		
	}
	
	private void iniciarAplicacion(){
		appView = new AppView();
		RootLayoutPanel.get().add(appView);	
	}
}