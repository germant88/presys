package com.sistemas.presys.client.observer;

public interface IObserver {
	public void update(Object theObserved, Object changeInfo);
}
