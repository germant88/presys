package com.sistemas.presys.client.observer;

import java.util.ArrayList;
import java.util.List;

public class ObservableManager implements IObservable {

	private List<IObserver> observers = new ArrayList<IObserver>();

	public void addObserver(IObserver observer) {
		observers.add(observer);
	}

	public void removeObserver(IObserver observer) {
		observers.remove(observer);
		
	}

	public void removeObservers() {
		observers.clear();
		
	}
	
	public void notify(IObservable theObserved, Object changeInfo) {
		for(IObserver observer : observers)
			observer.update(theObserved, changeInfo);
	}
	
	public List<IObserver> getObservers() {
		return observers;
	}
	
	
}
