package com.sistemas.presys.client.observer;

public interface IObservable {
	public abstract void addObserver(IObserver observer);
	public abstract void removeObserver(IObserver observer);
	public abstract void removeObservers();		
}
