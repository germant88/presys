package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTTarea;

public interface TareaProperties extends PropertyAccess<DTTarea>{	  
	  @Path("codigo")
	  ModelKeyProvider<DTTarea> key();	
	   
	  @Path("nombre")
	  LabelProvider<DTTarea> nombreLabel();
	 
	  ValueProvider<DTTarea, String> codigo();
	  
	  ValueProvider<DTTarea, String> nombre();
	  
	  ValueProvider<DTTarea, String> descripcion();
	  
}
