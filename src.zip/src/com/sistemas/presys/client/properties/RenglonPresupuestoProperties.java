package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;

public interface RenglonPresupuestoProperties  extends PropertyAccess<DTRenglonPresupuesto>{
    
	
	  @Path("numeroRenglon")
	  ModelKeyProvider<DTRenglonPresupuesto> key();	
	   
	  @Path("nombreProducto")
	  LabelProvider<DTRenglonPresupuesto> nombreProductoLabel();
	 
	  ValueProvider<DTRenglonPresupuesto, Integer> numeroRenglon();
	  
	  ValueProvider<DTRenglonPresupuesto, String> nombreProducto();
	  
	  ValueProvider<DTRenglonPresupuesto, Double> importe();
	
}
