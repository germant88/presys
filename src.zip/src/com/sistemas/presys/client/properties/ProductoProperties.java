package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.datatypes.DTProducto;

public interface ProductoProperties extends PropertyAccess<DTCliente> {

	
	 @Path("codigo")
	  ModelKeyProvider<DTProducto> key();
	   
	  @Path("nombre")
	  LabelProvider<DTProducto> nombreLabel();
	 
	  ValueProvider<DTProducto, String> codigo();
	  
	  ValueProvider<DTProducto, String> nombre();
	  
	  ValueProvider<DTProducto, String> descripcion();
	   
	  ValueProvider<DTProducto, Boolean> habilitado();
	  
	  ValueProvider<DTProducto, String> estaHabilitado();
}
