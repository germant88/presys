package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;

public interface NotaImpresionProperties extends PropertyAccess<DTNotaImpresion>{
	  @Path("codigo")
	  ModelKeyProvider<DTNotaImpresion> key();		   
	  @Path("nombre")
	  LabelProvider<DTNotaImpresion> nombreLabel();
	 
	  ValueProvider<DTNotaImpresion, String> codigo();
	  
	  ValueProvider<DTNotaImpresion, String> nombre();
	  
	  ValueProvider<DTNotaImpresion, String> descripcion();
}
