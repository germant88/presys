package com.sistemas.presys.client.properties;

import java.util.Date;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;

public interface GridPresupuestosProperties  extends PropertyAccess<DTGridPresupuesto>{
	  
	  @Path("id")
	  ModelKeyProvider<DTGridPresupuesto> key();	
	   
	  @Path("nombreCliente")
	  LabelProvider<DTGridPresupuesto> nombreClienteLabel();
	 
	  ValueProvider<DTGridPresupuesto, String> id();

	  ValueProvider<DTGridPresupuesto, Date> fecha();
	  
	  ValueProvider<DTGridPresupuesto, String> nombreCliente();
	  
	  ValueProvider<DTGridPresupuesto, String> nombreEdificio();
	  
	  ValueProvider<DTGridPresupuesto, String> nombreEstado();
	  
	  ValueProvider<DTGridPresupuesto, Date> seguimiento();

	  ValueProvider<DTGridPresupuesto, String> nombreTipoDocumento();
}
