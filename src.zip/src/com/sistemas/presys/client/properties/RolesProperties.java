package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTRol;

public interface RolesProperties  extends PropertyAccess<DTRol>{

	  @Path("id")
	  ModelKeyProvider<DTRol> key();	
	   
	  @Path("nombre")
	  LabelProvider<DTRol> nombreRol();
	 
	  ValueProvider<DTRol, String> id();
	  
	  ValueProvider<DTRol, String> nombre();
	  	  
	
	
}
