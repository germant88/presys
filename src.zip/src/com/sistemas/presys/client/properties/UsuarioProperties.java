package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTUsuario;

public interface UsuarioProperties extends PropertyAccess<DTUsuario>{
	  
	  @Path("id")
	  ModelKeyProvider<DTUsuario> key();	
	   
	  @Path("nombre")
	  LabelProvider<DTUsuario> nombreLabel();
	 
	  ValueProvider<DTUsuario, String> id();
	  
	  ValueProvider<DTUsuario, String> nombre();
	  
	  ValueProvider<DTUsuario, String> apellido();	   	 
}
