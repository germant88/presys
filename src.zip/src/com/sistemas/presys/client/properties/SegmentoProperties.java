package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTSegmento;



public interface SegmentoProperties extends PropertyAccess<DTSegmento> {
   
	  @Path("codigo")
	  ModelKeyProvider<DTSegmento> key();	
	   
	  @Path("nombre")
	  LabelProvider<DTSegmento> nombreLabel();
	 
	  ValueProvider<DTSegmento, String> codigo();
	  
	  ValueProvider<DTSegmento, String> nombre();
	  
	  ValueProvider<DTSegmento, String> descripcion();
	   
	  ValueProvider<DTSegmento, Boolean> habilitado();
	  
	  ValueProvider<DTSegmento, String> estaHabilitado();
}
