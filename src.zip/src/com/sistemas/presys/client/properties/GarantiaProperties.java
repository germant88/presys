package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.model.FormaDePago;
import com.sistemas.presys.shared.model.Garantia;

public interface GarantiaProperties extends PropertyAccess<Garantia>{

	  @Path("codigo")
	  ModelKeyProvider<Garantia> key();	
	   
	  @Path("nombre")
	  LabelProvider<Garantia> nombreLabel();
	 
	  ValueProvider<Garantia, String> codigo();
	  
	  ValueProvider<Garantia, String> nombre();
	  
	  ValueProvider<Garantia, String> duracion();
	
}
