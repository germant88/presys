package com.sistemas.presys.client.properties;

import java.util.Date;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;

public interface NotaSeguimientoProperties extends PropertyAccess<DTNotaSeguimiento>{
	  @Path("numeroNotaSeguimiento")
	  ModelKeyProvider<DTNotaSeguimiento> key();
	   
	  @Path("descripcion")
	  LabelProvider<DTNotaSeguimiento> descripcionLabel();
	 
	  ValueProvider<DTNotaSeguimiento, Integer> numeroNotaSeguimiento();
	  
	  ValueProvider<DTNotaSeguimiento, String> descripcion();
	  
	  ValueProvider<DTNotaSeguimiento, Date> fechaSeguimiento();
	  
	  ValueProvider<DTNotaSeguimiento, String> usuario();
}
