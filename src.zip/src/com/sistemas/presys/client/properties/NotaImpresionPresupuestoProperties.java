package com.sistemas.presys.client.properties;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.LabelProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;

public interface NotaImpresionPresupuestoProperties extends PropertyAccess<DTNotaImpresionPresupuesto>{
	  @Path("numeroNotaImpresionPresupuesto")
	  ModelKeyProvider<DTNotaImpresionPresupuesto> key();	
	   
	  @Path("nombre")
	  LabelProvider<DTNotaImpresionPresupuesto> nombreLabel();
	  
	  ValueProvider<DTNotaImpresionPresupuesto, String> nombre();
	 
	  ValueProvider<DTNotaImpresionPresupuesto, String> codigoNotaImpresionXDefecto();
	  
	  ValueProvider<DTNotaImpresionPresupuesto, String> descripcion();	 
	  
}
