package com.sistemas.presys.client;


import java.util.HashMap;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.LayoutPanel;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.user.client.ui.SplitLayoutPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.widgets.Button;
import com.gwtext.client.widgets.Component;
import com.gwtext.client.widgets.Toolbar;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.ToolbarMenuButton;
import com.gwtext.client.widgets.ToolbarTextItem;
import com.gwtext.client.widgets.event.ButtonListener;
import com.gwtext.client.widgets.form.Label;
import com.gwtext.client.widgets.menu.BaseItem;
import com.gwtext.client.widgets.menu.Menu;
import com.gwtext.client.widgets.menu.MenuItem;
import com.gwtext.client.widgets.menu.event.BaseItemListenerAdapter;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sistemas.presys.client.forms.FormABMClientes;
import com.sistemas.presys.client.forms.FormABMEdificios;
import com.sistemas.presys.client.forms.FormABMFormasDePagos;
import com.sistemas.presys.client.forms.FormABMGarantias;
import com.sistemas.presys.client.forms.FormABMNotasImpresion;
import com.sistemas.presys.client.forms.FormABMProductos;
import com.sistemas.presys.client.forms.FormABMSegmentos;
import com.sistemas.presys.client.forms.FormABMTareas;
import com.sistemas.presys.client.forms.FormABMUsuarios;
import com.sistemas.presys.client.forms.FormCambiarContrasena;
import com.sistemas.presys.client.forms.FormCierrePresupuesto;
import com.sistemas.presys.client.forms.FormConsultaPresupuestos;
import com.sistemas.presys.client.forms.FormParametrosReporteDocPendientes;
import com.sistemas.presys.client.forms.FormPresupuesto;
import com.sistemas.presys.client.forms.FormReportePendientes;
import com.sistemas.presys.client.forms.FormSolicitud;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuarios;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuariosAsync;
import com.sistemas.presys.client.rpc.IRPCManejadorUtiles;
import com.sistemas.presys.client.rpc.IRPCManejadorUtilesAsync;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.utiles.Ctes;

public class AppView extends SimplePanel {		
    private final IRPCManejadorUtilesAsync manejadorUtiles = GWT
			.create(IRPCManejadorUtiles.class);
    
    private final IRPCManejadorUsuariosAsync manejadorUsuarios = GWT
    		.create(IRPCManejadorUsuarios.class);

    private Label lblUsuarioActual;
    private ToolbarButton btnCerrarSesion;
    
    private Toolbar toolbar;
    
	public AppView() {
		lblUsuarioActual = new Label();
	    lblUsuarioActual.setText("");	    	    
		obtenerUsuarioLogueado();			
	}
	
	private void cargarMenuUsuario(DTUsuario usuario){
	setSize("100%", "100%");
		
		SplitLayoutPanel splitLayoutPanel = new SplitLayoutPanel();
		
		HorizontalPanel hpCabezal = new HorizontalPanel();
		hpCabezal.setSize("100%", "68px");
		
		VerticalPanel vp = new VerticalPanel();
		vp.setSize("100%", "100%");					    
		
		LayoutPanel panelSuperior = new LayoutPanel();		
		panelSuperior.setSize("400px", "68px");
		panelSuperior.setStyleName("cabezalIzq");
		panelSuperior.add(lblUsuarioActual);
		
		LayoutPanel panelSuperiorCentral = new LayoutPanel();		
		panelSuperiorCentral.setSize("3000px", "68px");
		panelSuperiorCentral.setStyleName("cabezalCentral");
		
		hpCabezal.add(panelSuperior);
		hpCabezal.add(panelSuperiorCentral);
		
		ContentPanel panelInferior = new ContentPanel();
		panelInferior.setHeaderVisible(false);
		panelInferior.setSize("100%", "100%");
	
		setWidget(splitLayoutPanel);
		splitLayoutPanel.setSize("100%", "100%");
		
		
		toolbar = new Toolbar();
		toolbar.setAutoWidth(true);
		toolbar.setHeight("30px");
		
		
		
		ToolbarMenuButton tlbrmnbtnDefiniciones = new ToolbarMenuButton("Definiciones");
		
		Menu menu = new Menu();
		
		MenuItem menuItem = new MenuItem();
		menuItem.setText("Clientes");
		menuItem.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMClientes form = new FormABMClientes();
			   form.show();
			}
		});
		menu.addItem(menuItem);
		
		MenuItem menuItem_1 = new MenuItem();
		menuItem_1.setText("Productos");
		menuItem_1.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMProductos form = new FormABMProductos();
			   form.show();
			}
		});
		menu.addItem(menuItem_1);
		
		MenuItem menuItemTareas = new MenuItem();
		menuItemTareas.setText("Tareas");
		menuItemTareas.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMTareas form = new FormABMTareas();
			   form.show();
			}
		});
		menu.addItem(menuItemTareas);
		
		MenuItem menuItemSegmentos = new MenuItem();
		menuItemSegmentos.setText("Segmentos");
		menuItemSegmentos.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMSegmentos form = new FormABMSegmentos();
			   form.show();
			}
		});
		menu.addItem(menuItemSegmentos);
		
		MenuItem menuItemEdificios = new MenuItem();
		menuItemEdificios.setText("Edificios");
		menuItemEdificios.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMEdificios form = new FormABMEdificios();
			   form.show();
			}
		});
		menu.addItem(menuItemEdificios);
		
		MenuItem menuItemFormasPagos = new MenuItem();
		menuItemFormasPagos.setText("Formas de pago");
		menuItemFormasPagos.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMFormasDePagos form = new FormABMFormasDePagos();
			   form.show();
			}
		});
		menu.addItem(menuItemFormasPagos);
		
		MenuItem menuItemGarantias = new MenuItem();
		menuItemGarantias.setText("Garantias");
		menuItemGarantias.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMGarantias form = new FormABMGarantias();
			   form.show();
			}
		});
		menu.addItem(menuItemGarantias);
		
		MenuItem menuItemNotasImpresion = new MenuItem();
		menuItemNotasImpresion.setText("Notas impresion");
		menuItemNotasImpresion.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormABMNotasImpresion form = new FormABMNotasImpresion();
			   form.show();
			}
		});
		menu.addItem(menuItemNotasImpresion);
										
		tlbrmnbtnDefiniciones.setMenu(menu);
		toolbar.addButton(tlbrmnbtnDefiniciones);
		
		
        ToolbarMenuButton tlbrmnbtnPresupuestos = new ToolbarMenuButton("Presupuestos");
		
		Menu menuPresupuestos = new Menu();
		
		MenuItem menuItemIngresoSolicitud = new MenuItem();
		menuItemIngresoSolicitud.setText("Ingreso de solicitud");
		menuItemIngresoSolicitud.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormSolicitud formSolicitud = new FormSolicitud(null, Ctes.K_MODO_ALTA, null, null);
			   formSolicitud.show();
			}
		});
		
		MenuItem menuItemIngresoPresupuesto = new MenuItem();
		menuItemIngresoPresupuesto.setText("Ingreso de presupuesto");
		menuItemIngresoPresupuesto.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   FormPresupuesto form = new FormPresupuesto(null, Ctes.K_MODO_ALTA, null, null);
			   form.show();
			}
		});
		
		MenuItem menuItemConsultar = new MenuItem();
		menuItemConsultar.setText("Consultar");
		menuItemConsultar.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
               FormConsultaPresupuestos form = new FormConsultaPresupuestos(null, Ctes.K_MODO_CONSULTA);
               form.show();
			}
		});
		
		MenuItem menuItemCerrar = new MenuItem();
		menuItemCerrar.setText("Cerrar presupuesto");
		menuItemCerrar.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
               FormCierrePresupuesto form = new FormCierrePresupuesto();
               form.show();
			}
		});
		
		menuPresupuestos.addItem(menuItemIngresoSolicitud);
		menuPresupuestos.addItem(menuItemIngresoPresupuesto);
		menuPresupuestos.addItem(menuItemConsultar);
		menuPresupuestos.addItem(menuItemCerrar);
		tlbrmnbtnPresupuestos.setMenu(menuPresupuestos);
		toolbar.addButton(tlbrmnbtnPresupuestos);
		
		
        ToolbarMenuButton tlbrmnbtnReportes = new ToolbarMenuButton("Reportes");
        
        Menu menuReportes = new Menu();
        
        MenuItem menuItemPresupuestosPendientes = new MenuItem();
        menuItemPresupuestosPendientes.setText("Presupuestos pendientes");
        menuItemPresupuestosPendientes.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
					/*Map<String, String> parametros = new HashMap();
		            parametros.put("TipoDocumento", "PRESUP");
				    FormReportePendientes form = new FormReportePendientes(Ctes.K_REPORTE_PENDIENTES, parametros,null);
			   	    form.show();*/
			   	    
			   	    FormParametrosReporteDocPendientes form = new FormParametrosReporteDocPendientes(Ctes.K_TDOC_PRESUPUESTO);
					form.show();
			}
		});
        
        MenuItem menuItemSolicitudesPendientes = new MenuItem();
        menuItemSolicitudesPendientes.setText("Solicitues pendientes");
        menuItemSolicitudesPendientes.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
					//Map<String, String> parametros = new HashMap();
		            //parametros.put("TipoDocumento", Ctes.K_TDOC_SOLICITUD);		            
				  //FormReportePendientes form = new FormReportePendientes(Ctes.K_REPORTE_PENDIENTES, parametros, null);
			   	  //form.show();
				
				FormParametrosReporteDocPendientes form = new FormParametrosReporteDocPendientes(Ctes.K_TDOC_SOLICITUD);
				form.show();
			}
		});


        menuReportes.addItem(menuItemPresupuestosPendientes);
        menuReportes.addItem(menuItemSolicitudesPendientes);
        tlbrmnbtnReportes.setMenu(menuReportes);
        toolbar.addButton(tlbrmnbtnReportes);		
				
        ToolbarMenuButton tlbrmnbtnConfiguracion = new ToolbarMenuButton("Configuracion");
        
        Menu menuConfiguracion = new Menu();
        
        MenuItem menuItemUsuarios = new MenuItem();
        menuItemUsuarios.setText("Usuarios");
        menuItemUsuarios.addListener(new BaseItemListenerAdapter() {
			@Override
			public void onClick(BaseItem item, EventObject e) {
			   	FormABMUsuarios form = new FormABMUsuarios();
			   	form.show();
			}
		});
        
        boolean esSupervisor = false;
        for (int i = 0; i < usuario.getListaRoles().size(); i ++){
        	if (usuario.getListaRoles().get(i).getId().equals("SUPERVISOR")) {
        		esSupervisor = true;
        	}
        }
        
        
	        MenuItem menuItemCambiarContrasena = new MenuItem();
	        menuItemCambiarContrasena.setText("Cambiar mi contrase\u00f1a");
	        menuItemCambiarContrasena.addListener(new BaseItemListenerAdapter() {
				@Override
				public void onClick(BaseItem item, EventObject e) {
				   	FormCambiarContrasena form = new FormCambiarContrasena();
				   	form.show();
				}
			});
	    
	    if (esSupervisor) {    
	        menuConfiguracion.addItem(menuItemUsuarios);
        }
        menuConfiguracion.addItem(menuItemCambiarContrasena);
        tlbrmnbtnConfiguracion.setMenu(menuConfiguracion);
        toolbar.addButton(tlbrmnbtnConfiguracion);
		
        vp.setSize("100%", "100%");
		vp.add(hpCabezal);
		vp.add(toolbar);
				   
		splitLayoutPanel.addNorth(vp, 97.0);
		
		Toolbar toolbar_1 = new Toolbar();
		toolbar_1.setAutoWidth(true);
		
		ToolbarTextItem tlbrtxtmPresysVersion = new ToolbarTextItem("PRESYS Version 0.0.0.1");		
		toolbar_1.addItem(tlbrtxtmPresysVersion);
		toolbar_1.addSeparator();
				
		btnCerrarSesion = new ToolbarButton("Finalizar");
		toolbar_1.addButton(btnCerrarSesion);
		
		panelInferior.add(toolbar_1);
		
		splitLayoutPanel.addSouth(panelInferior, 27.0);
		
		AsignarEventoCerrarSesion();				
	}
	
	private void AsignarEventoCerrarSesion() {
		btnCerrarSesion.addListener(new ButtonListener() {
									
			@Override
			public void onStateRestore(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onShow(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onRender(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onHide(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onEnable(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onDisable(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onDestroy(Component component) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeStateRestore(Component component,
					JavaScriptObject state) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeShow(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeRender(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeHide(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean doBeforeDestroy(Component component) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public void onToggle(Button button, boolean pressed) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMouseOver(Button button, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMouseOut(Button button, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuTriggerOver(Button button, Menu menu, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuTriggerOut(Button button, Menu menu, EventObject e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuShow(Button button, Menu menu) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onMenuHide(Button button, Menu menu) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onClick(Button button, EventObject e) {			
				cerrarSesion();
			}

			@Override
			public void onStateSave(Component component, JavaScriptObject state) {
				// TODO Auto-generated method stub
				
			}
		});
	}

	protected void cerrarSesion() {
		manejadorUtiles.cerrarSesion(new AsyncCallback<Void>() {

			@Override
			public void onFailure(Throwable caught) {
              
			}

			@Override
			public void onSuccess(Void result) {
			   redireccionar();				
			}
		});
		
	}

	protected void redireccionar() {
		Window.Location.assign("/Login.html");
		Window.Location.reload();		
	}

	private void obtenerUsuarioLogueado() {
       manejadorUtiles.obtenerUsuarioLogueado(new AsyncCallback<String>() {
		
		@Override
		public void onSuccess(String result) {
           try {
			manejadorUsuarios.obtenerPorCodigo(result, new AsyncCallback<DTUsuario>() {

				@SuppressWarnings("unused")
				@Override
				public void onFailure(Throwable caught) {
				
					String excepcion = caught.getMessage();
					
				}

				@Override
				public void onSuccess(DTUsuario result) {
					cargarUsuarioLogueado(result);				
				}
			});
		} catch (LogicException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		         
		}
		
		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			
		}
	});				
	}

	protected void cargarUsuarioLogueado(DTUsuario usuario) {
       Boolean encontreUsuario = false;
	   if (usuario != null) {
    	   if (usuario.getId().trim().equals("") == false) {
    		   this.lblUsuarioActual.setText((usuario.getNombre() != null ? usuario.getNombre() : "") + " " + (usuario.getApellido() != null ? usuario.getApellido() : ""));
    		   cargarMenuUsuario(usuario);
    		   encontreUsuario = true;
    	   }
       }
				
	   if (encontreUsuario == false) {
		   Login formLogin = new  Login();
		   formLogin.show();
	   }
	}
}
