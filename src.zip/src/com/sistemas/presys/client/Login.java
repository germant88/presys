package com.sistemas.presys.client;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.gwtext.client.widgets.form.TextField;
import com.sencha.gxt.widget.core.client.Window;


public class Login extends Window{
	private TextField login;
	private TextField password;
	private Button resetButton;
	private Button loginButton;
	
		public Login() {		    
			setClosable(false);
			setResizable(false);
			setModal(true);
									
			login = new TextField();									
			login.setName("j_username");
			login.setMinLength(4);
			this.add(login);
			
			password = new TextField();
			password.setFieldLabel("Password");						
			password.setName("j_password");
			password.setMinLength(4);
			password.setPassword(true);
			this.add(password);
			
			
			
			resetButton = new Button("Resetear");
			resetButton.addClickHandler(new ClickHandler() {
				
				@Override
				public void onClick(ClickEvent event) {
					login.reset();
					password.reset();					
					login.focus();					
				}
			});
						
			
			loginButton = new Button("Entrar");
			loginButton.setEnabled(false);
			loginButton.addClickHandler(new ClickHandler() {
				
				@Override
				public void onClick(ClickEvent event) {
		           // loguear usuario					
				}
			});
			
			getButtonBar().add(loginButton);
			getButtonBar().add(resetButton);						
			login.focus();
		}

		
}
