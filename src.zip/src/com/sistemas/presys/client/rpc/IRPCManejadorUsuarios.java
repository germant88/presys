package com.sistemas.presys.client.rpc;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTRol;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manUsuario")
public interface IRPCManejadorUsuarios extends RemoteService{
	
public ArrayList<DTUsuario> obtenerUsuarios();

void agregarUsuario(String codigo, String nombre, String apellido,
		String password, List<DTRol> listaRolesSeleccionados) throws LogicException, Exception;

void eliminarUsuario(String id);

public DTUsuario obtenerPorCodigo(String xcodigo) throws Exception;

void modificar(String codigo, String nombre, String apellido,
		String contrasena, Boolean cambiarContrasena, List<DTRol> listaRolesSeleccionados) throws Exception;

public ArrayList<DTUsuario> buscarUsuario(Integer buscarPor, String text);

public void cambiarContrasena(String codigo, String contrasena) throws Exception;

public boolean validarContrasena(String contrasena, String codigoUsuario) throws Exception;
	
}
