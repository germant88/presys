package com.sistemas.presys.client.rpc;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;

public interface IRPCManejadorConsultasPresupuestosAsync {

	void buscarPresupuestos(String codigo, Date fechaDesde, Date fechaHasta,
			ArrayList<Integer> xestados, ArrayList<String> xtipos, String cliente, String edificio, String producto,
			AsyncCallback<ArrayList<DTGridPresupuesto>> callback);
	
	void obtenerDocumentosOrigenDeDocumento(String codigo, String tipoDocumento, AsyncCallback<ArrayList<DTGridPresupuesto>> callback);
	
	void obtenerDocumentosDestinoDeDocumento(String codigo, String tipoDocumento, AsyncCallback<ArrayList<DTGridPresupuesto>> callback);
	
}
