package com.sistemas.presys.client.rpc;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;

public interface IRPCManejadorSolicitudesPresupuestosAsync {

	void agregar(
			String xcodigo,
			String xtipoDocumento,
			Date xfecha,
			String xusuarioAsignado,
			String xcodigoCliente,
			String xcodigoEdificio,
			String xdetalles,
			Integer xestado,
			Date xfechaSeguimiento,
			ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,
			Double xtotal,
			String xcodigoSolOPresOrigen,
			String xtipoDocumentoOrigen,
			ArrayList<DTRenglonPresupuesto> listaDTRenglonesPresupuesto,
			String formaDePago,
			String garantia,
			Integer superficie,
			Double leyesSocialesHasta,
			Double costoBQ,
			Integer tiempoEjecDias,
			Integer tiempoEjecMeses,
			Integer tiempoEjecAnios,
			Integer validezDias,
			Integer validezMeses,
			Integer validezAnios,
			ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresionPresupuesto,
			AsyncCallback<Void> callback);

	void obtenerPorCodigo(String codigo, String tipoDocumento,
			AsyncCallback<DTSolicitudPresupuesto> callback);
	
	void obtenerNotasDeSolicitud(String codigo, String tipoDocumento,
			AsyncCallback<List<DTNotaSeguimiento>> callback);

	void modificar(String xcodigo, String xtipoDocumento, Date xfecha,
			String xusuarioAsignado, String xcodigoCliente,
			String xcodigoEdificio, String xdetalles, Integer xestado,
			Date xfechaSeguimiento,
			ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,
			String formaDePago, String garantia, Integer superficie,
			Double leyesSocialesHasta, Double costoBQ, Integer tiempoEjecDias,
			Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios,
		    ArrayList<DTNotaImpresionPresupuesto> notasImpresion,
			AsyncCallback<Void> callback);

	void cambiarEstado(String codigoSolicitudPresupuesto, String tipoDocumento, Integer estado,
			AsyncCallback<Void> callback);

	void obtenerNotasDeImpresion(String codigo,
			AsyncCallback<List<DTNotaImpresionPresupuesto>> callback);

}
