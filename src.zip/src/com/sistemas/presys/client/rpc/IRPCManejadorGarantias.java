package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.Garantia;

@RemoteServiceRelativePath("manGarantia")
public interface IRPCManejadorGarantias extends RemoteService{

	public void agregar(String codigo, String nombre, Integer anios, Integer meses,
                            Integer dias)  throws LogicException;

	public void modificar(String codigo, String nombre, Integer anios, Integer meses, Integer dias);
	
	public void eliminar(String codigo);
	
	public ArrayList<Garantia> obtenerGarantias();
	
	public Garantia obtenerGarantiaPorCodigo(String Codigo);
	
	public ArrayList<Garantia> buscar(Integer buscarPor, String cadena);

}
