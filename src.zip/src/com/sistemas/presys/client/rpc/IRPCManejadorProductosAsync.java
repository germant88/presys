package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.excepciones.LogicException;

public interface IRPCManejadorProductosAsync {

	public void obtenerProductos(AsyncCallback<ArrayList<DTProducto>> callback);
	
	public void agregarProducto(String xcodigo, String xnombre, String xdescripcion, AsyncCallback callback) throws LogicException;
	
	public void eliminarProducto(String xcodigo, AsyncCallback callback );
	
	public void modificarProducto(String codigo, String nombre, String descripcion, Boolean habilitado, AsyncCallback callback ); 
		
	public void buscarProducto(Integer buscarPor, String cadena, AsyncCallback<ArrayList<DTProducto>> callback);

	public void obtenerPorCodigo(String xcodigoProducto, AsyncCallback<DTProducto> asyncCallback);		
}
