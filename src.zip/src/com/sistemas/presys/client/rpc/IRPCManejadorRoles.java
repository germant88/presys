package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTRol;

@RemoteServiceRelativePath("manRol")
public interface IRPCManejadorRoles extends RemoteService{
	
	public ArrayList<DTRol> obtenerRoles();

}
