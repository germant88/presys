package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.model.Garantia;

public interface IRPCManejadorGarantiasAsync {

	void agregar(String codigo, String nombre, Integer anios, Integer meses,
			Integer dias, AsyncCallback<Void> callback);

	void buscar(Integer buscarPor, String cadena,
			AsyncCallback<ArrayList<Garantia>> callback);

	void eliminar(String codigo, AsyncCallback<Void> callback);

	void modificar(String codigo, String nombre, Integer anios, Integer meses,
			Integer dias, AsyncCallback<Void> callback);

	void obtenerGarantiaPorCodigo(String Codigo,
			AsyncCallback<Garantia> callback);

	void obtenerGarantias(AsyncCallback<ArrayList<Garantia>> callback);

}
