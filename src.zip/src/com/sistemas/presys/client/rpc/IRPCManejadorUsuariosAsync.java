package com.sistemas.presys.client.rpc;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTRol;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.excepciones.LogicException;

public interface IRPCManejadorUsuariosAsync {

   public void obtenerUsuarios(AsyncCallback<ArrayList<DTUsuario>> callback);

void agregarUsuario(String codigo, String nombre, String apellido,
		String password, List<DTRol> listaRolesSeleccionados, AsyncCallback<Void> callback);

public void eliminarUsuario(String id, AsyncCallback asyncCallback);

public void obtenerPorCodigo(String xcodigo, AsyncCallback<DTUsuario> callback) throws LogicException;

public void modificar(String codigo, String nombre, String apellido,
		String contrasena, Boolean cambiarContrasena, List<DTRol> listaRolesSeleccionados, AsyncCallback<Void> asyncCallback);

public void buscarUsuario(Integer buscarPor, String text,
		AsyncCallback<ArrayList<DTUsuario>> asyncCallback);

public void cambiarContrasena(String codigo, String contrasena,
		AsyncCallback<Void> callback);

void validarContrasena(String contrasena, String codigoUsuario,
		AsyncCallback<Boolean> callback);

}
