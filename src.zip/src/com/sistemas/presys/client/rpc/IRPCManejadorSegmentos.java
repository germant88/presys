package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manSegmentos")
public interface IRPCManejadorSegmentos extends RemoteService{

	void agregarSegmento(String xcodigo, String xnombre, String xdescripcion) throws LogicException;

	void eliminarSegmento(String xcodigo);

	void modificarSegmento(String codigo, String nombre, String descripcion,
			Boolean habilitado);
	
	public ArrayList<DTSegmento> obtenerSegmentos();
	
	public ArrayList<DTSegmento> buscarSegmento(Integer buscarPor, String cadena);

	public DTSegmento obtenerPorCodigo(String xcodigoSegmento);

	
}
