package com.sistemas.presys.client.rpc;

import java.util.ArrayList;
import java.util.Date;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.server.model.PK_SolicitudPresupuesto;
import com.sistemas.presys.shared.datatypes.DTGridPresupuesto;

@RemoteServiceRelativePath("manConsultasPresupuestos")
public interface IRPCManejadorConsultasPresupuestos extends RemoteService{
	
	ArrayList<DTGridPresupuesto> buscarPresupuestos(String codigo,
			Date fechaDesde, Date fechaHasta, ArrayList<Integer> xestados,
			ArrayList<String> xtipos, String cliente, String edificio, String producto);

	ArrayList<DTGridPresupuesto> obtenerDocumentosOrigenDeDocumento(
			String codigo, String tipoDocumento);

	ArrayList<DTGridPresupuesto> obtenerDocumentosDestinoDeDocumento(
			String codigo, String tipoDocumento);
}
