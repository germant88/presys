package com.sistemas.presys.client.rpc;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTCliente;

@RemoteServiceRelativePath("manCorrelativo")
public interface IRPCManejadorCorrelativos extends RemoteService{

	public String obtenerProximoCorrelativo(String Codigo);
}
