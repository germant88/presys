package com.sistemas.presys.client.rpc;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTCliente;

public interface IRPCManejadorCorrelativosAsync {

	public void obtenerProximoCorrelativo(String Codigo, AsyncCallback<String> callback);
}
