package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTSegmento;
import com.sistemas.presys.shared.excepciones.LogicException;

public interface IRPCManejadorSegmentosAsync {

    public void obtenerSegmentos(AsyncCallback<ArrayList<DTSegmento>> callback);
	
	public void agregarSegmento(String xcodigo, String xnombre, String xdescripcion, AsyncCallback callback) throws LogicException;
	
	public void eliminarSegmento(String xcodigo, AsyncCallback callback );
	
	public void modificarSegmento(String codigo, String nombre, String descripcion, Boolean habilitado, AsyncCallback callback ); 
		
	public void buscarSegmento(Integer buscarPor, String cadena, AsyncCallback<ArrayList<DTSegmento>> callback);

	public void obtenerPorCodigo(String xcodigoSegmento, AsyncCallback<DTSegmento> asyncCallback);
	
}
