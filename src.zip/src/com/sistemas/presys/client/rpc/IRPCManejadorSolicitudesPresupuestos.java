package com.sistemas.presys.client.rpc;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.datatypes.DTNotaImpresionPresupuesto;
import com.sistemas.presys.shared.datatypes.DTNotaSeguimiento;
import com.sistemas.presys.shared.datatypes.DTRenglonPresupuesto;
import com.sistemas.presys.shared.datatypes.DTSolicitudPresupuesto;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manSolicitud")
public interface IRPCManejadorSolicitudesPresupuestos extends RemoteService{
	public DTSolicitudPresupuesto obtenerPorCodigo(String codigo, String tipoDocumento);

	public List<DTNotaSeguimiento> obtenerNotasDeSolicitud(String codigo, String tipoDocumento);
	
	public List<DTNotaImpresionPresupuesto> obtenerNotasDeImpresion(String codigo);
	
	public void modificar(String xcodigo, String xtipoDocumento, Date xfecha, String xusuarioAsignado,
            String xcodigoCliente, String xcodigoEdificio,
            String xdetalles, Integer xestado, Date xfechaSeguimiento, ArrayList<DTNotaSeguimiento> listaNotasSeguimiento,String formaDePago, String garantia, Integer superficie, Double leyesSocialesHasta, Double costoBQ, 
			Integer tiempoEjecDias, Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios, ArrayList<DTNotaImpresionPresupuesto> notasImpresion) throws LogicException;
	
	void cambiarEstado(String codigoSolicitudPresupuesto, String tipoDocumento,
			Integer estado);

	void agregar(String xcodigo, String xtipoDocumento, Date xfecha,
			String xusuarioAsignado, String xcodigoCliente,
			String xcodigoEdificio, String xdetalles, Integer xestado,
			Date xfechaSeguimiento,
			ArrayList<DTNotaSeguimiento> listaNotasSeguimiento, Double xtotal,
			String xcodigoSolOPresOrigen, String xtipoDocumentoOrigen,
			ArrayList<DTRenglonPresupuesto> listaDTRenglonesPresupuesto,
			String formaDePago, String garantia, Integer superficie,
			Double leyesSocialesHasta, Double costoBQ, Integer tiempoEjecDias,
			Integer tiempoEjecMeses, Integer tiempoEjecAnios,
			Integer validezDias, Integer validezMeses, Integer validezAnios, 
			ArrayList<DTNotaImpresionPresupuesto> listaNotasImpresionPresupuesto)
			throws LogicException;
}
