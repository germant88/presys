package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manEdificio")
public interface IRPCManejadorEdificios extends RemoteService{
	
   public void agregarEdificio(String codigo, String nombre, String direccion, String xcodigoCliente)  throws LogicException;

   public void modificarEdificio(String codigo, String nombre, String direccion, String xcodigoCliente);

   public void eliminarEdificio(String codigo);

   public ArrayList<DTEdificio> obtenerEdificios();

   public DTEdificio obtenerEdificioPorCodigo(String Codigo);
   
   public ArrayList<DTEdificio> obtenerEdificiosDeCliente(String codigoCliente);

   public ArrayList<DTEdificio> buscarEdificio(Integer buscarPor, String cadena);

ArrayList<DTEdificio> buscarEdificioDeCliente(Integer buscarPor, String text,
		String codigoCliente);

}
