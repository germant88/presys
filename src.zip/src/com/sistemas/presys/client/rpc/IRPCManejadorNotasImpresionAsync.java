package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;

public interface IRPCManejadorNotasImpresionAsync {

	void agregarNotaImpresion(String xcodigo, String xnombre,
			String xdescripcion, AsyncCallback<Void> callback);

	void buscarNotaImpresion(Integer buscarPor, String cadena,
			AsyncCallback<ArrayList<DTNotaImpresion>> callback);

	void eliminarNotaImpresion(String xcodigo, AsyncCallback<Void> callback);

	void modificarNotaImpresion(String codigo, String nombre,
			String descripcion, AsyncCallback<Void> callback);

	void obtenerPorCodigo(String xcodigoTarea,
			AsyncCallback<DTNotaImpresion> callback);

	void obtenerNotasImpresion(AsyncCallback<ArrayList<DTNotaImpresion>> callback);

}
