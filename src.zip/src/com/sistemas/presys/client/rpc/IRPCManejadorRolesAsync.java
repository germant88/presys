package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTRol;

public interface IRPCManejadorRolesAsync {

	void obtenerRoles(AsyncCallback<ArrayList<DTRol>> callback);

}
