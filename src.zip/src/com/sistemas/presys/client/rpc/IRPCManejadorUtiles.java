package com.sistemas.presys.client.rpc;

import java.util.Map;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("manUtiles")
public interface IRPCManejadorUtiles extends RemoteService{

	public String obtenerUsuarioLogueado() throws Exception;

	void cerrarSesion();
	
	public Boolean ejecutarReporteSolicitudPresupuesto(String codigoSolPres);
	
	public String exportarReportePDF(String idReporte, Map parametros, String idSubReporte);
}
