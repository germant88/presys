package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.model.FormaDePago;

public interface IRPCManejadorFormasPagosAsync {

	void agregar(String codigo, String nombre, String descripcion,
			AsyncCallback<Void> callback);

	void eliminar(String codigo, AsyncCallback<Void> callback);

	void buscarFormaDePago(Integer buscarPor, String cadena,
			AsyncCallback<ArrayList<FormaDePago>> callback);

	void modificar(String codigo, String nombre, String descripcion,
			AsyncCallback<Void> callback);

	void obtenerFormaDePagoPorCodigo(String Codigo,
			AsyncCallback<FormaDePago> asyncCallback);

	void obtenerFormasDePago(AsyncCallback<ArrayList<FormaDePago>> callback);
}
