package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.excepciones.LogicException;
import com.sistemas.presys.shared.model.FormaDePago;


@RemoteServiceRelativePath("manFormaPago")
public interface IRPCManejadorFormasPagos extends RemoteService{

   public void agregar(String codigo, String nombre, String descripcion)  throws LogicException;

   public void modificar(String codigo, String nombre, String descripcion);

   public void eliminar(String codigo);

   public ArrayList<FormaDePago> obtenerFormasDePago();

   public FormaDePago obtenerFormaDePagoPorCodigo(String Codigo);

   public ArrayList<FormaDePago> buscarFormaDePago(Integer buscarPor, String cadena);
}
