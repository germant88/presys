package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manCliente")
public interface IRPCManejadorClientes extends RemoteService {

	public DTCliente agregarCliente(String codigo, String nombre, String email, String direccion,
			                        String rut, String telefono, String contactoNombre, String contactoEmail, String contactoTelefono, String codigoSegmento)  throws LogicException;
	
	public DTCliente modificarCliente(String codigo, String nombre, String email, String direccion,
            String rut, String telefono, String contactoNombre, String contactoEmail, String contactoTelefono,
            String codigoSegmento);
	
	public void eliminarCliente(String codigo);
	
	public ArrayList<DTCliente> obtenerClientes();
	
	public DTCliente obtenerClientePorCodigo(String Codigo);
	
	public ArrayList<DTCliente> buscarCliente(Integer buscarPor, String cadena);
	
}
