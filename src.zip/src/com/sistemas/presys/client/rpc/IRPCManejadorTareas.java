package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTTarea;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manTarea")
public interface IRPCManejadorTareas extends RemoteService{
	
    public ArrayList<DTTarea> obtenerTareas();
	
	public void agregarTarea(String xcodigo, String xnombre, String xdescripcion) throws LogicException;
	
	public void eliminarTarea(String xcodigo);
	
	public void modificarTarea(String codigo, String nombre, String descripcion); 
	
	public ArrayList<DTTarea> buscarTarea(Integer buscarPor, String cadena);
	
	public DTTarea obtenerPorCodigo(String xcodigoTarea);

}
