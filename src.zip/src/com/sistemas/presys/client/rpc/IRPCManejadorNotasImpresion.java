package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTNotaImpresion;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manNotaImpresion")
public interface IRPCManejadorNotasImpresion extends RemoteService{
	
    public ArrayList<DTNotaImpresion> obtenerNotasImpresion();
	
	public void agregarNotaImpresion(String xcodigo, String xnombre, String xdescripcion) throws LogicException;
	
	public void eliminarNotaImpresion(String xcodigo);
	
	public void modificarNotaImpresion(String codigo, String nombre, String descripcion); 
	
	public ArrayList<DTNotaImpresion> buscarNotaImpresion(Integer buscarPor, String cadena);
	
	public DTNotaImpresion obtenerPorCodigo(String xcodigoTarea);	
}
