package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTTarea;

public interface IRPCManejadorTareasAsync {

	void agregarTarea(String xcodigo, String xnombre, String xdescripcion,
			AsyncCallback<Void> callback);

	void buscarTarea(Integer buscarPor, String cadena,
			AsyncCallback<ArrayList<DTTarea>> callback);

	void eliminarTarea(String xcodigo, AsyncCallback<Void> callback);

	void modificarTarea(String codigo, String nombre, String descripcion,
			AsyncCallback<Void> callback);

	void obtenerPorCodigo(String xcodigoTarea, AsyncCallback<DTTarea> callback);

	void obtenerTareas(AsyncCallback<ArrayList<DTTarea>> callback);

}
