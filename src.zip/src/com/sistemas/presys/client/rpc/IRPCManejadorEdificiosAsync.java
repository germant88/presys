package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTEdificio;
import com.sistemas.presys.shared.excepciones.LogicException;

public interface IRPCManejadorEdificiosAsync {

	void agregarEdificio(String codigo, String nombre, String direccion, String xcodigoCliente,
			AsyncCallback<Void> callback) throws LogicException;

	void buscarEdificio(Integer buscarPor, String cadena,
			AsyncCallback<ArrayList<DTEdificio>> callback);

	void eliminarEdificio(String codigo, AsyncCallback<Void> callback);

	void modificarEdificio(String codigo, String nombre, String direccion, String xcodigoCliente,
			AsyncCallback<Void> callback);

	void obtenerEdificioPorCodigo(String Codigo,
			AsyncCallback<DTEdificio> callback);

	void obtenerEdificios(AsyncCallback<ArrayList<DTEdificio>> callback);

	void obtenerEdificiosDeCliente(String codigoCliente,
			AsyncCallback<ArrayList<DTEdificio>> callback);

	void buscarEdificioDeCliente(Integer buscarPor, String text,
			String codigoCliente,
			AsyncCallback<ArrayList<DTEdificio>> asyncCallback);

}
