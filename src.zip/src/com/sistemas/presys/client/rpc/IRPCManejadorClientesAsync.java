package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.excepciones.LogicException;

public interface IRPCManejadorClientesAsync {

	public void agregarCliente(String codigo, String nombre, String email,
			String direccion, String rut, String telefono,
			String contactoNombre, String contactoEmail,
			String contactoTelefono, String codigoSegmento, AsyncCallback<DTCliente> callback) throws LogicException;
	
	public void modificarCliente(String codigo, String nombre, String email, String direccion,
            String rut, String telefono, String contactoNombre, String contactoEmail, String contactoTelefono,
            String codigoSegmento, AsyncCallback<DTCliente> callback);		
	
	public void eliminarCliente(String codigo, AsyncCallback callback);
	
	public void obtenerClientes(AsyncCallback<ArrayList<DTCliente>> callback);
	
	public void obtenerClientePorCodigo(String Codigo, AsyncCallback<DTCliente> callback);
	
	public void buscarCliente(Integer buscarPor, String cadena, AsyncCallback<ArrayList<DTCliente>> callback);

}
