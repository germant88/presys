package com.sistemas.presys.client.rpc;

import java.util.ArrayList;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.sistemas.presys.shared.datatypes.DTProducto;
import com.sistemas.presys.shared.excepciones.LogicException;

@RemoteServiceRelativePath("manProducto")
public interface IRPCManejadorProductos extends RemoteService {

	public ArrayList<DTProducto> obtenerProductos();
	
	public void agregarProducto(String xcodigo, String xnombre, String xdescripcion) throws LogicException;
	
	public void eliminarProducto(String xcodigo);
	
	public void modificarProducto(String codigo, String nombre, String descripcion, Boolean habilitado); 
	
	public ArrayList<DTProducto> buscarProducto(Integer buscarPor, String cadena);
	
	public DTProducto obtenerPorCodigo(String xcodigoProducto);
}

