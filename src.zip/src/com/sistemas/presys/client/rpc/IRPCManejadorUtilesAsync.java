package com.sistemas.presys.client.rpc;

import java.util.Map;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface IRPCManejadorUtilesAsync {

	void obtenerUsuarioLogueado(AsyncCallback<String> callback);

	void cerrarSesion(AsyncCallback<Void> asyncCallback);

	void ejecutarReporteSolicitudPresupuesto(String codigoSolPres, AsyncCallback<Boolean> callback);

	void exportarReportePDF(String idReporte, Map parametros, String idSubReporte, AsyncCallback<String> callback);
}
