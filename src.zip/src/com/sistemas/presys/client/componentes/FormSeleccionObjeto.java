package com.sistemas.presys.client.componentes;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gwtext.client.core.EventObject;
import com.gwtext.client.data.SimpleStore;
import com.gwtext.client.widgets.Component;
import com.gwtext.client.widgets.Toolbar;
import com.gwtext.client.widgets.ToolbarButton;
import com.gwtext.client.widgets.event.ButtonListener;
import com.gwtext.client.widgets.form.ComboBox;
import com.gwtext.client.widgets.menu.Menu;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.forms.FormCliente;
import com.sistemas.presys.client.observer.IObserver;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.ClienteProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorClientes;
import com.sistemas.presys.client.rpc.IRPCManejadorClientesAsync;
import com.sistemas.presys.shared.datatypes.DTCliente;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormSeleccionObjeto extends Window implements IObserver{
	
	private static final ClienteProperties props = GWT.create(ClienteProperties.class);
	private final IRPCManejadorClientesAsync manejadorClientes = GWT
				.create(IRPCManejadorClientes.class);
	
	protected Button btnBuscar;
	protected ComboBox cboxFiltrarPor;
	protected TextField txtFiltro;
	protected ListStore store;
	protected ColumnModel cm;		
	protected Grid grilla;	
	BorderLayoutContainer layout;
	public String tituloForm;
	private ObservableManager observableManager;
	private ObservableManager observableManagerCli;
	
	private ToolbarButton btnAgregar;
	private ToolbarButton btnModificar;
	private ToolbarButton btnEliminar;
	
	public FormSeleccionObjeto(){
	  super();	   	  
	}

	public FormSeleccionObjeto(ObservableManager xObservableManager) {
       super(); 
       observableManager = xObservableManager;
       observableManagerCli = new ObservableManager();
	   observableManagerCli.addObserver(this);
	   createComponents();	   
	   vincularEventos();	  
       cboxFiltrarPor.setValue("Nombre");
       this.setFocusWidget(txtFiltro);
	   cargarGrilla();
	}
	
	
	private void vincularEventos() {
		grilla.addCellDoubleClickHandler(new CellDoubleClickHandler() {			
			@Override
			public void onCellClick(CellDoubleClickEvent event) {				
				DTCliente clienteSeleccionado;
				clienteSeleccionado = (DTCliente) grilla.getSelectionModel().getSelectedItem();
				observableManager.notify(observableManager, clienteSeleccionado);
				cerrarme();
				
			}
		});
		
		btnBuscar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
			 buscar();   				
			}
		});	
		
       txtFiltro.addKeyDownHandler(new KeyDownHandler() {
			
			@Override
			public void onKeyDown(KeyDownEvent event) {
				 if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {				   
					 buscar();
					 ponerFocoEnFiltros();					 			
				 }				
			}			
		});
       
       btnAgregar.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			FormCliente form = new FormCliente(observableManagerCli, Ctes.K_MODO_ALTA, null); 			 
			form.show();			
		}
	});
       
       btnModificar.addListener(new ButtonListener() {
		
		@Override
		public void onStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onStateRestore(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onShow(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onRender(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onHide(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onEnable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDisable(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDestroy(Component component) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public boolean doBeforeStateSave(Component component, JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeStateRestore(Component component,
				JavaScriptObject state) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeShow(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeRender(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeHide(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean doBeforeDestroy(Component component) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void onToggle(com.gwtext.client.widgets.Button button,
				boolean pressed) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOver(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMouseOut(com.gwtext.client.widgets.Button button,
				EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOver(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuTriggerOut(com.gwtext.client.widgets.Button button,
				Menu menu, EventObject e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuShow(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onMenuHide(com.gwtext.client.widgets.Button button, Menu menu) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onClick(com.gwtext.client.widgets.Button button, EventObject e) {
			FormCliente form = new FormCliente(observableManagerCli, Ctes.K_MODO_MODIFICACION, ((DTCliente)grilla.getSelectionModel().getSelectedItem()).getCodigo()); 			 
			form.show();			
		}
	});
	}

	public void ponerFocoEnFiltros() {
		this.setFocusWidget(txtFiltro);		
		txtFiltro.setCursorPos(txtFiltro.getText().length());
		txtFiltro.focus();		
	}

	private void createComponents() {
     	   this.setMaximizable(true);
		   this.setModal(true);
		   this.setHeadingText(tituloForm);
		   this.setSize("550px", "300px");	   
  
	        final SimpleStore store = new SimpleStore(new String[]{"Filtro"}, Ctes.getFiltrarPorClientes());  
	        store.load();  
	  	    
	        cboxFiltrarPor = new ComboBox();
	        cboxFiltrarPor.setForceSelection(true);  
	        cboxFiltrarPor.setMinChars(1);  
	        cboxFiltrarPor.setFieldLabel("Filtrar por");  
	        cboxFiltrarPor.setStore(store);  
	        cboxFiltrarPor.setDisplayField("Filtro");  
	        cboxFiltrarPor.setMode(ComboBox.LOCAL);  
	        cboxFiltrarPor.setTriggerAction(ComboBox.ALL);  
	        cboxFiltrarPor.setEmptyText("Filtrar por...");  	         
	        cboxFiltrarPor.setTypeAhead(true);    
	        cboxFiltrarPor.setWidth(150);  	  
	        cboxFiltrarPor.setHideTrigger(false);  
	    
		     
		   BorderLayoutContainer layout = new BorderLayoutContainer();
		 
		   this.add(layout);
		   
		   crearGrilla();
		   
		   // NORTH
		   ContentPanel panelSuperior = new ContentPanel();
		   panelSuperior.setHeaderVisible(false);

		   HorizontalPanel hp = new HorizontalPanel();
		   hp.setWidth("300px");
		    
	   
		   txtFiltro = new TextField();
		   txtFiltro.setWidth("200px");
		   
		   btnBuscar = new Button();
		   btnBuscar.setText("Buscar");
		   btnBuscar.setSize("70px", "30px");
		   
           hp.add(cboxFiltrarPor);
		   hp.add(txtFiltro);
		   hp.add(btnBuscar);
		   
		   hp.setSpacing(15);
		   hp.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		           
           Toolbar toolbar = new Toolbar();

	       toolbar.setWidth("100%");
		       
	       btnAgregar = new ToolbarButton();
			
		   btnAgregar.setText("Agregar");
			
		   toolbar.addButton(btnAgregar);
		   
		   btnModificar = new ToolbarButton();
			
		   btnModificar.setText("Modificar");
			
		   toolbar.addButton(btnModificar);
			
		   toolbar.addFill();								   			
		   	   	   
		   VerticalPanel vp = new VerticalPanel();
		   vp.setWidth("100%");
					
		   vp.add(hp);
		   vp.add(toolbar);
			
		   panelSuperior.setWidget(vp);				
			 		   		   
		   //.add(hp, new MarginData(0, 350, 0, 0));
		   //panelSuperior.add(toolbar, new MarginData(0, 350, 0, 0));
		    
		   layout.setNorthWidget(panelSuperior, new BorderLayoutData(90));
		 
		   // CENTER	   
		   ContentPanel panelCentral = new ContentPanel();
		   panelCentral.setHeaderVisible(false);
		   panelCentral.add(grilla);
		   layout.setCenterWidget(panelCentral);		
	}

	

	private void cargarGrilla() {
		grilla.getStore().clear();
		this.grilla.mask("Cargando clientes...");
		manejadorClientes.obtenerClientes(new AsyncCallback<ArrayList<DTCliente>>(
				) {
					@Override
					public void onSuccess(ArrayList<DTCliente> result) {
					   store.addAll(result);
                       grilla.reconfigure(store, cm);	
                       grilla.unmask();
					}
					
					@Override
					public void onFailure(Throwable caught) {
						grilla.unmask();						
					}
		});				
	}
	
	
	private void crearGrilla() {		  		  	    
	      List<ColumnConfig<DTCliente, ?>> l = new ArrayList<ColumnConfig<DTCliente, ?>>();
		  
		  ColumnConfig<DTCliente, String> codigoCol = new ColumnConfig<DTCliente, String>(props.codigo(), 100, "Codigo");
		  ColumnConfig<DTCliente, String> nombreCol = new ColumnConfig<DTCliente, String>(props.nombre(), 100, "Nombre");
		  ColumnConfig<DTCliente, String> rutCol = new ColumnConfig<DTCliente, String>(props.rut(), 100, "Rut");
		  ColumnConfig<DTCliente, String> telefonoCol = new ColumnConfig<DTCliente, String>(props.telefono(), 100, "Telefono");
	      ColumnConfig<DTCliente, String> emailCol = new ColumnConfig<DTCliente, String>(props.email(), 100, "Email");
	      ColumnConfig<DTCliente, String> direccionCol = new ColumnConfig<DTCliente, String>(props.direccion(), 100, "Direccion");
	 
	      
	      l.add(codigoCol);
	      l.add(nombreCol);
	      l.add(rutCol);
	      l.add(telefonoCol);
	      l.add(emailCol);
	      l.add(direccionCol);
		  
		  
	      cm = new ColumnModel<DTCliente>(l);
	 
	      store = new ListStore<DTCliente>(props.key());	      	     	      
	      
	      grilla = new Grid<DTCliente>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	      grilla.getView().setAutoExpandMin(100);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	      
	}
	
	private void cerrarme(){
		this.hide();
	}
	
	private void buscar() {
		Integer buscarPor;
		   if (this.cboxFiltrarPor.getValue().equals("Codigo"))  {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else if (this.cboxFiltrarPor.getValue().equals("Nombre")) {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_RUT;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargarndo clientes...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorClientes.buscarCliente(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTCliente>>() {
			
			@Override
			public void onSuccess(ArrayList<DTCliente> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();	               
	               btnBuscar.setEnabled(true);
			}
			
			@Override
			public void onFailure(Throwable caught) {
				 grilla.unmask();
				 btnBuscar.setEnabled(true);
			}
		});
	}

	@Override
	public void update(Object theObserved, Object changeInfo) {
       buscar();		
	}
}
