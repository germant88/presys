package com.sistemas.presys.client.componentes;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.gwtext.client.data.SimpleStore;
import com.gwtext.client.widgets.form.ComboBox;
import com.sencha.gxt.data.shared.ListStore;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer;
import com.sencha.gxt.widget.core.client.container.BorderLayoutContainer.BorderLayoutData;
import com.sencha.gxt.widget.core.client.container.MarginData;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent;
import com.sencha.gxt.widget.core.client.event.CellDoubleClickEvent.CellDoubleClickHandler;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sencha.gxt.widget.core.client.grid.ColumnConfig;
import com.sencha.gxt.widget.core.client.grid.ColumnModel;
import com.sencha.gxt.widget.core.client.grid.Grid;
import com.sistemas.presys.client.observer.ObservableManager;
import com.sistemas.presys.client.properties.UsuarioProperties;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuarios;
import com.sistemas.presys.client.rpc.IRPCManejadorUsuariosAsync;
import com.sistemas.presys.shared.datatypes.DTUsuario;
import com.sistemas.presys.shared.utiles.Ctes;

public class FormSeleccionUsuario extends Window{
	
	private static final UsuarioProperties props = GWT.create(UsuarioProperties.class);
	private final IRPCManejadorUsuariosAsync manejadorUsuarios = GWT
				.create(IRPCManejadorUsuarios.class);
	
	
	protected Button btnBuscar;
	protected ComboBox cboxFiltrarPor;
	protected TextField txtFiltro;
	protected ListStore store;
	protected ColumnModel cm;		
	protected Grid grilla;	
	BorderLayoutContainer layout;
	public String tituloForm;
	private ObservableManager observableManager;
	private Integer Entidad;
	
	
	public FormSeleccionUsuario(){
	  super();	   	  
	}

	public FormSeleccionUsuario(ObservableManager xObservableManager) {
       super();
       observableManager = xObservableManager;
	   createComponents();	   
	   vincularEventos();	  
       cboxFiltrarPor.setValue("Nombre");
       this.setFocusWidget(txtFiltro);
	   cargarGrilla();
	}

	private void vincularEventos() {
		grilla.addCellDoubleClickHandler(new CellDoubleClickHandler() {			
			@Override
			public void onCellClick(CellDoubleClickEvent event) {				
				DTUsuario usuarioSeleccionado;
				usuarioSeleccionado = (DTUsuario) grilla.getSelectionModel().getSelectedItem();
				observableManager.notify(observableManager, usuarioSeleccionado);
				cerrarme();				
			}
		});
		
		btnBuscar.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
			 buscar();   				
			}
		});	
		
       txtFiltro.addKeyDownHandler(new KeyDownHandler() {
			
			@Override
			public void onKeyDown(KeyDownEvent event) {
				 if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {				   
					 buscar();
					 ponerFocoEnFiltros();					 			
				 }				
			}			
		});
	}

	public void ponerFocoEnFiltros() {
		this.setFocusWidget(txtFiltro);		
		txtFiltro.setCursorPos(txtFiltro.getText().length());
		txtFiltro.focus();		
	}

	private void createComponents() {
     	   this.setMaximizable(true);
		   this.setModal(true);
		   this.setHeadingText(tituloForm);
		   this.setSize("550px", "300px");	   

		 //create a Store using local array data  
	        final SimpleStore store = new SimpleStore(new String[]{"Filtro"}, Ctes.getFiltrarPorUsuarios());  
	        store.load();  
	  	    
	        cboxFiltrarPor = new ComboBox();
	        cboxFiltrarPor.setForceSelection(true);  
	        cboxFiltrarPor.setMinChars(1);  
	        cboxFiltrarPor.setFieldLabel("Filtrar por");  
	        cboxFiltrarPor.setStore(store);  
	        cboxFiltrarPor.setDisplayField("Filtro");  
	        cboxFiltrarPor.setMode(ComboBox.LOCAL);  
	        cboxFiltrarPor.setTriggerAction(ComboBox.ALL);  
	        cboxFiltrarPor.setEmptyText("Filtrar por...");  	         
	        cboxFiltrarPor.setTypeAhead(true);  
	        //cboxFiltrarPor.setSelectOnFocus(true);  
	        cboxFiltrarPor.setWidth(150);  	  
	        cboxFiltrarPor.setHideTrigger(false);  
	    
		     
		   BorderLayoutContainer layout = new BorderLayoutContainer();
		 
		   this.add(layout);
		   
		   crearGrilla();
		   
		   // NORTH
		   ContentPanel panelSuperior = new ContentPanel();
		   panelSuperior.setHeaderVisible(false);

		   HorizontalPanel hp = new HorizontalPanel();
		   hp.setWidth("300px");
		    
	   
		   txtFiltro = new TextField();
		   txtFiltro.setWidth("200px");
		   
		   btnBuscar = new Button();
		   btnBuscar.setText("Buscar");
		   btnBuscar.setSize("70px", "30px");
		   
           hp.add(cboxFiltrarPor);
		   hp.add(txtFiltro);
		   hp.add(btnBuscar);
		   
		   hp.setSpacing(15);
		   hp.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
		   	   	   
		   panelSuperior.add(hp, new MarginData(0, 350, 0, 0));
		    
		   layout.setNorthWidget(panelSuperior, new BorderLayoutData(50));
		 
		   // CENTER	   
		   ContentPanel panelCentral = new ContentPanel();
		   panelCentral.setHeaderVisible(false);
		   panelCentral.add(grilla);
		   layout.setCenterWidget(panelCentral);		
	}

	

	private void cargarGrilla() {
		grilla.getStore().clear();
		this.grilla.mask("Cargando...");
		manejadorUsuarios.obtenerUsuarios(new AsyncCallback<ArrayList<DTUsuario>>() {

			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();				
			}

			@Override
			public void onSuccess(ArrayList<DTUsuario> result) {
				   store.addAll(result);
                   grilla.reconfigure(store, cm);	
                   grilla.unmask();				
			}
		});				
	}
	
	
	private void crearGrilla() {		  
		  	    
	      List<ColumnConfig<DTUsuario, ?>> l = new ArrayList<ColumnConfig<DTUsuario, ?>>();
		  
		  ColumnConfig<DTUsuario, String> codigoCol   = new ColumnConfig<DTUsuario, String>(props.id(), 100, "Codigo");
		  ColumnConfig<DTUsuario, String> nombreCol   = new ColumnConfig<DTUsuario, String>(props.nombre(), 100, "Nombre");
		  ColumnConfig<DTUsuario, String> ApellidoCol = new ColumnConfig<DTUsuario, String>(props.apellido(), 100, "Apellido");

	 
	      
	      l.add(codigoCol);
	      l.add(nombreCol);	   
	      l.add(ApellidoCol);
		  
		  
	      cm = new ColumnModel<DTUsuario>(l);
	 
	      store = new ListStore<DTUsuario>(props.key());	      	     	      
	      
	      grilla = new Grid<DTUsuario>(store, cm);
	      
	      grilla.getView().setAutoExpandColumn(nombreCol);
	      grilla.getView().setStripeRows(true);
	      grilla.getView().setColumnLines(true);
	      grilla.setBorders(false);
	      grilla.getView().setAutoExpandMin(100);
	 
	      grilla.setColumnReordering(true);
	      grilla.setStateful(true);
	      grilla.setStateId("Grilla");
	      grilla.setSize("100%", "100%");	      
	}
	
	private void cerrarme(){
		this.hide();
	}
	
	private void buscar() {
		Integer buscarPor;
		   if (this.cboxFiltrarPor.getValue().equals("Codigo"))  {
	          	  buscarPor = Ctes.K_BUSCAR_X_COD;
	       }
		   else if (this.cboxFiltrarPor.getValue().equals("Nombre")) {
			   buscarPor = Ctes.K_BUSCAR_X_NOM;
		   }
		   else {
			   buscarPor = Ctes.K_BUSCAR_X_DIR;
		   }
		   
		   grilla.getStore().clear();
		   this.grilla.mask("Cargando...");
		   this.btnBuscar.setEnabled(false);
		   
		   manejadorUsuarios.buscarUsuario(buscarPor, this.txtFiltro.getText(), new AsyncCallback<ArrayList<DTUsuario>>() {

			@Override
			public void onFailure(Throwable caught) {
				grilla.unmask();
				btnBuscar.setEnabled(true);				
			}

			@Override
			public void onSuccess(ArrayList<DTUsuario> result) {
				   store.addAll(result);
	               grilla.reconfigure(store, cm);	
	               grilla.unmask();	               
	               btnBuscar.setEnabled(true);				
			}
		});
		   		   
	}

}
