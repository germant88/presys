package com.sistemas.presys.client.componentes;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DecoratorPanel;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.sencha.gxt.widget.core.client.form.TextField;
import com.sistemas.presys.client.observer.ObservableManager;

public class SeleccionObjeto extends Composite {
   public TextField txtCodigo;
   public Button    btnBuscar;
   private DecoratorPanel main;
   private ObservableManager observableManager;
   
	public static final Integer K_CLIENTES         = 1;
	public static final Integer K_EDIFICIOS        = 2;
	public static final Integer K_PRODUCTOS        = 3;
	public static final Integer K_USUARIOS         = 4;
	public static final Integer K_TAREAS           = 5;
	public static final Integer K_FORMAS_DE_PAGOS  = 6;
	public static final Integer K_GARANTIAS        = 7;
	public static final Integer K_NOTAS_IMPRESION  = 8;	
	private Integer Entidad;
    private String  codigoEntidadAux;
	
   public SeleccionObjeto(ObservableManager xObservableManager, Integer xEntidad){
	   main = new DecoratorPanel();
	   main.setWidget(crearControles());
	   Entidad = xEntidad;
	   vincularEventos();
	   observableManager = xObservableManager;
	   initWidget(main);
   }
   public SeleccionObjeto(ObservableManager xObservableManager, Integer xEntidad, String xcodigoEntidadAux){
	   main = new DecoratorPanel();
	   main.setWidget(crearControles());
	   Entidad = xEntidad;
	   codigoEntidadAux = xcodigoEntidadAux;
	   vincularEventos();
	   observableManager = xObservableManager;
	   initWidget(main);
	}

private HorizontalPanel crearControles() {
	   HorizontalPanel contenedor = new HorizontalPanel();
       contenedor.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
       contenedor.setSpacing(0);
	   
      txtCodigo = new TextField();
      btnBuscar = new Button();
      btnBuscar.setText("...");
      
      
      contenedor.add(txtCodigo);
      contenedor.add(btnBuscar);      
      
      return contenedor;
   }
   
   private void vincularEventos(){
	   btnBuscar.addClickHandler(new ClickHandler() {
		
		@Override
		public void onClick(ClickEvent event) {
		     
		   
		   if (Entidad.equals(K_CLIENTES)) {
		      FormSeleccionObjeto form = new FormSeleccionObjeto(observableManager);
		      form.show();
		   }
		   else if (Entidad.equals(K_EDIFICIOS)) {
			  FormSeleccionEdificio form = new FormSeleccionEdificio(observableManager, codigoEntidadAux);
			  form.show();
		   }		   		  
		   else if (Entidad.equals(K_USUARIOS)) {
			   FormSeleccionUsuario form = new FormSeleccionUsuario(observableManager);
			   form.show();
		   }
		   else if (Entidad.equals(K_TAREAS)) {
			  FormSeleccionTarea   form = new FormSeleccionTarea(observableManager);
			  form.show();
		   }
		   else if (Entidad.equals(K_FORMAS_DE_PAGOS)) {
			  FormSeleccionFormaDePago form = new FormSeleccionFormaDePago(observableManager);
		      form.show();
		   }
		   else if (Entidad.equals(K_GARANTIAS)) {
			  FormSeleccionGarantia form = new FormSeleccionGarantia(observableManager);
			  form.show();
		   }
		   else if (Entidad.equals(K_NOTAS_IMPRESION)) {
			  FormSeleccionNotaImpresion form = new FormSeleccionNotaImpresion(observableManager);
			  form.show();
		   }
		   else {
			   FormSeleccionProducto form = new FormSeleccionProducto(observableManager);
			   form.show();
		   }
		}
	});
   }
public String getCodigoEntidadAux() {
	return codigoEntidadAux;
}
public void setCodigoEntidadAux(String codigoEntidadAux) {
	this.codigoEntidadAux = codigoEntidadAux;
}
	
	
}
